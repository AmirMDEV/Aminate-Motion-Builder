"""
Aminate Mobu

MotionBuilder sibling toolkit for Aminate.
"""

from __future__ import annotations

import base64
import json
import math
import os
import re
import time
from collections import OrderedDict

from pyfbsdk import (
    FBAddRegionParam,
    FBApplication,
    FBBodyNodeId,
    FBButton,
    FBCharacter,
    FBCharacterKeyingMode,
    FBCharacterPlotWhere,
    FBColor,
    FBConstraint,
    FBAttachType,
    FBButtonLook,
    FBButtonState,
    FBButtonStyle,
    FBEdit,
    FBFindModelByLabelName,
    FBGetSelectedModels,
    FBLabel,
    FBMemo,
    FBMessageBox,
    FBModel,
    FBModelList,
    FBModelMarker,
    FBModelMarkerOptical,
    FBModelSkeleton,
    FBModelTransformationType,
    FBPlotOptions,
    FBPlotPopup,
    FBPlayerControl,
    FBPopup,
    ShowTool,
    FBStringList,
    FBSystem,
    FBTime,
    FBTimeReferential,
    FBTextJustify,
    FBToolPossibleDockPosition,
    FBVector3d,
)
import pyfbsdk_additions

try:
    from PySide6 import QtCore, QtGui, QtWidgets
    from shiboken6 import getCppPointer, isValid as shiboken_is_valid, wrapInstance
except Exception:  # pragma: no cover - MotionBuilder fallback
    try:  # pragma: no cover - older MotionBuilder fallback
        from PySide2 import QtCore, QtGui, QtWidgets
        from shiboken2 import getCppPointer, isValid as shiboken_is_valid, wrapInstance
    except Exception:  # pragma: no cover - no Qt bridge available
        QtCore = None
        QtGui = None
        QtWidgets = None
        getCppPointer = None
        shiboken_is_valid = None
        wrapInstance = None


TOOL_NAME = "Aminate Mobu"
TOOL_VERSION = "Version 0.1 BETA"
TOOL_DOC_TAG = "aminate_mobu_tool"
QT_WINDOW_OBJECT_NAME = "aminateMobuWindow"
QT_DOCK_OBJECT_NAME = "aminateMobuDock"
QT_LAUNCHER_TOOLBAR_OBJECT_NAME = "aminateMobuLauncherToolbar"
QT_LAUNCHER_BUTTON_OBJECT_NAME = "aminateMobuLauncherButton"
QT_PANEL_BUILD_VERSION = 27
LAUNCHER_ICON_RELATIVE_PATH = os.path.join("assets", "icons", "aminate_toolbar_18.png")
STARTUP_BOOTSTRAP_FILENAME = "aminate_mobu_startup.py"
MB_DOCUMENTS_ROOT = os.path.join(
    os.path.expanduser("~"),
    "Documents",
    "MB",
)
FOLLOW_AMIR_URL = "https://followamir.com"
DEFAULT_DONATE_URL = "https://www.paypal.com/donate/?hosted_button_id=2U2GXSKFJKJCA"
DONATE_URL = os.environ.get("AMIR_PAYPAL_DONATE_URL") or os.environ.get("AMIR_DONATE_URL") or DEFAULT_DONATE_URL
THEME_MOTIONBUILDER = "motionbuilder"
THEME_MODERN = "modern"
THEME_LABELS = OrderedDict(
    [
        (THEME_MOTIONBUILDER, "MotionBuilder"),
        (THEME_MODERN, "Modern"),
    ]
)
DEFAULT_THEME_KEY = THEME_MOTIONBUILDER
SCENE_CLEANER_HINT = (
    "Marker label is not exposed by MotionBuilder Python. "
    "Animated default markers are treated as prop markers, renamed with your chosen base name, and only non-animated junk markers are deleted."
)
LOCK_DEFINITION_WARNING = (
    "Your character map looks finished. Lock the character definition so MotionBuilder can use it properly."
)
CONTROL_RIG_MODE_WARNING = (
    "You need to be in a control rig body part or full body editing mode."
)
LOCK_WARNING_THROTTLE_SECONDS = 8.0
MODE_WARNING_THROTTLE_SECONDS = 2.0
DEFAULT_TOAST_DURATION_MS = 4000
DEFAULT_PROP_MARKER_BASE_NAME = "Prop"
UNLABELLED_MARKER_PATTERN = re.compile(r"^(?:_?\d+|marker[\s_-]?\d*|tmpmarker[\s_-]?\d*|unnamedmarker[\s_-]?\d*|unnamed[\s_-]?\d*)$", re.IGNORECASE)
UNLABELLED_MARKER_NAMESPACE_PATTERN = re.compile(r"^unlabel(?:ed|led)?markers?$", re.IGNORECASE)
CONTROL_RIG_PROPERTY_NAMES = {"Lcl Translation", "Lcl Rotation"}
MARKER_TRANSFORM_PROPERTY_NAMES = (
    "Lcl Translation",
    "Lcl Rotation",
    "Translation",
    "Rotation",
)
TPOSE_AXIS_DOT_THRESHOLD = 0.995
TPOSE_ALIGN_FINGERS = False
EASY_TOOLTIP_TEXT = {
    "Aminate": "Open Aminate Mobu tools.",
    "File": "Open files, save work, import, export, and close the scene.",
    "Edit": "Undo, redo, copy, paste, and other basic scene edits.",
    "Animation": "Work with keys, takes, layers, plotting, and animation tools.",
    "Settings": "Change MotionBuilder preferences and scene options.",
    "Layout": "Show, hide, and reset panel layouts.",
    "Open Reality": "Open live device, camera, and realtime connection tools.",
    "Python Tools": "Open MotionBuilder scripting and Python helper tools.",
    "Window": "Show, hide, and arrange MotionBuilder windows.",
    "Help": "Open help, docs, and version information.",
    "Viewer": "This is the main 3D view where you look at and work in the scene.",
    "View": "Choose which camera or view the Viewer uses.",
    "Display": "Choose what the Viewer draws, like grids, helpers, and models.",
    "Renderer": "Choose how the Viewer draws the scene.",
    "Transport Controls": "Play, stop, scrub, and move through time.",
    "Auto Key": "Creates a key when you change something that already has animation keys, so edits get recorded while you work.",
    "AutoKey": "Creates a key when you change something that already has animation keys, so edits get recorded while you work.",
    "Key": "Adds a keyframe at the current time for the selected object, skeleton bone, or character control.",
    "Key Selected": "Adds a keyframe at the current time for the selected object, skeleton bone, or character control.",
    "Set Key": "Adds a keyframe at the current time for the selected object, skeleton bone, or character control.",
    "Delete Key": "Deletes the selected keyframes, or deletes the key on the current frame for the selected animated channels.",
    "Delete Keys": "Deletes selected keyframes from the active animation curve or timeline selection.",
    "Cut Key": "Removes selected keyframes and puts them on the clipboard so you can paste them somewhere else.",
    "Copy Key": "Copies selected keyframes to the clipboard without removing them.",
    "Paste Key": "Pastes copied keyframes at the current time.",
    "Move Keys": "Moves selected animation keys in time without changing the object shape or pose directly.",
    "Play": "Starts playback so you can watch the animation at the current frame rate.",
    "Stop": "Stops playback and leaves the time slider where it is.",
    "Go To Start": "Moves the time slider to the first frame of the take.",
    "Go To End": "Moves the time slider to the last frame of the take.",
    "Previous Key": "Jumps to the previous keyframe on the active animation.",
    "Next Key": "Jumps to the next keyframe on the active animation.",
    "Previous Frame": "Moves one frame backward.",
    "Next Frame": "Moves one frame forward.",
    "Loop": "Repeats playback between the start and end frames.",
    "Snap on Frames": "Forces keys and scrubbing to land on whole frames instead of in-between times.",
    "30 fps": "Shows the frame rate used for playback and timing.",
    "24 fps": "Shows the frame rate used for playback and timing.",
    "1x": "Plays the timeline at normal speed.",
    "Action": "Work with action clips and their timing.",
    "Take": "A take is one version of the animation, like a separate recording pass.",
    "Take 001": "This is the active take, which stores one version of your animation.",
    "BaseAnimation": "Base animation is the main animation layer underneath extra correction layers.",
    "Navigator": "Browse everything in the scene.",
    "Dopesheet": "See and move keys in a simple timeline view.",
    "FCurves": "Edit animation curves and smooth motion.",
    "Story": "Arrange animation clips on tracks, like editing a video timeline.",
    "Animation Trigger": "Set up events that make animation actions happen automatically.",
    "Key Controls": "Change how keys are created, moved, flattened, and synced.",
    "TR": "Key translation and rotation channels.",
    "0": "Zero means the value or frame is set to 0. On key controls, it resets the selected channel value to its neutral zero value.",
    "Zero": "Sets selected keyable values back to 0, like clearing a control's translate or rotate offset.",
    "Flat": "Makes selected keys ease in and out smoothly by flattening their curve handles.",
    "Disc.": "Makes selected keys change sharply, useful for pops, switches, or instant pose changes.",
    "Discontinuity": "Makes selected keys change sharply, useful for pops, switches, or instant pose changes.",
    "Stepped": "Holds the pose until the next key, then changes instantly.",
    "Linear": "Moves evenly between keys with no ease in or ease out.",
    "Auto": "Lets MotionBuilder choose the default key interpolation or active keying mode.",
    "Selected": "Only affects selected objects, selected controls, or selected keys.",
    "All": "Affects all relevant objects, controls, or keys in this tool area.",
    "TRS": "Keys translation, rotation, and scale channels together.",
    "Sync. All": "Syncs keying across matching controls so related body parts stay together.",
    "IK": "Inverse kinematics lets you move a hand or foot and have the limb follow.",
    "FK": "Forward kinematics rotates each joint in order, like shoulder then elbow then wrist.",
    "Resources": "Browse assets, scripts, templates, and scene resources.",
    "Pose Controls": "Browse saved poses and pose tools for characters.",
    "Properties": "Shows editable settings for the selected object.",
    "Filters": "Limits what the list shows so you can find things faster.",
    "Character Controls": "Create, define, characterize, and drive characters.",
    "Character": "Choose which character the Character Controls panel edits.",
    "Source": "Choose the motion source that drives this character, such as another character or mocap.",
    "Create": "Make a new actor or control rig.",
    "Actor": "Create an actor setup for device or optical data.",
    "Control Rig": "Build an animatable rig with controls.",
    "Define": "Connect skeleton parts to a character definition.",
    "Skeleton": "Map skeleton bones into the character system.",
    "Definition": "Connect bones to the HumanIK body map and check if the character is valid.",
    "Controls": "Animate the character using HumanIK body controls.",
    "Input Type": "Choose whether the character is driven by a control rig, skeleton, actor, or another source.",
    "Input Source": "Choose the exact control rig, character, or device sending motion into this character.",
    "Plot Character": "Bakes the current character motion into regular keys so it can be saved or edited.",
    "Plot": "Bakes procedural, constraint, or control-rig motion into regular editable keyframes.",
    "Bake": "Turns driven motion into normal keyframes so it keeps working without the live driver.",
    "Save": "Writes or bakes the current result so it can be reused safely.",
    "Reset All Properties": "Resets character definition settings back to their defaults.",
    "Character Definition": "Shows the bone map that tells MotionBuilder which bone is each body part.",
    "Character Settings": "Shows solver and retargeting settings for the selected character.",
    "Actions": "Main Aminate tools for cleaning, mapping, and setup checks.",
    "Notes": "Simple rules and reminders for how Aminate behaves.",
    "What This Tool Helps With": "Quick summary of what Aminate Mobu can do for this scene.",
    "Prop Marker Base Name": "Type the base name Aminate should use when renaming animated prop markers.",
    "Refresh": "Re-read the current scene and refresh Aminate status.",
    "Search": "Type here to filter the list and find matching scene items faster.",
    "Filters": "Choose which item types are shown in the list.",
    "Expand": "Open this item so you can see its children.",
    "Collapse": "Close this item so its children are hidden.",
    "Lock": "Prevents accidental changes until you unlock it.",
    "Unlock": "Allows this item to be edited again.",
    "Pin": "Keeps this panel or setting visible while you work.",
    "Close": "Closes this panel or menu.",
    "Scene Cleaner": "Delete user cameras, remove junk default markers, and keep animated prop markers.",
    "Delete Cameras": "Delete user made cameras from the scene.",
    "Delete Markers": "Delete junk default markers and keep animated prop markers.",
    "Auto Map Skeleton": "Select a skeleton bone or skinned mesh, then click this to map that whole skeleton into HumanIK.",
    "Use Selected Skeleton": "Optional: lock Aminate to the selected skeleton hierarchy before using several tools.",
    "T-Pose Frame 0": "Put the current character skeleton into a T-pose on frame 0 and key it there only.",
    "Hide Panel": "Collapse Aminate into a thin side tab so it takes less space.",
    "Show Panel": "Expand Aminate back into the full tool panel.",
    "Validate Character": "Check whether the character setup is ready and warn about missing steps.",
    "Body Part Mode": "Switch the control rig into body part editing mode.",
    "Full Body Mode": "Switch the control rig into full body editing mode.",
    "History Timeline": "Open the History Timeline tool for full scene snapshot branches.",
    "Name": "Shows the item name.",
    "Type": "Shows what kind of item this is.",
    "Active": "Shows whether this item is switched on right now.",
    "Weight": "Controls how strongly this constraint affects its object.",
    "Targets": "Shows the objects this constraint follows or points at.",
    "Definition Manager": "Save and reload character definition presets.",
    "Refresh Definitions": "Reload the saved definition preset list.",
    "Save Definition": "Save the current character definition links as a reusable preset.",
    "Load Definition": "Load the selected definition preset onto the current character.",
    "Rename Definition": "Rename the selected definition preset using the name field.",
    "Delete Definition": "Delete the selected saved definition preset.",
    "Constraints Manager": "Manage MotionBuilder constraints with easy names, keying, baking, and plain-English advice.",
    "List Constraints": "Refresh the list of constraints in the scene.",
    "Rename To Easy Names": "Rename selected constraints to readable Aminate names.",
    "Rename All Easy": "Rename every scene constraint to readable Aminate names.",
    "Key Selected Props": "Key useful constraint properties at the current time.",
    "Set Offset For This Take": "Store the current prop constraint offset on this take so the prop keeps the right hand or marker relationship here.",
    "Set Offset For All Takes": "Visit every take and store the current prop constraint offset on each take.",
    "Preview Offset Only": "Show the detected prop constraint offset without changing or keying anything.",
    "Mute Constraints For Setup": "Temporarily turn selected prop constraints off so you can place the prop cleanly before capturing an offset.",
    "Restore Constraints": "Turn constraints back on after setup and restore their previous active states.",
    "Bake Options": "Open MotionBuilder plotting options before saving constrained motion.",
    "Save To Skeleton": "Plot or save the current character motion onto the skeleton.",
    "Save To Control Rig": "Plot or save the current character motion onto the control rig.",
    "Donate": "Open Amir's PayPal donation page.",
    "Theme": "Shows which Aminate theme is active right now.",
    "Ready.": "This line shows the latest Aminate status message.",
}
AMINATE_MOBU_LOCAL_STYLESHEETS = {
THEME_MOTIONBUILDER: "",
THEME_MODERN: """
QWidget#aminateMobuWindow {
    background-color: #2F363E;
    color: #D8DEE5;
}
QWidget#aminateMobuWindow QLabel {
    font-size: 10px;
}
QLabel#aminateMobuHeaderTitle {
    color: #F2F5F8;
    font-size: 13px;
    font-weight: 600;
}
QLabel#aminateMobuHeaderSubtitle {
    color: #99A5B0;
    font-size: 9px;
}
QLabel#aminateMobuThemeBadge {
    background-color: #283038;
    color: #C7D1DB;
    border: 1px solid #43515E;
    border-radius: 3px;
    font-size: 9px;
    padding: 3px 8px;
}
QFrame#mayaAnimWorkflowTabIntro {
    background-color: #313A43;
    color: #DFE5EA;
    border: 1px solid #45525E;
    border-left: 3px solid #6D879A;
    border-radius: 4px;
}
QLabel#mayaAnimWorkflowIntroTitle {
    color: #F1F4F7;
    font-size: 11px;
    font-weight: 700;
}
QLabel#mayaAnimWorkflowIntroBody {
    color: #C5CED7;
    font-size: 10px;
}
QLabel#mayaAnimWorkflowStatusLabel {
    background-color: #252C33;
    color: #E1E6EB;
    border: 1px solid #3E4A55;
    border-radius: 4px;
    font-size: 10px;
    padding: 4px 7px;
}
QPlainTextEdit#aminateMobuStatusMemo {
    background-color: #21272E;
    color: #D8DEE4;
    border: 1px solid #404C57;
    border-radius: 3px;
    font-size: 10px;
    padding: 5px;
    selection-background-color: #526A7F;
}
QLabel#mayaAnimWorkflowBrandLabel,
QLabel#mayaAnimWorkflowVersionLabel,
QLabel#aminateMobuGroupHint {
    color: #8D99A4;
    font-size: 9px;
}
QPushButton#aminateMobuThemeToggle {
    background-color: #38424C;
    border: 1px solid #546372;
    border-radius: 4px;
    padding: 4px 12px;
    color: #EDF1F4;
    font-weight: 600;
    outline: none;
}
QPushButton#aminateMobuThemeToggle:hover {
    background-color: #45505C;
    border-color: #6D7E8F;
}
QPushButton#aminateMobuThemeToggle:pressed {
    background-color: #2E3740;
    border-color: #73889C;
}
QPushButton,
QToolButton,
QAbstractButton {
    background-color: #3A434D;
    color: #E9EDF1;
    border: 1px solid #53616F;
    border-radius: 4px;
    padding: 4px 10px;
    font-weight: 600;
    outline: none;
}
QPushButton:hover,
QToolButton:hover,
QAbstractButton:hover {
    background-color: #45505C;
    border-color: #687A8C;
}
QPushButton:pressed,
QToolButton:pressed,
QAbstractButton:pressed {
    background-color: #2F3740;
    border-color: #73879B;
}
QPushButton:checked,
QToolButton:checked,
QAbstractButton:checked {
    background-color: #516374;
    border-color: #7E96AA;
}
QPushButton:disabled,
QToolButton:disabled,
QAbstractButton:disabled {
    background-color: #262C32;
    color: #74808A;
    border-color: #3D4852;
}
QLineEdit,
QPlainTextEdit,
QTextEdit,
QComboBox,
QSpinBox,
QDoubleSpinBox {
    background-color: #252C33;
    color: #DEE4EA;
    border: 1px solid #43505C;
    border-radius: 3px;
    padding: 3px 6px;
    selection-background-color: #526A7F;
}
QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 16px;
    border-left: 1px solid #45515D;
    background-color: #2D353E;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
}
QComboBox::down-arrow {
    width: 8px;
    height: 8px;
}
QLineEdit:focus,
QPlainTextEdit:focus,
QTextEdit:focus,
QComboBox:focus,
QSpinBox:focus,
QDoubleSpinBox:focus {
    border-color: #6F889E;
}
QCheckBox,
QRadioButton,
QLabel {
    color: #D8DEE5;
}
QGroupBox {
    background-color: #313943;
    color: #E3E8ED;
    border: 1px solid #44515D;
    border-radius: 5px;
    margin-top: 10px;
    padding: 8px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 8px;
    font-size: 10px;
    padding: 0px 5px;
    color: #E9EEF2;
    background-color: #38434F;
    border: 1px solid #546271;
    border-radius: 3px;
}
QTabWidget::pane {
    border: 1px solid #44515D;
    border-radius: 6px;
    top: -1px;
    background-color: #29313A;
    padding: 2px;
}
QTabBar::tab {
    background-color: #313A43;
    color: #B8C4CF;
    border: 1px solid #465462;
    border-bottom: 0px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    padding: 4px 10px;
    margin-right: 2px;
    min-width: 38px;
}
QTabBar::tab:hover {
    background-color: #39434D;
    color: #ECF1F5;
    border-color: #58697A;
}
QTabBar::tab:selected {
    background-color: #405262;
    color: #F3F6F8;
    border-color: #6F889D;
    padding-bottom: 5px;
}
QTabBar::tab:!selected {
    margin-top: 2px;
}
QSplitter::handle:horizontal {
    width: 2px;
    background-color: #46525D;
}
QSplitter::handle:vertical {
    height: 2px;
    background-color: #46525D;
}
QScrollBar:vertical,
QScrollBar:horizontal {
    background-color: #232A31;
    border: 0px;
    margin: 0px;
}
QScrollBar::handle:vertical,
QScrollBar::handle:horizontal {
    background-color: #46515D;
    border-radius: 4px;
    min-height: 18px;
    min-width: 18px;
}
QScrollBar::handle:vertical:hover,
QScrollBar::handle:horizontal:hover {
    background-color: #55616D;
}
QScrollBar::add-line,
QScrollBar::sub-line {
    width: 0px;
    height: 0px;
}
""",
}
APP_THEME_STYLESHEETS = {
THEME_MOTIONBUILDER: """
QWidget {
    color: #E4E8EC;
    background-color: #3A3F44;
    selection-background-color: #6A7D8D;
    selection-color: #FFFFFF;
}
QMainWindow,
QDialog,
QDockWidget,
QTabWidget::pane,
QStackedWidget,
QStatusBar,
QToolBar,
QMenuBar,
QMenu,
QAbstractScrollArea,
QTreeView,
QListView,
QTableView {
    background-color: #3B4045;
}
QDockWidget::title {
    background-color: #454A50;
    color: #F1F4F6;
    padding-left: 6px;
    padding-top: 3px;
    padding-bottom: 3px;
    border-bottom: 1px solid #2E3337;
}
QDockWidget {
    border: 1px solid #2E3337;
}
QMenuBar {
    background-color: #34393E;
    border-bottom: 1px solid #272B2F;
}
QMenuBar::item {
    background: transparent;
    color: #F1F4F6;
    padding: 3px 7px;
    margin: 0px 1px;
}
QMenuBar::item:selected,
QMenuBar::item:pressed {
    background-color: #4B5258;
}
QMenu {
    background-color: #3C4146;
    color: #F1F4F6;
    border: 1px solid #25292D;
}
QMenu::item {
    padding: 5px 22px;
}
QMenu::item:selected {
    background-color: #59616A;
}
QToolBar {
    background-color: #44494F;
    border: 0px;
    spacing: 2px;
}
QToolBar::separator {
    background-color: #2D3135;
    width: 1px;
    margin: 3px 3px;
}
QPushButton,
QToolButton,
QAbstractButton,
QComboBox,
QAbstractSpinBox,
QLineEdit,
QPlainTextEdit,
QTextEdit {
    background-color: #4D5359;
    color: #F2F5F7;
    border: 1px solid #24282C;
    border-radius: 1px;
    padding: 3px 7px;
}
QPushButton:hover,
QToolButton:hover,
QAbstractButton:hover,
QComboBox:hover,
QAbstractSpinBox:hover,
QLineEdit:hover {
    background-color: #596068;
}
QPushButton:pressed,
QToolButton:pressed,
QAbstractButton:pressed {
    background-color: #363B40;
}
QComboBox::drop-down {
    width: 16px;
    border-left: 1px solid #30353A;
    background-color: #464C52;
}
QAbstractItemView {
    background-color: #30353A;
    color: #EEF2F5;
    border: 1px solid #25292D;
    outline: 0px;
}
QAbstractItemView::item:selected {
    background-color: #637381;
    color: #FFFFFF;
}
QHeaderView::section {
    background-color: #494F55;
    color: #F1F4F6;
    border: 1px solid #2D3135;
    padding: 3px 6px;
}
QTabWidget::pane {
    border: 1px solid #2E3337;
    background-color: #3B4045;
}
QTabBar::tab {
    background-color: #454B51;
    color: #E6EAED;
    border: 1px solid #2D3135;
    padding: 4px 9px;
    margin-right: 1px;
}
QTabBar::tab:selected {
    background-color: #59616A;
    color: #FFFFFF;
}
QTreeView,
QListView,
QTableView {
    background-color: #2E3338;
    alternate-background-color: #383D42;
    gridline-color: #555B61;
    border: 1px solid #2D3135;
}
QTreeView::item,
QListView::item,
QTableView::item {
    padding-top: 2px;
    padding-bottom: 2px;
}
QTreeView::item:selected,
QListView::item:selected,
QTableView::item:selected {
    background-color: #6A7D8D;
    color: #FFFFFF;
}
""",
THEME_MODERN: """
QWidget {
    color: #D6DDE4;
    background-color: #29313A;
    selection-background-color: #4D677E;
    selection-color: #F2F5F8;
}
QMainWindow,
QDialog,
QDockWidget,
QTabWidget::pane,
QStackedWidget,
QStatusBar,
QToolBar,
QMenuBar,
QMenu,
QAbstractScrollArea,
QTreeView,
QListView,
QTableView {
    background-color: #273039;
}
QDockWidget > QWidget,
QStackedWidget > QWidget,
QTabWidget > QWidget,
QDockWidget QWidget,
QStackedWidget QWidget,
QTabWidget QWidget,
QAbstractScrollArea > QWidget,
QAbstractScrollArea > QWidget > QWidget,
QFrame {
    background-color: #242D35;
}
QDockWidget QLabel,
QStackedWidget QLabel,
QTabWidget QLabel {
    background-color: transparent;
}
QDockWidget::title {
    background-color: #2D3741;
    color: #DEE4EA;
    padding-left: 10px;
    padding-right: 34px;
    padding-top: 4px;
    padding-bottom: 4px;
    border-bottom: 1px solid #43515D;
}
QDockWidget {
    border: 1px solid #42505B;
}
QDockWidget::close-button,
QDockWidget::float-button {
    background-color: #3A434D;
    border: 1px solid #52606E;
    border-radius: 4px;
    padding: 1px;
}
QDockWidget::close-button:hover,
QDockWidget::float-button:hover {
    background-color: #46515D;
    border-color: #687A8C;
}
QDockWidget::close-button:pressed,
QDockWidget::float-button:pressed {
    background-color: #2F3740;
    border-color: #73879B;
}
QMenuBar {
    border-bottom: 1px solid #3F4C58;
    background-color: #25303A;
}
QMenuBar::item {
    background: transparent;
    padding: 4px 8px;
    margin: 1px 2px;
    color: #D8DEE5;
    border-radius: 4px;
}
QMenuBar::item:selected,
QMenu::item:selected {
    background-color: #37414C;
    color: #F0F3F6;
}
QMenuBar::item:pressed {
    background-color: #313A43;
    color: #F4F6F8;
}
QMenu {
    background-color: #2A3138;
    border: 1px solid #42505B;
}
QMenu::item {
    padding: 6px 22px;
}
QMenu::separator {
    height: 1px;
    background-color: #43515E;
    margin: 4px 10px;
}
QToolBar {
    border: 0px;
    spacing: 3px;
    background-color: #2C3640;
}
QToolBar::separator {
    background-color: #44525F;
    width: 1px;
    margin: 4px 4px;
}
QToolButton#aminateMobuLauncherButton {
    background-color: #34404B;
    border: 1px solid #607589;
    border-radius: 5px;
    color: #EDF2F5;
    padding: 4px 10px;
    font-weight: 600;
}
QToolButton#aminateMobuLauncherButton:hover {
    background-color: #3F4C59;
    border: 1px solid #7890A5;
}
QToolButton#aminateMobuLauncherButton:pressed,
QToolButton#aminateMobuLauncherButton:checked {
    background-color: #2C3540;
    border: 1px solid #8099AF;
}
QPushButton,
QToolButton,
QAbstractButton {
    background-color: #39434D;
    color: #E9EEF2;
    border: 1px solid #52616F;
    border-radius: 5px;
    padding: 4px 10px;
    font-weight: 600;
}
QComboBox,
QAbstractSpinBox,
QLineEdit,
QPlainTextEdit,
QTextEdit {
    background-color: #242B32;
    color: #E6EBEF;
    border: 1px solid #42505B;
    border-radius: 4px;
    padding: 4px 8px;
}
QToolBar QToolButton,
QToolBar QAbstractButton,
QToolBar QComboBox,
QToolBar QAbstractSpinBox {
    background-color: #36404A;
    border: 1px solid #4E5D6C;
    border-radius: 4px;
    padding: 2px 7px;
}
QToolBar QToolButton:hover,
QToolBar QAbstractButton:hover,
QToolBar QComboBox:hover,
QToolBar QAbstractSpinBox:hover {
    background-color: #414C58;
    border-color: #65788A;
}
QToolBar QToolButton:pressed,
QToolBar QAbstractButton:pressed,
QToolBar QToolButton:checked {
    background-color: #2E3741;
    border-color: #73879C;
}
QToolBar QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 14px;
    border-left: 1px solid #4C5A67;
    background-color: #2D353E;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
}
QToolBar QComboBox::down-arrow {
    width: 8px;
    height: 8px;
}
QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 16px;
    border-left: 1px solid #465461;
    background-color: #2D353E;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
}
QComboBox::down-arrow {
    width: 8px;
    height: 8px;
}
QComboBox QAbstractItemView {
    background-color: #252C33;
    color: #E7ECF0;
    border: 1px solid #45515D;
    selection-background-color: #4F667B;
    selection-color: #F4F7F9;
    outline: 0px;
}
QAbstractItemView {
    background-color: #252C33;
    color: #E3E8EC;
    border: 1px solid #42505D;
    outline: 0px;
}
QAbstractSpinBox::up-button,
QAbstractSpinBox::down-button {
    background-color: #2D353E;
    border-left: 1px solid #465461;
    width: 15px;
}
QAbstractSpinBox::up-button:hover,
QAbstractSpinBox::down-button:hover {
    background-color: #38434E;
}
QDockWidget QLabel {
    color: #D2DAE1;
}
QDockWidget QLineEdit,
QDockWidget QComboBox,
QDockWidget QAbstractSpinBox {
    border-radius: 4px;
    padding: 2px 6px;
    min-height: 18px;
}
QDockWidget QToolButton {
    background-color: #36404A;
    border: 1px solid #4A5A69;
    border-radius: 4px;
    padding: 1px 5px;
    min-height: 17px;
    font-weight: 500;
}
QDockWidget QAbstractButton {
    background-color: #36404A;
    color: #DDE4EA;
    border: 1px solid #4A5A69;
    border-radius: 4px;
    padding: 1px 5px;
}
QDockWidget QToolButton:hover,
QDockWidget QAbstractButton:hover,
QDockWidget QComboBox:hover,
QDockWidget QAbstractSpinBox:hover,
QDockWidget QLineEdit:hover {
    border-color: #708498;
}
QDockWidget QComboBox::drop-down {
    width: 13px;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
}
QDockWidget QAbstractSpinBox::up-button,
QDockWidget QAbstractSpinBox::down-button {
    width: 13px;
}
QDockWidget QComboBox QAbstractItemView::item {
    padding: 3px 8px;
    min-height: 18px;
}
QPushButton:hover,
QToolButton:hover,
QAbstractButton:hover {
    background-color: #44505C;
    border-color: #697C8E;
}
QComboBox:hover,
QAbstractSpinBox:hover,
QLineEdit:hover,
QPlainTextEdit:hover,
QTextEdit:hover {
    border-color: #697C8E;
}
QPushButton:pressed,
QToolButton:pressed,
QAbstractButton:pressed {
    background-color: #2F3740;
    border-color: #73879B;
}
QPushButton:checked,
QToolButton:checked,
QAbstractButton:checked,
QToolButton:selected {
    background-color: #516374;
    border-color: #8098AC;
}
QPushButton:disabled,
QToolButton:disabled,
QAbstractButton:disabled,
QComboBox:disabled,
QAbstractSpinBox:disabled {
    background-color: #262C32;
    color: #77818A;
    border-color: #3D4852;
}
QLineEdit:focus,
QPlainTextEdit:focus,
QTextEdit:focus,
QComboBox:focus,
QAbstractSpinBox:focus {
    border: 1px solid #6F889E;
}
QHeaderView::section {
    background-color: #2D3741;
    color: #DEE5EB;
    border: 1px solid #43515E;
    padding: 4px 8px;
    font-weight: 600;
}
QTabWidget::pane {
    border: 1px solid #42505C;
    border-radius: 6px;
    top: -1px;
    background-color: #242D35;
    padding: 2px;
}
QTabBar::tab {
    background-color: #313A43;
    color: #BBC6D0;
    border: 1px solid #465361;
    border-bottom: 0px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    padding: 4px 11px;
    margin-right: 3px;
    min-width: 40px;
}
QTabBar::tab:hover {
    background-color: #39434D;
    color: #EEF2F5;
    border-color: #566879;
}
QTabBar::tab:selected {
    background-color: #415264;
    color: #F4F7F9;
    border-color: #70899E;
    padding-bottom: 5px;
}
QTabBar::tab:!selected {
    margin-top: 2px;
}
QTreeView,
QListView,
QTableView {
    background-color: #1F262D;
    alternate-background-color: #273039;
    gridline-color: #43515E;
    border: 1px solid #42505D;
    show-decoration-selected: 1;
}
QTreeView::item,
QListView::item,
QTableView::item {
    padding-top: 2px;
    padding-bottom: 2px;
    padding-left: 5px;
    padding-right: 5px;
    border: 1px solid transparent;
}
QTreeView::item:selected,
QListView::item:selected,
QTableView::item:selected {
    background-color: #4F667B;
    color: #F4F7F9;
    border-color: #748EA4;
}
QTreeView::item:hover,
QListView::item:hover,
QTableView::item:hover {
    background-color: #333D47;
}
QSplitter::handle:horizontal {
    width: 2px;
    background-color: #43505C;
}
QSplitter::handle:vertical {
    height: 2px;
    background-color: #43505C;
}
QScrollBar:vertical,
QScrollBar:horizontal {
    background: #21282F;
    border: 0px;
    margin: 0px;
}
QScrollBar::handle:vertical,
QScrollBar::handle:horizontal {
    background: #44505C;
    border-radius: 4px;
    min-height: 18px;
    min-width: 18px;
}
QScrollBar::handle:vertical:hover,
QScrollBar::handle:horizontal:hover {
    background: #56626E;
}
QScrollBar::add-line,
QScrollBar::sub-line {
    width: 0px;
    height: 0px;
}
QStatusBar {
    border-top: 1px solid #3F4C58;
}
QStatusBar::item {
    border: 0px;
}
QStatusBar QLabel {
    color: #CDD5DD;
    padding-left: 1px;
    padding-right: 2px;
}
QGroupBox {
    border: 1px solid #44525E;
    border-radius: 6px;
    margin-top: 10px;
    padding: 10px;
    background-color: #28313A;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 1px 6px;
    color: #E8EEF3;
    background-color: #38444F;
    border: 1px solid #526171;
    border-radius: 4px;
}
""",
}

CORE_REQUIRED_LINKS = (
    "HipsLink",
    "LeftUpLegLink",
    "LeftLegLink",
    "LeftFootLink",
    "RightUpLegLink",
    "RightLegLink",
    "RightFootLink",
    "SpineLink",
    "LeftArmLink",
    "LeftForeArmLink",
    "LeftHandLink",
    "RightArmLink",
    "RightForeArmLink",
    "RightHandLink",
    "HeadLink",
)

CHARACTER_SLOT_CANDIDATES = OrderedDict(
    [
        ("ReferenceLink", ("reference", "root")),
        ("HipsLink", ("hips", "pelvis")),
        ("HipsTranslationLink", ("hips", "pelvis")),
        ("LeftUpLegLink", ("leftupleg", "leftthigh", "lthigh")),
        ("LeftLegLink", ("leftleg", "leftcalf", "lcalf")),
        ("LeftFootLink", ("leftfoot", "lfoot")),
        ("LeftToeBaseLink", ("lefttoebase", "lefttoe", "ltoe")),
        ("RightUpLegLink", ("rightupleg", "rightthigh", "rthigh")),
        ("RightLegLink", ("rightleg", "rightcalf", "rcalf")),
        ("RightFootLink", ("rightfoot", "rfoot")),
        ("RightToeBaseLink", ("righttoebase", "righttoe", "rtoe")),
        ("SpineLink", ("spine", "waist")),
        ("Spine1Link", ("spine1", "spine01", "chest")),
        ("Spine2Link", ("spine2", "spine02", "upperchest")),
        ("Spine3Link", ("spine3",)),
        ("Spine4Link", ("spine4",)),
        ("Spine5Link", ("spine5",)),
        ("Spine6Link", ("spine6",)),
        ("Spine7Link", ("spine7",)),
        ("Spine8Link", ("spine8",)),
        ("Spine9Link", ("spine9",)),
        ("NeckLink", ("neck",)),
        ("Neck1Link", ("neck1", "neck01")),
        ("Neck2Link", ("neck2", "neck02")),
        ("HeadLink", ("head",)),
        ("LeftShoulderLink", ("leftshoulder", "leftclavicle", "lclavicle")),
        ("LeftArmLink", ("leftarm", "leftupperarm", "lupperarm")),
        ("LeftArmRollLink", ("leftarmroll", "leftuparmtwist", "luparmtwist")),
        ("LeftForeArmLink", ("leftforearm", "leftlowerarm", "lforearm", "llowerarm")),
        ("LeftForeArmRollLink", ("leftforearmroll", "leftforearmtwist", "lforearmtwist")),
        ("LeftHandLink", ("lefthand", "lwrist")),
        ("RightShoulderLink", ("rightshoulder", "rightclavicle", "rclavicle")),
        ("RightArmLink", ("rightarm", "rightupperarm", "rupperarm")),
        ("RightArmRollLink", ("rightarmroll", "rightuparmtwist", "ruparmtwist")),
        ("RightForeArmLink", ("rightforearm", "rightlowerarm", "rforearm", "rlowerarm")),
        ("RightForeArmRollLink", ("rightforearmroll", "rightforearmtwist", "rforearmtwist")),
        ("RightHandLink", ("righthand", "rwrist")),
        ("LeftUpLegRollLink", ("leftuplegroll", "leftthightwist", "lthightwist")),
        ("LeftLegRollLink", ("leftlegroll", "leftcalftwist", "lcalftwist")),
        ("RightUpLegRollLink", ("rightuplegroll", "rightthightwist", "rthightwist")),
        ("RightLegRollLink", ("rightlegroll", "rightcalftwist", "rcalftwist")),
        ("LeftHandThumb1Link", ("lefthandthumb1", "lthumb1")),
        ("LeftHandThumb2Link", ("lefthandthumb2", "lthumb2")),
        ("LeftHandThumb3Link", ("lefthandthumb3", "lthumb3")),
        ("LeftHandThumb4Link", ("lefthandthumb4", "lthumb4")),
        ("LeftHandIndex1Link", ("lefthandindex1", "lindex1")),
        ("LeftHandIndex2Link", ("lefthandindex2", "lindex2")),
        ("LeftHandIndex3Link", ("lefthandindex3", "lindex3")),
        ("LeftHandIndex4Link", ("lefthandindex4", "lindex4")),
        ("LeftHandMiddle1Link", ("lefthandmiddle1", "lmiddle1")),
        ("LeftHandMiddle2Link", ("lefthandmiddle2", "lmiddle2")),
        ("LeftHandMiddle3Link", ("lefthandmiddle3", "lmiddle3")),
        ("LeftHandMiddle4Link", ("lefthandmiddle4", "lmiddle4")),
        ("LeftHandRing1Link", ("lefthandring1", "lring1")),
        ("LeftHandRing2Link", ("lefthandring2", "lring2")),
        ("LeftHandRing3Link", ("lefthandring3", "lring3")),
        ("LeftHandRing4Link", ("lefthandring4", "lring4")),
        ("LeftHandPinky1Link", ("lefthandpinky1", "lpinky1")),
        ("LeftHandPinky2Link", ("lefthandpinky2", "lpinky2")),
        ("LeftHandPinky3Link", ("lefthandpinky3", "lpinky3")),
        ("LeftHandPinky4Link", ("lefthandpinky4", "lpinky4")),
        ("RightHandThumb1Link", ("righthandthumb1", "rthumb1")),
        ("RightHandThumb2Link", ("righthandthumb2", "rthumb2")),
        ("RightHandThumb3Link", ("righthandthumb3", "rthumb3")),
        ("RightHandThumb4Link", ("righthandthumb4", "rthumb4")),
        ("RightHandIndex1Link", ("righthandindex1", "rindex1")),
        ("RightHandIndex2Link", ("righthandindex2", "rindex2")),
        ("RightHandIndex3Link", ("righthandindex3", "rindex3")),
        ("RightHandIndex4Link", ("righthandindex4", "rindex4")),
        ("RightHandMiddle1Link", ("righthandmiddle1", "rmiddle1")),
        ("RightHandMiddle2Link", ("righthandmiddle2", "rmiddle2")),
        ("RightHandMiddle3Link", ("righthandmiddle3", "rmiddle3")),
        ("RightHandMiddle4Link", ("righthandmiddle4", "rmiddle4")),
        ("RightHandRing1Link", ("righthandring1", "rring1")),
        ("RightHandRing2Link", ("righthandring2", "rring2")),
        ("RightHandRing3Link", ("righthandring3", "rring3")),
        ("RightHandRing4Link", ("righthandring4", "rring4")),
        ("RightHandPinky1Link", ("righthandpinky1", "rpinky1")),
        ("RightHandPinky2Link", ("righthandpinky2", "rpinky2")),
        ("RightHandPinky3Link", ("righthandpinky3", "rpinky3")),
        ("RightHandPinky4Link", ("righthandpinky4", "rpinky4")),
    ]
)

ROLL_LINK_SLOTS = tuple(slot_name for slot_name in CHARACTER_SLOT_CANDIDATES if "RollLink" in slot_name)
RETARGET_OPTIONAL_MATCH_SLOTS = tuple(
    ["Spine{0}Link".format(index) for index in range(1, 10)]
    + ["Neck1Link", "Neck2Link"]
)

_TOOL = None
_QT_TOOL = None
_QT_DOCK = None
_QT_LAUNCHER_TOOLBAR = None
_QT_LAUNCHER_ACTION = None
_QT_TOOLTIP_FILTER = None
_QT_RICH_TOOLTIP = None
_QT_TOOLTIP_LAST_TEXT = ""
_QT_TOOLTIP_LAST_SHOWN_AT = 0.0
_TOAST = None
_TOAST_QUEUE = []
_TOAST_ACTIVE = False
_WARNING_LAST_SHOWN = {}
_WARNING_HISTORY = []
_STATUS_LINES = []
_CALLBACKS_INSTALLED = False
_PROP_MARKER_BASE_NAME = DEFAULT_PROP_MARKER_BASE_NAME
_SKELETON_SCOPE_ROOT_NAME = ""
_ACTIVE_THEME = DEFAULT_THEME_KEY
_APP_THEME_BASELINE = None
_APP_THEME_OWNED = False
_APP_THEME_BASELINE_PALETTE = None
_APP_THEME_BASELINE_STYLE = None
APP_BASELINE_STYLESHEET_ATTR = "_aminate_mobu_baseline_stylesheet"
APP_BASELINE_PALETTE_ATTR = "_aminate_mobu_baseline_palette"
APP_BASELINE_STYLE_ATTR = "_aminate_mobu_baseline_style"
DEFAULT_UI_SNAPSHOT_FILENAME = "motionbuilder_default_ui_snapshot.json"


def _now():
    return time.time()


def _safe_caption(text):
    return str(text or "").strip()


def _module_root_dir():
    return os.path.dirname(os.path.abspath(__file__))


def _user_data_dir():
    path = os.path.join(os.path.expanduser("~"), "Documents", "MB", "AminateMobu")
    os.makedirs(path, exist_ok=True)
    return path


def _definition_store_path():
    return os.path.join(_user_data_dir(), "character_definitions.json")


def _default_ui_snapshot_path():
    return os.path.join(_module_root_dir(), DEFAULT_UI_SNAPSHOT_FILENAME)


def _byte_array_to_base64(value):
    if value is None:
        return ""
    try:
        return bytes(value.toBase64()).decode("ascii")
    except Exception:
        try:
            return base64.b64encode(bytes(value)).decode("ascii")
        except Exception:
            return ""


def _byte_array_from_base64(text):
    if not text or QtCore is None:
        return None
    try:
        return QtCore.QByteArray.fromBase64(text.encode("ascii"))
    except Exception:
        try:
            data = base64.b64decode(text.encode("ascii"))
            payload = QtCore.QByteArray()
            payload.append(data)
            return payload
        except Exception:
            return None


def capture_current_ui_snapshot(main=None, snapshot_path=None):
    main = main or _qt_host_main_window()
    if main is None:
        return None
    if not hasattr(main, "saveState") or not hasattr(main, "saveGeometry"):
        return None
    app = _qt_application()
    theme_key = get_active_theme()
    snapshot = {
        "version": 1,
        "captured_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "theme_key_at_capture": theme_key,
        "window_title": _safe_caption(getattr(main, "windowTitle", lambda: "")()),
        "app_stylesheet_length": len((app.styleSheet() or "")) if app is not None else 0,
        "layout_only": True,
        "geometry_b64": _byte_array_to_base64(main.saveGeometry()),
        "state_b64": _byte_array_to_base64(main.saveState()),
    }
    snapshot_path = snapshot_path or _default_ui_snapshot_path()
    with open(snapshot_path, "w", encoding="utf-8") as handle:
        json.dump(snapshot, handle, indent=2)
    return snapshot_path


def ensure_default_ui_snapshot(main=None, force=False):
    snapshot_path = _default_ui_snapshot_path()
    if not force and os.path.isfile(snapshot_path):
        return snapshot_path
    return capture_current_ui_snapshot(main=main, snapshot_path=snapshot_path)


def ensure_native_default_ui_snapshot(main=None, force=False):
    app = _qt_application()
    current_stylesheet = app.styleSheet() if app is not None else ""
    if _APP_THEME_OWNED or _theme_string_is_modern(current_stylesheet):
        return _default_ui_snapshot_path() if os.path.isfile(_default_ui_snapshot_path()) else None
    return ensure_default_ui_snapshot(main=main, force=force)


def _restore_saved_ui_snapshot(main=None, snapshot_path=None):
    main = main or _qt_host_main_window()
    if main is None:
        return False
    snapshot_path = snapshot_path or _default_ui_snapshot_path()
    if not os.path.isfile(snapshot_path):
        return False
    try:
        with open(snapshot_path, "r", encoding="utf-8") as handle:
            snapshot = json.load(handle)
    except Exception:
        return False
    restored = False
    geometry = _byte_array_from_base64(snapshot.get("geometry_b64", ""))
    state = _byte_array_from_base64(snapshot.get("state_b64", ""))
    try:
        if geometry is not None and not geometry.isEmpty() and hasattr(main, "restoreGeometry"):
            restored = bool(main.restoreGeometry(geometry)) or restored
    except Exception:
        pass
    try:
        if state is not None and not state.isEmpty() and hasattr(main, "restoreState"):
            restored = bool(main.restoreState(state)) or restored
    except Exception:
        pass
    return restored


def _component_short_name(component):
    if component is None:
        return ""
    return str(getattr(component, "Name", "") or getattr(component, "LongName", "") or "")


def _component_long_name(component):
    if component is None:
        return ""
    return str(getattr(component, "LongName", "") or getattr(component, "Name", "") or "")


def _namespace_from_long_name(long_name):
    text = str(long_name or "")
    if ":" not in text:
        return ""
    return text.split(":", 1)[0]


def _short_name_from_long_name(long_name):
    text = str(long_name or "")
    if ":" not in text:
        return text
    return text.split(":")[-1]


def _normalize_name(name):
    return re.sub(r"[^a-z0-9]+", "", str(name or "").lower())


def _sanitize_prop_marker_base_name(name):
    cleaned = re.sub(r"[^A-Za-z0-9]+", "_", str(name or "").strip()).strip("_")
    return cleaned or DEFAULT_PROP_MARKER_BASE_NAME


def get_prop_marker_base_name():
    return _PROP_MARKER_BASE_NAME


def set_prop_marker_base_name(name):
    global _PROP_MARKER_BASE_NAME
    clean_name = _sanitize_prop_marker_base_name(name)
    _PROP_MARKER_BASE_NAME = clean_name
    return clean_name


def _is_dummy_name(name):
    clean = _normalize_name(name)
    return clean.endswith("dummy") or clean.endswith("end")


def _name_tokens(name):
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(name or ""))
    tokens = [item.lower() for item in re.split(r"[^A-Za-z0-9]+", text) if item]
    return [item for item in tokens if item not in ("mixamorig", "bip", "bone", "joint", "skel", "jnt")]


def _side_from_tokens(tokens, normalized):
    token_set = set(tokens)
    if token_set.intersection(("left", "l")) or normalized.startswith("left") or normalized.endswith("left"):
        return "left"
    if token_set.intersection(("right", "r")) or normalized.startswith("right") or normalized.endswith("right"):
        return "right"
    return ""


def _slot_side(slot_name):
    if slot_name.startswith("Left"):
        return "left"
    if slot_name.startswith("Right"):
        return "right"
    return ""


def _slot_number(slot_name):
    match = re.search(r"(\d+)Link$", slot_name)
    return int(match.group(1)) if match else None


def _token_has_number(tokens, number):
    if number is None:
        return True
    wanted = str(number)
    padded = "0{0}".format(number)
    return any(item == wanted or item == padded or item.endswith(wanted) for item in tokens)


def _auto_map_slot_terms(slot_name):
    base = slot_name.replace("Left", "").replace("Right", "")
    base = re.sub(r"\d+Link$", "Link", base)
    terms = {
        "ReferenceLink": ("reference", "root"),
        "HipsLink": ("hips", "hip", "pelvis"),
        "HipsTranslationLink": ("hips", "hip", "pelvis"),
        "SpineLink": ("spine", "waist"),
        "NeckLink": ("neck",),
        "HeadLink": ("head",),
        "ShoulderLink": ("shoulder", "clavicle", "collar"),
        "ArmLink": ("upperarm", "uparm", "arm"),
        "ArmRollLink": ("upperarmtwist", "upperarmroll", "uparmtwist", "twist"),
        "ForeArmLink": ("lowerarm", "forearm", "loarm"),
        "ForeArmRollLink": ("lowerarmtwist", "forearmtwist", "lowerarmroll", "twist"),
        "HandLink": ("hand", "wrist"),
        "UpLegLink": ("upleg", "upperleg", "thigh"),
        "UpLegRollLink": ("thightwist", "uplegtwist", "upperlegtwist", "thighroll", "twist"),
        "LegLink": ("leg", "lowerleg", "calf", "shin"),
        "LegRollLink": ("calftwist", "legtwist", "lowerlegtwist", "calfroll", "twist"),
        "FootLink": ("foot", "ankle"),
        "ToeBaseLink": ("toebase", "toe", "ball"),
        "HandThumbLink": ("thumb",),
        "HandIndexLink": ("index", "pointer"),
        "HandMiddleLink": ("middle",),
        "HandRingLink": ("ring",),
        "HandPinkyLink": ("pinky", "little"),
    }
    if "Thumb" in slot_name:
        return terms["HandThumbLink"]
    if "Index" in slot_name:
        return terms["HandIndexLink"]
    if "Middle" in slot_name:
        return terms["HandMiddleLink"]
    if "Ring" in slot_name:
        return terms["HandRingLink"]
    if "Pinky" in slot_name:
        return terms["HandPinkyLink"]
    return terms.get(base, ())


def _candidate_slot_score(slot_name, normalized_name, model):
    short_name = _short_name_from_long_name(_component_long_name(model))
    tokens = _name_tokens(short_name)
    token_set = set(tokens)
    side = _slot_side(slot_name)
    if side and _side_from_tokens(tokens, normalized_name) != side:
        return 0
    if not side and _side_from_tokens(tokens, normalized_name):
        return 0

    score = 0
    for candidate in CHARACTER_SLOT_CANDIDATES.get(slot_name, ()):
        candidate_norm = _normalize_name(candidate)
        if normalized_name == candidate_norm:
            score = max(score, 100)
        elif normalized_name.endswith(candidate_norm) or normalized_name.startswith(candidate_norm):
            score = max(score, 75)

    terms = _auto_map_slot_terms(slot_name)
    compact_tokens = {_normalize_name(item) for item in tokens}
    for term in terms:
        term_norm = _normalize_name(term)
        if term_norm in compact_tokens:
            score = max(score, 70 if len(term_norm) > 5 else 60)
        elif term_norm in normalized_name:
            score = max(score, 85 if len(term_norm) > 5 else 60)

    if score <= 0:
        return 0

    number = _slot_number(slot_name)
    finger_slot = any(name in slot_name for name in ("Thumb", "Index", "Middle", "Ring", "Pinky"))
    if finger_slot and not _token_has_number(tokens, number):
        return 0
    if finger_slot and "metacarpal" in token_set:
        score -= 20
    if "RollLink" in slot_name and not ("twist" in normalized_name or "roll" in normalized_name):
        return 0
    if "RollLink" not in slot_name and ("twist" in normalized_name or "roll" in normalized_name):
        score -= 25
    if "ToeBaseLink" in slot_name and "ik" in token_set:
        return 0
    if slot_name in ("ReferenceLink", "HipsLink", "HipsTranslationLink") and "ik" in token_set:
        return 0
    if "Spine" in slot_name:
        number = _slot_number(slot_name)
        if number is None:
            if any(item in token_set for item in ("01", "1")):
                score += 15
        elif _token_has_number(tokens, number):
            score += 15
        else:
            score -= 25
    if "RollLink" in slot_name:
        if any(item in token_set for item in ("01", "1")):
            score += 8
        if any(item in token_set for item in ("02", "2")):
            score -= 2
    if side:
        score += 10
    return score


def _qt_object_is_valid(value):
    if value is None:
        return False
    if shiboken_is_valid is None:
        return True
    try:
        return bool(shiboken_is_valid(value))
    except Exception:
        return False


def _qt_main_window():
    if QtWidgets is None:
        return None
    app = QtWidgets.QApplication.instance()
    if app is None:
        return None
    active = app.activeWindow()
    if _qt_object_is_valid(active):
        return active
    for widget in app.topLevelWidgets():
        if not _qt_object_is_valid(widget):
            continue
        title = widget.windowTitle() or ""
        if "MotionBuilder" in title:
            return widget
    widgets = app.topLevelWidgets()
    for widget in widgets:
        if _qt_object_is_valid(widget):
            return widget
    return None


def _qt_host_main_window():
    if QtWidgets is None:
        return None
    app = QtWidgets.QApplication.instance()
    if app is None:
        return None
    for widget in app.topLevelWidgets():
        if not _qt_object_is_valid(widget):
            continue
        try:
            if hasattr(widget, "addDockWidget") and "MotionBuilder" in (widget.windowTitle() or ""):
                return widget
        except Exception:
            continue
    active = app.activeWindow()
    if _qt_object_is_valid(active) and hasattr(active, "addDockWidget"):
        return active
    return None


def _existing_aminate_mobu_docks():
    if QtWidgets is None:
        return []
    main = _qt_host_main_window()
    if main is None:
        return []
    docks = []
    for widget in main.findChildren(QtWidgets.QDockWidget):
        if not _qt_object_is_valid(widget):
            continue
        try:
            if widget.objectName() == QT_DOCK_OBJECT_NAME:
                docks.append(widget)
        except Exception:
            continue
    return docks


def _close_duplicate_aminate_mobu_docks(keep_dock=None):
    for widget in _existing_aminate_mobu_docks():
        if keep_dock is not None and widget is keep_dock:
            continue
        try:
            widget.close()
        except Exception:
            pass


def _existing_aminate_launcher_toolbars():
    if QtWidgets is None:
        return []
    main = _qt_host_main_window()
    if main is None:
        return []
    toolbars = []
    for widget in main.findChildren(QtWidgets.QToolBar):
        if not _qt_object_is_valid(widget):
            continue
        try:
            if widget.objectName() == QT_LAUNCHER_TOOLBAR_OBJECT_NAME:
                toolbars.append(widget)
        except Exception:
            continue
    return toolbars


def _close_duplicate_aminate_launcher_toolbars(keep_toolbar=None):
    for widget in _existing_aminate_launcher_toolbars():
        if keep_toolbar is not None and widget is keep_toolbar:
            continue
        try:
            widget.hide()
        except Exception:
            pass
        try:
            widget.deleteLater()
        except Exception:
            pass


def _qt_application():
    if QtWidgets is None:
        return None
    return QtWidgets.QApplication.instance()


def _theme_string_is_modern(stylesheet):
    return (stylesheet or "").strip() == _app_theme_stylesheet(THEME_MODERN).strip()


def _sync_baseline_from_app_cache(app=None):
    global _APP_THEME_BASELINE, _APP_THEME_BASELINE_PALETTE, _APP_THEME_BASELINE_STYLE
    app = app or _qt_application()
    if app is None:
        return False
    changed = False
    try:
        cached_stylesheet = getattr(app, APP_BASELINE_STYLESHEET_ATTR, None)
        if cached_stylesheet is not None and _APP_THEME_BASELINE is None:
            _APP_THEME_BASELINE = cached_stylesheet
            changed = True
    except Exception:
        pass
    try:
        cached_palette = getattr(app, APP_BASELINE_PALETTE_ATTR, None)
        if cached_palette is not None and _APP_THEME_BASELINE_PALETTE is None:
            _APP_THEME_BASELINE_PALETTE = _copy_palette(cached_palette)
            changed = True
    except Exception:
        pass
    try:
        cached_style = getattr(app, APP_BASELINE_STYLE_ATTR, None)
        if cached_style is not None and _APP_THEME_BASELINE_STYLE is None:
            _APP_THEME_BASELINE_STYLE = cached_style
            changed = True
    except Exception:
        pass
    return changed


def _store_baseline_on_app(app=None):
    app = app or _qt_application()
    if app is None:
        return False
    try:
        setattr(app, APP_BASELINE_STYLESHEET_ATTR, _APP_THEME_BASELINE)
    except Exception:
        pass
    try:
        setattr(app, APP_BASELINE_PALETTE_ATTR, _copy_palette(_APP_THEME_BASELINE_PALETTE))
    except Exception:
        pass
    try:
        setattr(app, APP_BASELINE_STYLE_ATTR, _APP_THEME_BASELINE_STYLE)
    except Exception:
        pass
    return True


def _reset_to_best_effort_native(app):
    if app is None:
        return False
    try:
        app.setStyleSheet("")
    except Exception:
        pass
    try:
        style = app.style()
        if style is not None:
            app.setPalette(style.standardPalette())
    except Exception:
        pass
    return True


def prime_app_theme_baseline(force_reset=False):
    global _APP_THEME_BASELINE, _APP_THEME_BASELINE_PALETTE, _APP_THEME_BASELINE_STYLE
    app = _qt_application()
    if app is None:
        return False
    _sync_baseline_from_app_cache(app)
    if not force_reset and _APP_THEME_BASELINE is not None and _APP_THEME_BASELINE_PALETTE is not None:
        return True
    current_stylesheet = app.styleSheet() or ""
    if _theme_string_is_modern(current_stylesheet) and not force_reset:
        return False
    if force_reset:
        _reset_to_best_effort_native(app)
        current_stylesheet = app.styleSheet() or ""
    _APP_THEME_BASELINE = current_stylesheet
    _APP_THEME_BASELINE_PALETTE = _copy_palette(app.palette())
    try:
        _APP_THEME_BASELINE_STYLE = app.style().objectName()
    except Exception:
        _APP_THEME_BASELINE_STYLE = None
    _store_baseline_on_app(app)
    return True


def _clean_tooltip_key(text):
    if not text:
        return ""
    cleaned = re.sub(r"<[^>]+>", " ", str(text))
    cleaned = cleaned.replace("&nbsp;", " ").replace("&amp;", "&")
    cleaned = re.sub(r"\s+", " ", cleaned.replace("&", " ")).strip()
    if " - " in cleaned:
        cleaned = cleaned.split(" - ", 1)[0].strip()
    while cleaned.endswith(":"):
        cleaned = cleaned[:-1].rstrip()
    return cleaned


def _tooltip_sentence(text):
    cleaned = re.sub(r"<[^>]+>", " ", str(text or ""))
    cleaned = cleaned.replace("&nbsp;", " ").replace("&amp;", "&")
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def _format_easy_tooltip(title, body):
    title = _clean_tooltip_key(title) or "Help"
    body = _tooltip_sentence(body)
    if not body:
        return None
    if body.lower().startswith((title + " -").lower()):
        return body
    if len(body) > 170:
        body = body[:167].rstrip() + "..."
    return "{0} - {1}".format(title, body)


def _easy_tooltip_text(text, class_name=""):
    key = _clean_tooltip_key(text)
    if not key:
        return None
    lower_key = key.lower()
    if lower_key in ("0", "zero"):
        return _format_easy_tooltip("Zero", EASY_TOOLTIP_TEXT["Zero"])
    if key in EASY_TOOLTIP_TEXT:
        return _format_easy_tooltip(key, EASY_TOOLTIP_TEXT[key])
    if re.match(r"take\s+\d+", lower_key):
        return _format_easy_tooltip(key, "This is the active take, which stores one version of your animation.")
    if re.match(r"animlayer\d+", key):
        return _format_easy_tooltip(key, "This animation layer stores one stack of keys on top of the base animation.")
    if lower_key == "none":
        return _format_easy_tooltip(key, "Nothing is set here yet.")
    if "version" in lower_key and "beta" in lower_key:
        return _format_easy_tooltip(key, "This shows which Aminate Mobu build is loaded.")
    if "auto" in lower_key and "key" in lower_key:
        return _format_easy_tooltip(key, EASY_TOOLTIP_TEXT["Auto Key"])
    if "delete" in lower_key and "key" in lower_key:
        return _format_easy_tooltip("Delete Key", EASY_TOOLTIP_TEXT["Delete Key"])
    if "remove" in lower_key and "key" in lower_key:
        return _format_easy_tooltip("Delete Key", EASY_TOOLTIP_TEXT["Delete Key"])
    if "flat" in lower_key:
        return _format_easy_tooltip("Flat", EASY_TOOLTIP_TEXT["Flat"])
    if "disc" in lower_key or "discontinu" in lower_key:
        return _format_easy_tooltip("Discontinuity", EASY_TOOLTIP_TEXT["Discontinuity"])
    if "plot" in lower_key:
        return _format_easy_tooltip("Plot", EASY_TOOLTIP_TEXT["Plot"])
    if "bake" in lower_key:
        return _format_easy_tooltip("Bake", EASY_TOOLTIP_TEXT["Bake"])
    if "play" in lower_key and "back" in lower_key:
        return _format_easy_tooltip(key, "Starts or stops playback so you can review motion in time.")
    if "key" in lower_key and ("frame" in lower_key or class_name in ("QPushButton", "QToolButton", "QAction")):
        return _format_easy_tooltip(key, "Adds or edits animation keys at the current time.")
    if class_name == "QPushButton":
        return _format_easy_tooltip(key, "Click this button to run {0}.".format(lower_key))
    if class_name == "QToolButton":
        return _format_easy_tooltip(key, "Click this small tool button to open or use {0}.".format(lower_key))
    if class_name == "QAction":
        return _format_easy_tooltip(key, "Open {0} options or run that command.".format(lower_key))
    if class_name == "QMenu":
        return _format_easy_tooltip(key, "Open this menu to find {0} commands.".format(lower_key))
    if class_name == "QGroupBox":
        return _format_easy_tooltip(key, "This section groups controls for {0}.".format(lower_key))
    if class_name == "QTabBar":
        return _format_easy_tooltip(key, "Open this tab to see {0} tools.".format(lower_key))
    if class_name == "QLabel":
        return _format_easy_tooltip(key, "This label shows {0}.".format(lower_key))
    return None


def _tooltip_candidates_from_action(action):
    candidates = []
    for attr in ("text", "toolTip", "statusTip", "whatsThis"):
        try:
            value = getattr(action, attr)()
        except Exception:
            value = None
        if value:
            candidates.append(value)
    return candidates


def _tooltip_candidates_from_widget(widget):
    candidates = []
    try:
        default_action = widget.defaultAction()
    except Exception:
        default_action = None
    if default_action is not None:
        candidates.extend(_tooltip_candidates_from_action(default_action))
    for attr in ("text", "title", "windowTitle", "placeholderText", "accessibleName", "toolTip", "statusTip", "whatsThis", "objectName"):
        try:
            value = getattr(widget, attr)()
        except Exception:
            value = None
        if value:
            candidates.append(value)
    try:
        parent = widget.parentWidget()
    except Exception:
        parent = None
    if parent is not None:
        try:
            parent_title = parent.windowTitle() or parent.objectName()
        except Exception:
            parent_title = ""
        if parent_title:
            candidates.append(parent_title)
    return candidates


def _icon_only_context_tooltip(widget, class_name=""):
    if QtWidgets is None or widget is None:
        return None
    try:
        text = _tooltip_sentence(widget.text())
    except Exception:
        text = ""
    if text:
        return None
    candidates = " ".join(_tooltip_candidates_from_widget(widget)).lower()
    try:
        parent = widget.parentWidget()
    except Exception:
        parent = None
    parent_name = ""
    if parent is not None:
        try:
            parent_name = "{0} {1}".format(parent.metaObject().className(), parent.objectName()).lower()
        except Exception:
            parent_name = ""
    context = "{0} {1}".format(candidates, parent_name)
    if "transport" in context:
        return _format_easy_tooltip("Transport Button", "Controls playback or timeline movement. Hover near it to see play, stop, step, or jump behavior.")
    if "key" in context or "keying" in context:
        return _format_easy_tooltip("Keying Button", "Works with animation keys for the selected object or character control.")
    if "character" in context:
        return _format_easy_tooltip("Character Tool", "Changes character setup, body controls, or HumanIK character editing.")
    if "resource" in context or "navigator" in context:
        return _format_easy_tooltip("Browser Button", "Changes how this list is shown, filtered, expanded, or searched.")
    if "viewer" in context:
        return _format_easy_tooltip("Viewer Button", "Changes camera navigation, display mode, selection, or scene viewing.")
    if class_name in ("QToolButton", "QAbstractButton"):
        return _format_easy_tooltip("Tool Button", "Runs this icon tool. MotionBuilder does not expose a clearer name for this native icon.")
    return None


def _easy_tooltip_for_candidates(candidates, class_name=""):
    for candidate in candidates:
        tooltip = _easy_tooltip_text(candidate, class_name)
        if tooltip:
            return tooltip
    return None


def _split_easy_tooltip(text):
    cleaned = _tooltip_sentence(text)
    if " - " in cleaned:
        title, body = cleaned.split(" - ", 1)
    else:
        title, body = "Help", cleaned
    title = _clean_tooltip_key(title) or "Help"
    return title, body.strip()


if QtCore is not None and QtWidgets is not None:
    class AminateRichTooltip(QtWidgets.QFrame):
        def __init__(self, parent=None):
            super(AminateRichTooltip, self).__init__(parent)
            self.setWindowFlags(QtCore.Qt.ToolTip | QtCore.Qt.FramelessWindowHint)
            self.setAttribute(QtCore.Qt.WA_ShowWithoutActivating, True)
            self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, True)
            self.setObjectName("aminateRichTooltip")
            self.setStyleSheet(
                """
                QFrame#aminateRichTooltip {
                    background-color: #111820;
                    color: #EAF2F8;
                    border: 1px solid #4E718A;
                    border-radius: 10px;
                }
                QLabel#aminateRichTooltipTitle {
                    color: #FFFFFF;
                    font-size: 12px;
                    font-weight: 700;
                }
                QLabel#aminateRichTooltipBody {
                    color: #C9D6E0;
                    font-size: 11px;
                    line-height: 140%;
                }
                """
            )
            layout = QtWidgets.QVBoxLayout(self)
            layout.setContentsMargins(12, 10, 12, 10)
            layout.setSpacing(4)
            self.title_label = QtWidgets.QLabel()
            self.title_label.setObjectName("aminateRichTooltipTitle")
            self.body_label = QtWidgets.QLabel()
            self.body_label.setObjectName("aminateRichTooltipBody")
            self.body_label.setWordWrap(True)
            self.body_label.setMinimumWidth(300)
            self.body_label.setMaximumWidth(360)
            layout.addWidget(self.title_label)
            layout.addWidget(self.body_label)
            self._animation_group = None

        def show_tooltip(self, text, global_pos):
            title, body = _split_easy_tooltip(text)
            if not body:
                return
            if self.isVisible() and self.title_label.text() == title and self.body_label.text() == body:
                return
            self.title_label.setText(title)
            self.body_label.setText(body)
            self.adjustSize()
            width = min(max(self.width(), 280), 390)
            height = self.height()
            try:
                screen = QtWidgets.QApplication.screenAt(global_pos)
            except Exception:
                screen = None
            primary = QtWidgets.QApplication.primaryScreen()
            geometry = screen.availableGeometry() if screen else primary.availableGeometry()
            x = min(global_pos.x() + 18, geometry.right() - width - 8)
            y = min(global_pos.y() + 20, geometry.bottom() - height - 8)
            x = max(geometry.left() + 8, x)
            y = max(geometry.top() + 8, y)
            end_rect = QtCore.QRect(x, y, width, height)
            start_rect = QtCore.QRect(x + 12, y + 8, max(120, int(width * 0.72)), max(40, int(height * 0.65)))
            self.setGeometry(start_rect)
            self.setWindowOpacity(0.0)
            self.show()
            self.raise_()
            self._animation_group = QtCore.QParallelAnimationGroup(self)
            opacity_anim = QtCore.QPropertyAnimation(self, b"windowOpacity")
            opacity_anim.setDuration(130)
            opacity_anim.setStartValue(0.0)
            opacity_anim.setEndValue(1.0)
            geometry_anim = QtCore.QPropertyAnimation(self, b"geometry")
            geometry_anim.setDuration(150)
            geometry_anim.setEasingCurve(QtCore.QEasingCurve.OutCubic)
            geometry_anim.setStartValue(start_rect)
            geometry_anim.setEndValue(end_rect)
            self._animation_group.addAnimation(opacity_anim)
            self._animation_group.addAnimation(geometry_anim)
            self._animation_group.start(QtCore.QAbstractAnimation.DeleteWhenStopped)
            QtCore.QTimer.singleShot(7000, self.hide)


def _show_rich_tooltip(text, global_pos):
    global _QT_RICH_TOOLTIP, _QT_TOOLTIP_LAST_TEXT, _QT_TOOLTIP_LAST_SHOWN_AT
    if QtWidgets is None or QtCore is None or not text:
        return False
    app = _qt_application()
    if app is None:
        return False
    try:
        now = _now()
        if text == _QT_TOOLTIP_LAST_TEXT and now - _QT_TOOLTIP_LAST_SHOWN_AT < 0.35:
            return True
        _QT_TOOLTIP_LAST_TEXT = text
        _QT_TOOLTIP_LAST_SHOWN_AT = now
        if _QT_RICH_TOOLTIP is None:
            _QT_RICH_TOOLTIP = AminateRichTooltip()
        _QT_RICH_TOOLTIP.show_tooltip(text, global_pos)
        return True
    except Exception:
        return False


def _hide_rich_tooltip():
    try:
        if _QT_RICH_TOOLTIP is not None:
            _QT_RICH_TOOLTIP.hide()
    except Exception:
        pass


def _apply_easy_tooltip_to_action(action):
    if action is None:
        return False
    tooltip = _easy_tooltip_for_candidates(_tooltip_candidates_from_action(action), "QAction")
    if not tooltip:
        return False
    changed = False
    try:
        if action.toolTip() != tooltip:
            action.setToolTip(tooltip)
            changed = True
    except Exception:
        pass
    try:
        if action.statusTip() != tooltip:
            action.setStatusTip(tooltip)
            changed = True
    except Exception:
        pass
    try:
        action.setProperty("aminateEasyTooltip", tooltip)
    except Exception:
        pass
    return changed


def _extract_widget_text(widget):
    for attr in ("text", "title", "windowTitle", "placeholderText"):
        try:
            value = getattr(widget, attr)()
        except Exception:
            value = None
        if value:
            return value
    try:
        value = widget.accessibleName()
    except Exception:
        value = None
    return value or ""


def _apply_easy_tooltip_to_widget(widget):
    if widget is None or QtWidgets is None:
        return False
    if shiboken_is_valid is not None:
        try:
            if not shiboken_is_valid(widget):
                return False
        except Exception:
            return False
    class_name = widget.metaObject().className() if hasattr(widget, "metaObject") else widget.__class__.__name__
    if isinstance(widget, QtWidgets.QTabBar):
        changed = False
        for index in range(widget.count()):
            tooltip = _easy_tooltip_text(widget.tabText(index), "QTabBar")
            if not tooltip:
                continue
            try:
                if widget.tabToolTip(index) != tooltip:
                    widget.setTabToolTip(index, tooltip)
                    changed = True
            except Exception:
                continue
        return changed
    tooltip = _easy_tooltip_for_candidates(_tooltip_candidates_from_widget(widget), class_name)
    if not tooltip:
        tooltip = _icon_only_context_tooltip(widget, class_name)
    if not tooltip:
        if isinstance(widget, QtWidgets.QLineEdit):
            tooltip = _format_easy_tooltip("Text Field", "Type text here. This changes the value used by the tool.")
        elif isinstance(widget, QtWidgets.QComboBox):
            tooltip = _format_easy_tooltip("Dropdown", "Choose one option from this list.")
        elif isinstance(widget, QtWidgets.QPlainTextEdit):
            tooltip = _format_easy_tooltip("Text Area", "This area shows detailed output or notes.")
        elif isinstance(widget, (QtWidgets.QTableWidget, QtWidgets.QTreeWidget, QtWidgets.QListWidget)):
            tooltip = _format_easy_tooltip("List", "Select an item here to view or edit that part of the scene.")
    if not tooltip:
        return False
    changed = False
    try:
        if widget.toolTip() != tooltip:
            widget.setToolTip(tooltip)
            changed = True
    except Exception:
        pass
    try:
        if hasattr(widget, "setStatusTip") and widget.statusTip() != tooltip:
            widget.setStatusTip(tooltip)
            changed = True
    except Exception:
        pass
    try:
        widget.setProperty("aminateEasyTooltip", tooltip)
    except Exception:
        pass
    try:
        for action in widget.actions():
            _apply_easy_tooltip_to_action(action)
    except Exception:
        pass
    return changed


def refresh_easy_motionbuilder_tooltips():
    app = _qt_application()
    if QtWidgets is None or app is None:
        return 0
    touched = 0
    try:
        widgets = list(app.allWidgets())
    except Exception:
        widgets = []
    for widget in widgets:
        if shiboken_is_valid is not None:
            try:
                if not shiboken_is_valid(widget):
                    continue
            except Exception:
                continue
        try:
            touched += int(_apply_easy_tooltip_to_widget(widget))
        except Exception:
            continue
        try:
            for action in widget.actions():
                if shiboken_is_valid is not None:
                    try:
                        if not shiboken_is_valid(action):
                            continue
                    except Exception:
                        continue
                touched += int(_apply_easy_tooltip_to_action(action))
        except Exception:
            pass
    main = _qt_host_main_window()
    if QtGui is not None and main is not None:
        try:
            for action in main.findChildren(QtGui.QAction):
                if shiboken_is_valid is not None:
                    try:
                        if not shiboken_is_valid(action):
                            continue
                    except Exception:
                        continue
                touched += int(_apply_easy_tooltip_to_action(action))
        except Exception:
            pass
    return touched


if QtCore is not None and QtWidgets is not None:
    class MotionBuilderEasyTooltipFilter(QtCore.QObject):
        def eventFilter(self, watched, event):
            try:
                if watched is not None and event is not None:
                    if event.type() in (
                        QtCore.QEvent.Leave,
                        QtCore.QEvent.MouseButtonPress,
                        QtCore.QEvent.WindowDeactivate,
                        QtCore.QEvent.Hide,
                    ):
                        _hide_rich_tooltip()
                    if event.type() in (
                        QtCore.QEvent.Show,
                        QtCore.QEvent.Polish,
                    ):
                        if QtGui is not None and isinstance(watched, QtGui.QAction):
                            _apply_easy_tooltip_to_action(watched)
                        elif isinstance(watched, QtWidgets.QWidget):
                            _apply_easy_tooltip_to_widget(watched)
                    if event.type() == QtCore.QEvent.ToolTip and isinstance(watched, QtWidgets.QWidget):
                        _apply_easy_tooltip_to_widget(watched)
                        tooltip = ""
                        try:
                            tooltip = watched.property("aminateEasyTooltip") or watched.toolTip()
                        except Exception:
                            tooltip = ""
                        if tooltip:
                            global_pos = event.globalPos() if hasattr(event, "globalPos") else watched.mapToGlobal(QtCore.QPoint(0, 0))
                            if _show_rich_tooltip(tooltip, global_pos):
                                event.accept()
                                return True
            except Exception:
                pass
            return False


def install_easy_motionbuilder_tooltips():
    global _QT_TOOLTIP_FILTER
    app = _qt_application()
    if app is None or QtCore is None or QtWidgets is None:
        return 0
    if _QT_TOOLTIP_FILTER is None:
        try:
            _QT_TOOLTIP_FILTER = MotionBuilderEasyTooltipFilter(app)
            app.installEventFilter(_QT_TOOLTIP_FILTER)
        except Exception:
            _QT_TOOLTIP_FILTER = None
    return refresh_easy_motionbuilder_tooltips()


def _copy_palette(palette):
    if QtGui is None or palette is None:
        return None
    try:
        return QtGui.QPalette(palette)
    except Exception:
        return None


def _palette_role_signature(palette):
    if QtGui is None or palette is None:
        return None
    groups = (
        QtGui.QPalette.Active,
        QtGui.QPalette.Inactive,
        QtGui.QPalette.Disabled,
    )
    role_names = (
        "Window",
        "WindowText",
        "Base",
        "AlternateBase",
        "Text",
        "Button",
        "ButtonText",
        "BrightText",
        "Highlight",
        "HighlightedText",
        "ToolTipBase",
        "ToolTipText",
        "Link",
        "LinkVisited",
    )
    roles = [getattr(QtGui.QPalette, name) for name in role_names if hasattr(QtGui.QPalette, name)]
    return tuple(int(palette.color(group, role).rgba()) for group in groups for role in roles)


def _palettes_match(first, second):
    return _palette_role_signature(first) == _palette_role_signature(second)


def _make_motionbuilder_dark_palette():
    if QtGui is None:
        return None
    palette = QtGui.QPalette()
    colors = {
        QtGui.QPalette.Window: QtGui.QColor("#3A3F44"),
        QtGui.QPalette.WindowText: QtGui.QColor("#EEF2F5"),
        QtGui.QPalette.Base: QtGui.QColor("#2E3338"),
        QtGui.QPalette.AlternateBase: QtGui.QColor("#383D42"),
        QtGui.QPalette.ToolTipBase: QtGui.QColor("#3F454A"),
        QtGui.QPalette.ToolTipText: QtGui.QColor("#F4F7F9"),
        QtGui.QPalette.Text: QtGui.QColor("#EEF2F5"),
        QtGui.QPalette.Button: QtGui.QColor("#4D5359"),
        QtGui.QPalette.ButtonText: QtGui.QColor("#F2F5F7"),
        QtGui.QPalette.BrightText: QtGui.QColor("#FFFFFF"),
        QtGui.QPalette.Highlight: QtGui.QColor("#6A7D8D"),
        QtGui.QPalette.HighlightedText: QtGui.QColor("#FFFFFF"),
        QtGui.QPalette.Light: QtGui.QColor("#5E656C"),
        QtGui.QPalette.Midlight: QtGui.QColor("#535A61"),
        QtGui.QPalette.Mid: QtGui.QColor("#454B51"),
        QtGui.QPalette.Dark: QtGui.QColor("#2D3135"),
        QtGui.QPalette.Shadow: QtGui.QColor("#202428"),
        QtGui.QPalette.Link: QtGui.QColor("#9AB7D2"),
        QtGui.QPalette.LinkVisited: QtGui.QColor("#B6C6D6"),
        QtGui.QPalette.PlaceholderText: QtGui.QColor("#AAB2BA"),
    }
    for role, color in colors.items():
        try:
            palette.setColor(role, color)
        except Exception:
            pass
    try:
        disabled_text = QtGui.QColor("#858B91")
        disabled_bg = QtGui.QColor("#373C41")
        palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, disabled_text)
        palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Text, disabled_text)
        palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, disabled_text)
        palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Button, disabled_bg)
        palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Base, QtGui.QColor("#30353A"))
    except Exception:
        pass
    return palette


def _make_modern_dark_palette():
    if QtGui is None:
        return None
    palette = QtGui.QPalette()
    colors = {
        QtGui.QPalette.Window: QtGui.QColor("#25303A"),
        QtGui.QPalette.WindowText: QtGui.QColor("#DEE4EA"),
        QtGui.QPalette.Base: QtGui.QColor("#182128"),
        QtGui.QPalette.AlternateBase: QtGui.QColor("#242D35"),
        QtGui.QPalette.ToolTipBase: QtGui.QColor("#242D35"),
        QtGui.QPalette.ToolTipText: QtGui.QColor("#F0F4F7"),
        QtGui.QPalette.Text: QtGui.QColor("#E1E7EC"),
        QtGui.QPalette.Button: QtGui.QColor("#2D3741"),
        QtGui.QPalette.ButtonText: QtGui.QColor("#EDF2F5"),
        QtGui.QPalette.BrightText: QtGui.QColor("#FFFFFF"),
        QtGui.QPalette.Highlight: QtGui.QColor("#4B667E"),
        QtGui.QPalette.HighlightedText: QtGui.QColor("#F4F7F9"),
        QtGui.QPalette.Light: QtGui.QColor("#3A4957"),
        QtGui.QPalette.Midlight: QtGui.QColor("#344250"),
        QtGui.QPalette.Mid: QtGui.QColor("#2D3945"),
        QtGui.QPalette.Dark: QtGui.QColor("#141C23"),
        QtGui.QPalette.Shadow: QtGui.QColor("#10161B"),
        QtGui.QPalette.Link: QtGui.QColor("#85A7C0"),
        QtGui.QPalette.LinkVisited: QtGui.QColor("#A1B8C9"),
        QtGui.QPalette.PlaceholderText: QtGui.QColor("#7A8691"),
    }
    for role, color in colors.items():
        try:
            palette.setColor(role, color)
        except Exception:
            pass
    try:
        disabled_text = QtGui.QColor("#717D88")
        disabled_bg = QtGui.QColor("#1D252C")
        palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, disabled_text)
        palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Text, disabled_text)
        palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, disabled_text)
        palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Button, disabled_bg)
        palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Base, disabled_bg)
        palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Window, QtGui.QColor("#202930"))
    except Exception:
        pass
    return palette


def _refresh_qt_theme():
    app = _qt_application()
    if app is None:
        return False
    try:
        app.processEvents()
    except Exception:
        pass
    widgets = []
    try:
        widgets = list(app.topLevelWidgets())
    except Exception:
        widgets = []
    for widget in widgets:
        if not _qt_object_is_valid(widget):
            continue
        try:
            style = widget.style()
            if style is not None:
                style.unpolish(widget)
                style.polish(widget)
            widget.update()
            widget.repaint()
        except Exception:
            continue
    try:
        app.processEvents()
    except Exception:
        pass
    return True


def _normalize_theme_key(theme_key):
    return theme_key if theme_key in THEME_LABELS else DEFAULT_THEME_KEY


def get_active_theme():
    return _normalize_theme_key(_ACTIVE_THEME)


def set_active_theme(theme_key):
    global _ACTIVE_THEME
    _ACTIVE_THEME = _normalize_theme_key(theme_key)
    return _ACTIVE_THEME


def _other_theme(theme_key):
    theme_key = _normalize_theme_key(theme_key)
    return THEME_MODERN if theme_key == THEME_MOTIONBUILDER else THEME_MOTIONBUILDER


def _theme_label(theme_key):
    return THEME_LABELS[_normalize_theme_key(theme_key)]


def _theme_toggle_caption(theme_key):
    return "{0} UI".format(_theme_label(_other_theme(theme_key)))


def _theme_tooltip(theme_key):
    return "Current theme: {0}. Click to switch to {1}.".format(
        _theme_label(theme_key),
        _theme_label(_other_theme(theme_key)),
    )


def _theme_stylesheet(theme_key):
    return AMINATE_MOBU_LOCAL_STYLESHEETS[_normalize_theme_key(theme_key)]


def _app_theme_stylesheet(theme_key):
    return APP_THEME_STYLESHEETS[_normalize_theme_key(theme_key)]


def _apply_motionbuilder_host_theme(app=None):
    global _APP_THEME_OWNED
    app = app or _qt_application()
    if app is None:
        return False
    _sync_baseline_from_app_cache(app)
    if _APP_THEME_BASELINE is None or _APP_THEME_BASELINE_PALETTE is None:
        if not prime_app_theme_baseline():
            return False
    try:
        app.setPalette(_copy_palette(_APP_THEME_BASELINE_PALETTE))
    except Exception:
        return False
    try:
        app.setStyleSheet(_APP_THEME_BASELINE or "")
    except Exception:
        return False
    _APP_THEME_OWNED = False
    _refresh_qt_theme()
    return (
        (app.styleSheet() or "") == (_APP_THEME_BASELINE or "")
        and _palettes_match(app.palette(), _APP_THEME_BASELINE_PALETTE)
    )


def _restore_app_theme():
    app = _qt_application()
    return _apply_motionbuilder_host_theme(app)


def _apply_app_theme(theme_key):
    global _APP_THEME_BASELINE, _APP_THEME_OWNED, _APP_THEME_BASELINE_PALETTE, _APP_THEME_BASELINE_STYLE
    app = _qt_application()
    if app is None:
        return False
    theme_key = _normalize_theme_key(theme_key)
    prime_app_theme_baseline()
    if theme_key == THEME_MOTIONBUILDER:
        return _restore_app_theme()
    palette = _make_modern_dark_palette()
    if palette is not None:
        try:
            app.setPalette(palette)
        except Exception:
            pass
    app.setStyleSheet(_app_theme_stylesheet(theme_key))
    _APP_THEME_OWNED = True
    _refresh_qt_theme()
    return True


def _style_donate_button(button, theme_key=None):
    if not button or not QtWidgets:
        return
    theme_key = _normalize_theme_key(theme_key)
    button.setMinimumWidth(92)
    if theme_key == THEME_MOTIONBUILDER:
        button.setStyleSheet(
            """
            QPushButton {
                background-color: #D9A441;
                color: #1A1A1A;
                border: 1px solid #9A742B;
                border-radius: 3px;
                padding: 6px 14px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #E7B24A;
            }
            QPushButton:pressed {
                background-color: #C89232;
            }
            """
        )
        return
    button.setStyleSheet(
        """
        QPushButton {
            background-color: #F3C54A;
            color: #1B1B1B;
            border: 1px solid #DAAE37;
            border-radius: 12px;
            padding: 7px 15px;
            font-weight: 600;
        }
        QPushButton:hover {
            background-color: #F7D46A;
        }
        QPushButton:pressed {
            background-color: #DEB03A;
        }
        """
    )


def _on_qt_panel_destroyed(panel_id):
    global _QT_TOOL
    global _QT_DOCK
    if _QT_TOOL is not None and id(_QT_TOOL) == panel_id:
        _QT_TOOL = None
        _QT_DOCK = None


def _launcher_icon_path():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    icon_path = os.path.join(base_dir, LAUNCHER_ICON_RELATIVE_PATH)
    return icon_path if os.path.isfile(icon_path) else None


def _ensure_aminate_launcher_toolbar():
    global _QT_LAUNCHER_TOOLBAR
    global _QT_LAUNCHER_ACTION
    if QtWidgets is None or QtCore is None:
        return None
    main = _qt_host_main_window()
    if main is None or not hasattr(main, "addToolBar"):
        return None
    if not _qt_object_is_valid(_QT_LAUNCHER_TOOLBAR):
        _QT_LAUNCHER_TOOLBAR = None
        _QT_LAUNCHER_ACTION = None
    if _QT_LAUNCHER_TOOLBAR is None:
        existing = _existing_aminate_launcher_toolbars()
        if existing:
            _QT_LAUNCHER_TOOLBAR = existing[-1]
            _close_duplicate_aminate_launcher_toolbars(keep_toolbar=_QT_LAUNCHER_TOOLBAR)
    if _QT_LAUNCHER_TOOLBAR is None:
        toolbar = QtWidgets.QToolBar("Aminate")
        toolbar.setObjectName(QT_LAUNCHER_TOOLBAR_OBJECT_NAME)
        toolbar.setMovable(True)
        toolbar.setFloatable(False)
        toolbar.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        toolbar.setIconSize(QtCore.QSize(18, 18))
        action = toolbar.addAction("Aminate")
        try:
            action.triggered.connect(lambda _checked=False: launch_aminate_mobu())
        except Exception:
            pass
        try:
            action.setToolTip("Open Aminate Mobu tools.")
            action.setStatusTip("Open Aminate Mobu tools.")
        except Exception:
            pass
        icon_path = _launcher_icon_path()
        if icon_path and QtGui is not None:
            try:
                action.setIcon(QtGui.QIcon(icon_path))
            except Exception:
                pass
        widget = toolbar.widgetForAction(action)
        if widget is not None:
            widget.setObjectName(QT_LAUNCHER_BUTTON_OBJECT_NAME)
            widget.setToolTip("Open the dockable Aminate Mobu tools.")
        main.addToolBar(QtCore.Qt.TopToolBarArea, toolbar)
        _QT_LAUNCHER_TOOLBAR = toolbar
        _QT_LAUNCHER_ACTION = action
    else:
        action_list = list(_QT_LAUNCHER_TOOLBAR.actions())
        _QT_LAUNCHER_ACTION = action_list[0] if action_list else _QT_LAUNCHER_TOOLBAR.addAction("Aminate")
        try:
            _QT_LAUNCHER_ACTION.setToolTip("Open Aminate Mobu tools.")
            _QT_LAUNCHER_ACTION.setStatusTip("Open Aminate Mobu tools.")
        except Exception:
            pass
        icon_path = _launcher_icon_path()
        if icon_path and QtGui is not None:
            try:
                _QT_LAUNCHER_ACTION.setIcon(QtGui.QIcon(icon_path))
            except Exception:
                pass
        widget = _QT_LAUNCHER_TOOLBAR.widgetForAction(_QT_LAUNCHER_ACTION)
        if widget is not None:
            widget.setObjectName(QT_LAUNCHER_BUTTON_OBJECT_NAME)
            widget.setToolTip("Open the dockable Aminate Mobu tools.")
    _close_duplicate_aminate_launcher_toolbars(keep_toolbar=_QT_LAUNCHER_TOOLBAR)
    try:
        _QT_LAUNCHER_TOOLBAR.show()
    except Exception:
        pass
    return _QT_LAUNCHER_TOOLBAR


def ensure_motionbuilder_ui_entry():
    prime_app_theme_baseline()
    ensure_native_default_ui_snapshot(force=False)
    toolbar = _ensure_aminate_launcher_toolbar()
    install_easy_motionbuilder_tooltips()
    return toolbar


def discover_motionbuilder_startup_dirs(root_dir=None):
    root_dir = root_dir or MB_DOCUMENTS_ROOT
    if not os.path.isdir(root_dir):
        return []
    startup_dirs = []
    for entry in sorted(os.listdir(root_dir), reverse=True):
        version_root = os.path.join(root_dir, entry)
        if not os.path.isdir(version_root):
            continue
        if not entry.isdigit():
            continue
        startup_dir = os.path.join(version_root, "config", "PythonStartup")
        startup_dirs.append(startup_dir)
    return startup_dirs


def startup_bootstrap_path(startup_dir=None):
    if startup_dir:
        return os.path.join(startup_dir, STARTUP_BOOTSTRAP_FILENAME)
    startup_dirs = discover_motionbuilder_startup_dirs()
    target_dir = startup_dirs[0] if startup_dirs else os.path.join(MB_DOCUMENTS_ROOT, "2026", "config", "PythonStartup")
    return os.path.join(target_dir, STARTUP_BOOTSTRAP_FILENAME)


def install_motionbuilder_startup(startup_dir=None, module_root=None):
    module_root = module_root or os.path.dirname(os.path.abspath(__file__))
    target_dirs = [startup_dir] if startup_dir else discover_motionbuilder_startup_dirs()
    if not target_dirs:
        target_dirs = [os.path.join(MB_DOCUMENTS_ROOT, "2026", "config", "PythonStartup")]
    bootstrap = """from __future__ import absolute_import, division, print_function
import sys
MODULE_ROOT = r\"{module_root}\"
if MODULE_ROOT not in sys.path:
    sys.path.insert(0, MODULE_ROOT)
def _boot():
    import aminate_mobu
    aminate_mobu.launch_aminate_mobu()
try:
    from PySide6 import QtCore
except Exception:
    try:
        from PySide2 import QtCore
    except Exception:
        QtCore = None
if QtCore is not None:
    QtCore.QTimer.singleShot(250, _boot)
else:
    _boot()
""".format(module_root=module_root.replace("\\", "\\\\"))
    installed_paths = []
    for target_dir in target_dirs:
        os.makedirs(target_dir, exist_ok=True)
        bootstrap_path = startup_bootstrap_path(target_dir)
        with open(bootstrap_path, "w", encoding="utf-8") as handle:
            handle.write(bootstrap)
        installed_paths.append(bootstrap_path)
    return installed_paths


def _open_external_url(url):
    if not url:
        return False
    if QtGui and hasattr(QtGui, "QDesktopServices"):
        return QtGui.QDesktopServices.openUrl(QtCore.QUrl(url))
    return False


class _ToastWidget(QtWidgets.QFrame if QtWidgets else object):
    def __init__(self):
        super(_ToastWidget, self).__init__(None)
        flags = QtCore.Qt.Tool | QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        self.setAttribute(QtCore.Qt.WA_ShowWithoutActivating, True)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground, True)
        self.setObjectName("AminateMobuToast")
        self.setStyleSheet(
            "#AminateMobuToast { background: rgba(18, 24, 31, 230); border: 1px solid rgba(114, 184, 255, 180); border-radius: 10px; }"
            "QLabel { color: white; font-size: 13px; padding: 10px 14px; }"
        )
        self._layout = QtWidgets.QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._label = QtWidgets.QLabel("")
        self._label.setWordWrap(True)
        self._layout.addWidget(self._label)
        self._hide_timer = QtCore.QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self._fade_out)
        self._animation = QtCore.QPropertyAnimation(self, b"windowOpacity", self)
        self._animation.setDuration(220)
        self._animation.finished.connect(self._after_hide)
        self._done = None

    def show_message(self, message, duration_ms, done_callback):
        self._done = done_callback
        self._animation.stop()
        self._hide_timer.stop()
        self._label.setText(str(message or ""))
        self.adjustSize()
        self._position()
        self.setWindowOpacity(1.0)
        self.show()
        self.raise_()
        self._hide_timer.start(int(duration_ms))

    def _position(self):
        anchor = _qt_host_main_window() or _qt_main_window()
        if anchor is None:
            return
        geo = anchor.frameGeometry()
        self.adjustSize()
        x_pos = geo.x() + int((geo.width() - self.width()) / 2)
        y_pos = geo.y() + geo.height() - self.height() - 56
        self.move(x_pos, y_pos)

    def _fade_out(self):
        self._animation.stop()
        self._animation.setStartValue(1.0)
        self._animation.setEndValue(0.0)
        self._animation.start()

    def _after_hide(self):
        self.hide()
        self.setWindowOpacity(1.0)
        done = self._done
        self._done = None
        if done:
            done()


def _ensure_toast():
    global _TOAST
    if QtWidgets is None:
        return None
    if _TOAST is None:
        _TOAST = _ToastWidget()
    return _TOAST


def _toast_finished():
    global _TOAST_ACTIVE
    _TOAST_ACTIVE = False
    _show_next_toast()


def _show_next_toast():
    global _TOAST_ACTIVE
    if _TOAST_ACTIVE or not _TOAST_QUEUE:
        return
    widget = _ensure_toast()
    if widget is None:
        _TOAST_QUEUE[:] = []
        return
    kind, message, duration_ms = _TOAST_QUEUE.pop(0)
    _TOAST_ACTIVE = True
    widget.show_message(message, duration_ms, _toast_finished)


def _warning_allowed(kind, throttle_seconds):
    now = _now()
    last_shown = _WARNING_LAST_SHOWN.get(kind, 0.0)
    if now - last_shown < float(throttle_seconds):
        return False
    _WARNING_LAST_SHOWN[kind] = now
    return True


def _record_warning(kind, message):
    payload = {"kind": str(kind), "message": str(message), "time": _now()}
    _WARNING_HISTORY.append(payload)
    panel = _QT_TOOL
    if panel is not None and hasattr(panel, "_refresh_warning_history_view"):
        try:
            panel._refresh_warning_history_view()
        except Exception:
            pass
    return payload


def _queue_warning(kind, message, duration_ms=DEFAULT_TOAST_DURATION_MS, throttle_seconds=0.0):
    if throttle_seconds and not _warning_allowed(kind, throttle_seconds):
        return False
    _record_warning(kind, message)
    widget = _ensure_toast()
    if widget is not None:
        _TOAST_QUEUE.append((kind, message, duration_ms))
        _show_next_toast()
    else:
        print("[Aminate Mobu][{0}] {1}".format(kind, message))
    return True


def reset_runtime_state(clear_tool=False):
    global _QT_TOOL
    global _QT_DOCK
    global _QT_LAUNCHER_TOOLBAR
    global _QT_LAUNCHER_ACTION
    global _TOAST_QUEUE, _TOAST_ACTIVE, _WARNING_LAST_SHOWN, _WARNING_HISTORY, _STATUS_LINES
    _TOAST_QUEUE = []
    _TOAST_ACTIVE = False
    _WARNING_LAST_SHOWN = {}
    _WARNING_HISTORY = []
    _STATUS_LINES = []
    if _QT_TOOL is not None and hasattr(_QT_TOOL, "_refresh_warning_history_view"):
        try:
            _QT_TOOL._refresh_warning_history_view()
        except Exception:
            pass
    remove_runtime_watchers()
    if clear_tool:
        _restore_app_theme()
        dock = _QT_DOCK if _qt_object_is_valid(_QT_DOCK) else None
        toolbar = _QT_LAUNCHER_TOOLBAR if _qt_object_is_valid(_QT_LAUNCHER_TOOLBAR) else None
        _QT_DOCK = None
        _QT_TOOL = None
        _QT_LAUNCHER_TOOLBAR = None
        _QT_LAUNCHER_ACTION = None
    else:
        dock = None
        toolbar = None
    if dock is not None:
        try:
            dock.hide()
        except Exception:
            pass
        try:
            dock.close()
        except Exception:
            pass
    if clear_tool:
        _close_duplicate_aminate_mobu_docks()
    if toolbar is not None:
        try:
            toolbar.hide()
        except Exception:
            pass
        try:
            toolbar.deleteLater()
        except Exception:
            pass
    if clear_tool:
        _close_duplicate_aminate_launcher_toolbars()
    if clear_tool and TOOL_NAME in pyfbsdk_additions.FBToolList:
        pyfbsdk_additions.FBDestroyToolByName(TOOL_NAME)


def get_warning_history():
    return list(_WARNING_HISTORY)


def _set_status_lines(lines):
    global _STATUS_LINES
    _STATUS_LINES = [str(line) for line in lines if str(line).strip()]
    memo = getattr(_TOOL, "status_memo", None)
    if memo is not None:
        text = FBStringList()
        for line in _STATUS_LINES:
            text.Add(line)
        memo.SetStrings(text)
    qt_memo = getattr(_QT_TOOL, "status_memo", None)
    if qt_memo is not None:
        qt_memo.setPlainText("\n".join(_STATUS_LINES))
    qt_status = getattr(_QT_TOOL, "status_label", None)
    if qt_status is not None:
        qt_status.setText(_status_display_text(_STATUS_LINES[-1] if _STATUS_LINES else "Ready."))


def _status_display_text(message):
    text = str(message or "Ready.")
    if any(item in text.lower() for item in ("error", "could not", "failed", "missing")):
        return text
    return u"\u2705 {0}".format(text)


def _sanitize_motionbuilder_warning_text(text):
    lines = []
    for line in str(text or "").splitlines():
        lower = line.lower()
        if "doesn't seem to be parallel to the x axis" in lower:
            continue
        if "does not seem to be parallel to the x axis" in lower:
            continue
        lines.append(line)
    return "\n".join(lines).strip()


def _append_status(line):
    lines = list(_STATUS_LINES)
    lines.append(str(line))
    _set_status_lines(lines[-28:])


def _property_src_count(prop):
    try:
        return int(prop.GetSrcCount())
    except Exception:
        return 0


def _property_first_src(prop):
    try:
        return prop.GetSrc(0)
    except Exception:
        return None


def _key_property_at_time(prop, time_value, values=None):
    if prop is None:
        return 0
    try:
        prop.SetAnimated(True)
    except Exception:
        pass
    if values is None:
        try:
            prop.KeyAt(time_value)
            return 1
        except Exception:
            pass
    try:
        node = prop.GetAnimationNode()
    except Exception:
        node = None
    if values is not None:
        try:
            values = [float(item) for item in values]
        except Exception:
            try:
                values = [float(values)]
            except Exception:
                values = []
    else:
        values = []
    try:
        wanted_seconds = float(time_value.GetSecondDouble())
    except Exception:
        wanted_seconds = None
    keyed = 0
    for child_index, child in enumerate(getattr(node, "Nodes", []) or []):
        fcurve = getattr(child, "FCurve", None)
        if fcurve is None:
            try:
                child.FCurve = child.CreateFCurve()
                fcurve = child.FCurve
            except Exception:
                fcurve = None
        if fcurve is None:
            continue
        value = values[child_index] if child_index < len(values) else None
        if value is not None:
            try:
                key_index = fcurve.KeyAdd(time_value, value)
                if key_index is not None and int(key_index) >= 0:
                    try:
                        fcurve.KeySetValue(int(key_index), value)
                    except Exception:
                        pass
                    keyed += 1
            except Exception:
                pass
            try:
                key_count = len(fcurve.Keys)
            except Exception:
                key_count = 0
            for key_index in range(key_count):
                try:
                    key_time = fcurve.KeyGetTime(key_index)
                    key_seconds = float(key_time.GetSecondDouble()) if wanted_seconds is not None else None
                    same_time = bool(key_time == time_value)
                    if key_seconds is not None:
                        same_time = abs(key_seconds - wanted_seconds) <= 0.000001
                    if same_time:
                        fcurve.KeySetValue(key_index, value)
                except Exception:
                    pass
            if value is not None:
                continue
        try:
            child.KeyAdd(time_value)
            keyed += 1
            continue
        except Exception:
            pass
        try:
            fcurve.KeyAdd(time_value)
            keyed += 1
        except Exception:
            pass
    return keyed


def _model_local_vector(model, transform_type):
    vector = FBVector3d()
    try:
        model.GetVector(vector, transform_type, False)
        return (float(vector[0]), float(vector[1]), float(vector[2]))
    except Exception:
        return None


def _key_model_property_at_time(model, prop_name, time_value):
    prop = model.PropertyList.Find(prop_name)
    values = None
    if prop_name == "Lcl Translation":
        values = _model_local_vector(model, FBModelTransformationType.kModelTranslation)
    elif prop_name == "Lcl Rotation":
        values = _model_local_vector(model, FBModelTransformationType.kModelRotation)
    return _key_property_at_time(prop, time_value, values=values)


def _character_summary(character):
    if character is None:
        return "Current Character: none"
    return "Current Character: {0} | Characterized: {1} | Keying Mode: {2}".format(
        character.LongName,
        bool(character.GetCharacterize()),
        character.KeyingMode,
    )


def _selected_models():
    models = FBModelList()
    FBGetSelectedModels(models)
    return list(models)


def _current_character():
    return FBApplication().CurrentCharacter


def _set_current_character(character):
    if character is None:
        return False
    try:
        FBApplication().CurrentCharacter = character
    except Exception:
        return False
    try:
        character.Selected = True
    except Exception:
        pass
    return True


def _scene_models(predicate=None):
    output = []
    for component in FBSystem().Scene.Components:
        if isinstance(component, FBModel):
            if predicate is None or predicate(component):
                output.append(component)
    return output


def _scene_skeletons(namespace=None):
    output = []
    for model in _scene_models(lambda item: isinstance(item, FBModelSkeleton)):
        if namespace and _namespace_from_long_name(model.LongName) != namespace:
            continue
        output.append(model)
    return output


def _model_parent(model):
    try:
        return model.Parent
    except Exception:
        return None


def _model_children(model):
    try:
        return list(model.Children)
    except Exception:
        return []


def _skeleton_root(model):
    if model is None:
        return None
    root = model
    parent = _model_parent(root)
    while isinstance(parent, FBModelSkeleton):
        root = parent
        parent = _model_parent(root)
    return root


def _skeleton_descendants(root):
    if root is None:
        return []
    output = []
    stack = [root]
    seen = set()
    while stack:
        model = stack.pop(0)
        key = _component_long_name(model)
        if key in seen:
            continue
        seen.add(key)
        if isinstance(model, FBModelSkeleton):
            output.append(model)
        for child in _model_children(model):
            if isinstance(child, FBModelSkeleton):
                stack.append(child)
    return output


def _skeleton_root_by_name(root_name):
    if not root_name:
        return None
    root = FBFindModelByLabelName(root_name)
    if root is None:
        root = FBFindModelByLabelName(_short_name_from_long_name(root_name))
    return root if isinstance(root, FBModelSkeleton) else None


def _is_model_in_skeleton_scope(model, root_name=None):
    root_name = root_name if root_name is not None else _SKELETON_SCOPE_ROOT_NAME
    if not model or not root_name:
        return False
    root = _skeleton_root(model)
    return bool(root and _component_long_name(root) == root_name)


def _skeleton_roots():
    roots = OrderedDict()
    for model in _scene_skeletons():
        root = _skeleton_root(model)
        if root is not None:
            roots.setdefault(_component_long_name(root), root)
    return list(roots.values())


def _ancestor_skeletons(model):
    output = []
    parent = model
    seen = set()
    while parent is not None:
        key = _component_long_name(parent)
        if key in seen:
            break
        seen.add(key)
        if isinstance(parent, FBModelSkeleton):
            output.append(parent)
        parent = _model_parent(parent)
    return output


def _iter_motionbuilder_list(value, limit=512):
    if value is None:
        return []
    try:
        return list(value)
    except Exception:
        pass
    try:
        count = min(int(len(value)), limit)
    except Exception:
        count = 0
    output = []
    for index in range(count):
        try:
            output.append(value[index])
        except Exception:
            break
    return output


def _connection_skeletons(component, max_depth=3):
    output = []
    queue = [(component, 0)]
    seen = set()
    while queue:
        item, depth = queue.pop(0)
        if item is None:
            continue
        key = id(item)
        if key in seen:
            continue
        seen.add(key)
        if isinstance(item, FBModelSkeleton):
            output.append(item)
            continue
        if depth >= max_depth:
            continue
        if isinstance(item, FBModel):
            queue.extend((ancestor, depth + 1) for ancestor in _ancestor_skeletons(item))
            try:
                geometry = item.Geometry
            except Exception:
                geometry = None
            if geometry is not None:
                queue.append((geometry, depth + 1))
        for method_name in ("GetSrc", "GetDst"):
            count_method = "GetSrcCount" if method_name == "GetSrc" else "GetDstCount"
            try:
                count = min(int(getattr(item, count_method)()), 512)
            except Exception:
                count = 0
            for index in range(count):
                try:
                    queue.append((getattr(item, method_name)(index), depth + 1))
                except Exception:
                    pass
        try:
            properties = list(getattr(item, "PropertyList", []) or [])
        except Exception:
            properties = []
        for prop in properties:
            for method_name in ("GetSrc", "GetDst"):
                count_method = "GetSrcCount" if method_name == "GetSrc" else "GetDstCount"
                try:
                    count = int(getattr(prop, count_method)())
                except Exception:
                    count = 0
                for index in range(count):
                    try:
                        queue.append((getattr(prop, method_name)(index), depth + 1))
                    except Exception:
                        pass
        for attr_name in ("Deformers", "Clusters"):
            try:
                related_items = getattr(item, attr_name)
            except Exception:
                related_items = None
            for related in _iter_motionbuilder_list(related_items):
                queue.append((related, depth + 1))
    unique = OrderedDict()
    for model in output:
        root = _skeleton_root(model)
        if root is not None:
            unique.setdefault(_component_long_name(root), root)
    return list(unique.values())


def _best_root_for_selected_models(selected_models):
    roots = _skeleton_roots()
    if not selected_models or not roots:
        return None
    selected_skeletons = [model for model in selected_models if isinstance(model, FBModelSkeleton)]
    if selected_skeletons:
        selected_names = {_component_long_name(model) for model in selected_skeletons}
        best_root = None
        best_score = -1
        for root in roots:
            descendants = _skeleton_descendants(root)
            descendant_names = {_component_long_name(model) for model in descendants}
            selected_hits = len(selected_names.intersection(descendant_names))
            namespace_hits = sum(
                1
                for model in selected_skeletons
                if _namespace_from_long_name(model.LongName) == _namespace_from_long_name(root.LongName)
            )
            score = (selected_hits * 10000) + (namespace_hits * 100) + len(descendants)
            if score > best_score:
                best_root = root
                best_score = score
        if best_root is not None and best_score > 0:
            return best_root
    related_roots = OrderedDict()
    for model in selected_models:
        for root in _connection_skeletons(model):
            related_roots.setdefault(_component_long_name(root), root)
        model_namespace = _namespace_from_long_name(_component_long_name(model))
        if model_namespace:
            for root in roots:
                if _namespace_from_long_name(root.LongName) == model_namespace:
                    related_roots.setdefault(_component_long_name(root), root)
    if len(related_roots) == 1:
        return next(iter(related_roots.values()))
    if related_roots:
        selected_names = [_normalize_name(_short_name_from_long_name(_component_long_name(model))) for model in selected_models]
        best_root = None
        best_score = -1
        for root in related_roots.values():
            root_namespace = _namespace_from_long_name(root.LongName)
            descendants = _skeleton_descendants(root)
            score = len(descendants)
            for model in selected_models:
                if root_namespace and _namespace_from_long_name(_component_long_name(model)) == root_namespace:
                    score += 1000
            root_tokens = _normalize_name(_short_name_from_long_name(root.LongName))
            if any(root_tokens and (root_tokens in name or name in root_tokens) for name in selected_names):
                score += 250
            if score > best_score:
                best_root = root
                best_score = score
        return best_root
    if len(roots) == 1:
        return roots[0]
    return None


def selected_skeleton_scope_label():
    if not _SKELETON_SCOPE_ROOT_NAME:
        return "No skeleton selected"
    return _short_name_from_long_name(_SKELETON_SCOPE_ROOT_NAME)


def set_selected_skeleton_scope_from_selection(require_selection=True):
    global _SKELETON_SCOPE_ROOT_NAME
    selected = _selected_models()
    root = _best_root_for_selected_models(selected)
    if root is not None:
        _SKELETON_SCOPE_ROOT_NAME = _component_long_name(root)
        _append_status("Selected skeleton scope: {0}.".format(selected_skeleton_scope_label()))
        return {"ok": True, "root": _SKELETON_SCOPE_ROOT_NAME, "label": selected_skeleton_scope_label()}
    if not selected and not require_selection:
        return {"ok": False, "error": "No skeleton or mesh selected."}
    result = {"ok": False, "error": "Select a skeleton bone or skinned mesh, then click Auto Map Skeleton."}
    _append_status(result["error"])
    return result


def _scoped_skeletons(namespace=None):
    if _SKELETON_SCOPE_ROOT_NAME:
        root = _skeleton_root_by_name(_SKELETON_SCOPE_ROOT_NAME)
        if root is not None:
            models = _skeleton_descendants(root)
            if namespace:
                models = [model for model in models if _namespace_from_long_name(model.LongName) == namespace]
            return models
    return _scene_skeletons(namespace=namespace)


def _require_skeleton_scope_if_needed():
    global _SKELETON_SCOPE_ROOT_NAME
    selection_result = set_selected_skeleton_scope_from_selection(require_selection=False)
    if selection_result.get("ok"):
        return None
    if _SKELETON_SCOPE_ROOT_NAME:
        return None
    roots = _skeleton_roots()
    if len(roots) > 1:
        namespace, indexed, score = find_best_skeleton_namespace()
        hips = _slot_match_for_index("HipsLink", indexed)
        inferred_root = _skeleton_root(hips) if hips is not None else None
        if inferred_root is not None and score >= 500:
            _SKELETON_SCOPE_ROOT_NAME = _component_long_name(inferred_root)
            _append_status(
                "Selected skeleton scope automatically: {0}. Select a different bone or mesh first if this is not the rig you wanted.".format(
                    selected_skeleton_scope_label()
                )
            )
            return None
        return {
            "ok": False,
            "error": "Multiple skeletons found. Select a skeleton bone or skinned mesh, then click Auto Map Skeleton.",
            "root_count": len(roots),
        }
    if len(roots) == 1:
        _SKELETON_SCOPE_ROOT_NAME = _component_long_name(roots[0])
    return None


def _scene_markers():
    return _scene_models(lambda item: isinstance(item, (FBModelMarker, FBModelMarkerOptical)))


def _is_unlabelled_marker(marker):
    long_name = _component_long_name(marker)
    short_name = _short_name_from_long_name(long_name).strip()
    namespace = _namespace_from_long_name(long_name).strip()
    if bool(UNLABELLED_MARKER_PATTERN.match(short_name)):
        return True
    if namespace and UNLABELLED_MARKER_NAMESPACE_PATTERN.match(_normalize_name(namespace)) and re.match(r"^_?\d+$", short_name):
        return True
    return False


def _is_unlabelled_marker_namespace(marker):
    namespace = _namespace_from_long_name(_component_long_name(marker)).strip()
    return bool(namespace and UNLABELLED_MARKER_NAMESPACE_PATTERN.match(_normalize_name(namespace)))


def _property_has_animation_keys(prop):
    if prop is None:
        return False
    try:
        animation_node = prop.GetAnimationNode()
    except Exception:
        animation_node = None
    if animation_node is None:
        return False

    def _node_has_keys(node):
        fcurve = getattr(node, "FCurve", None)
        if fcurve is not None:
            try:
                if len(fcurve.Keys) > 0:
                    return True
            except Exception:
                pass
        for child in getattr(node, "Nodes", []) or []:
            if _node_has_keys(child):
                return True
        return False

    if _node_has_keys(animation_node):
        return True
    for child in getattr(animation_node, "Nodes", []) or []:
        try:
            if _node_has_keys(child):
                return True
        except Exception:
            continue
    return False


def _animation_node_fcurves(node):
    fcurve = getattr(node, "FCurve", None)
    if fcurve is not None:
        yield fcurve
    for child in getattr(node, "Nodes", []) or []:
        for item in _animation_node_fcurves(child):
            yield item


def _fcurve_key_values(fcurve):
    values = []
    try:
        key_count = len(fcurve.Keys)
    except Exception:
        key_count = 0
    for index in range(key_count):
        try:
            values.append(float(fcurve.KeyGetValue(index)))
        except Exception:
            try:
                values.append(float(fcurve.Keys[index].Value))
            except Exception:
                pass
    return values


def _property_has_varying_animation_keys(prop, epsilon=0.0001):
    if prop is None:
        return False
    try:
        animation_node = prop.GetAnimationNode()
    except Exception:
        animation_node = None
    if animation_node is None:
        return False
    for fcurve in _animation_node_fcurves(animation_node):
        values = _fcurve_key_values(fcurve)
        if len(values) < 2:
            continue
        if (max(values) - min(values)) > epsilon:
            return True
    return False


def _marker_has_transform_animation(marker):
    if marker is None:
        return False
    for prop_name in MARKER_TRANSFORM_PROPERTY_NAMES:
        prop = marker.PropertyList.Find(prop_name)
        if _property_has_animation_keys(prop):
            return True
    for attr_name in ("Translation", "Rotation"):
        prop = getattr(marker, attr_name, None)
        if _property_has_animation_keys(prop):
            return True
    return False


def _existing_component_short_names():
    names = set()
    for component in FBSystem().Scene.Components:
        name = _short_name_from_long_name(_component_long_name(component))
        if name:
            names.add(name)
    return names


def _rename_component(component, target_name):
    old_name = _component_long_name(component)
    try:
        component.Name = target_name
    except Exception:
        return "", old_name
    return _component_long_name(component), old_name


def _rename_prop_markers(markers, base_name):
    renamed = []
    existing_names = _existing_component_short_names()
    sorted_markers = sorted(markers or [], key=lambda item: _component_long_name(item))
    clean_base_name = _sanitize_prop_marker_base_name(base_name)
    counter = 1
    for marker in sorted_markers:
        original_name = _short_name_from_long_name(_component_long_name(marker))
        while True:
            candidate = "{0}_{1}".format(clean_base_name, counter)
            counter += 1
            if candidate == original_name or candidate not in existing_names:
                break
        new_long_name, old_long_name = _rename_component(marker, candidate)
        new_short_name = _short_name_from_long_name(new_long_name or candidate)
        existing_names.discard(original_name)
        existing_names.add(new_short_name)
        renamed.append({"from": old_long_name, "to": new_long_name or candidate})
    return renamed


CONSTRAINT_PROPERTY_KEY_TERMS = (
    "active",
    "weight",
    "blend",
    "offset",
    "translation",
    "rotation",
    "scaling",
    "scale",
    "snap",
)


USER_CONSTRAINT_KIND_TOKENS = (
    "3points",
    "threepoints",
    "mapping",
    "position",
    "rotation",
    "aim",
    "multireferential",
    "range",
    "scale",
    "chainik",
    "parentchild",
    "relation",
    "splineik",
    "expression",
    "path",
    "rigidbody",
)


CONSTRAINT_RECOMMENDATIONS = (
    "Parent/Position/Rotation: use for prop handoffs, weapon holds, temporary space switching, and dynamic parenting.",
    "Aim: use for eyes, cameras, look-at rigs, and any control that must point at a target.",
    "Relation: use for advanced logic, math, remaps, switches, and multi-input rig behaviour.",
    "Chain IK: use for limbs/tails when you need solver-style posing before baking.",
    "Props across takes: use Set Offset For This Take when the prop starts in a different place on each take.",
    "Always key Weight/Active at the switch frame, then save/bake to Skeleton or Control Rig before cleanup.",
)


def _scene_constraints():
    constraints = []
    try:
        constraints.extend(list(FBSystem().Scene.Constraints))
    except Exception:
        constraints = []
    if not constraints:
        for component in FBSystem().Scene.Components:
            try:
                if isinstance(component, FBConstraint):
                    constraints.append(component)
            except Exception:
                if "Constraint" in type(component).__name__:
                    constraints.append(component)
    return [item for item in constraints if item is not None]


def _constraint_type_name(constraint):
    for attr in ("ClassName", "ClassGroupName"):
        value = getattr(constraint, attr, "")
        try:
            value = value() if callable(value) else value
        except Exception:
            value = ""
        if value:
            return str(value)
    return type(constraint).__name__


def _constraint_identifiers(constraint):
    values = [
        _constraint_type_name(constraint),
        type(constraint).__name__,
        _component_long_name(constraint),
        _short_name_from_long_name(_component_long_name(constraint)),
    ]
    for attr in ("Name", "LongName", "ClassName", "ClassGroupName"):
        value = getattr(constraint, attr, "")
        try:
            value = value() if callable(value) else value
        except Exception:
            value = ""
        if value:
            values.append(str(value))
    return [_normalize_name(value) for value in values if value]


def _constraint_tutorial_index_path():
    return os.path.join(_module_root_dir(), "assets", "tutorials", "constraints", "index.json")


def _constraint_tutorial_index():
    path = _constraint_tutorial_index_path()
    if not os.path.isfile(path):
        return OrderedDict()
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle, object_pairs_hook=OrderedDict)
    except Exception:
        return OrderedDict()
    return OrderedDict(payload)


def _constraint_tutorial_key_from_identifiers(identifiers):
    for token in USER_CONSTRAINT_KIND_TOKENS:
        if any(token in identifier for identifier in identifiers):
            if token == "3points":
                return "threepoints"
            return token
    return ""


def _constraint_tutorial_key(constraint):
    return _constraint_tutorial_key_from_identifiers(_constraint_identifiers(constraint))


def _constraint_tutorial_asset_path(key):
    index = _constraint_tutorial_index()
    item = index.get(key) or {}
    file_name = item.get("file") or "{0}.png".format(key)
    return os.path.join(_module_root_dir(), "assets", "tutorials", "constraints", file_name)


def _is_system_constraint(constraint):
    identifiers = _constraint_identifiers(constraint)
    return any("solver" in item or "hik" in item or "character" in item for item in identifiers)


def _is_user_facing_constraint(constraint):
    try:
        if not isinstance(constraint, FBConstraint):
            return False
    except Exception:
        if "Constraint" not in type(constraint).__name__:
            return False
    if _is_system_constraint(constraint):
        return False
    identifiers = _constraint_identifiers(constraint)
    return bool(_constraint_tutorial_key_from_identifiers(identifiers))


def _actionable_constraints(constraints=None):
    return [item for item in list(constraints if constraints is not None else _scene_constraints()) if _is_user_facing_constraint(item)]


def _constraint_target_summary(constraint):
    names = []
    try:
        group_count = int(constraint.ReferenceGroupGetCount())
    except Exception:
        group_count = 0
    for group_index in range(group_count):
        try:
            ref_count = int(constraint.ReferenceGetCount(group_index))
        except Exception:
            ref_count = 0
        for ref_index in range(ref_count):
            try:
                ref = constraint.ReferenceGet(group_index, ref_index)
            except Exception:
                ref = None
            if ref is not None:
                names.append(_short_name_from_long_name(_component_long_name(ref)))
    return ", ".join([name for name in names if name][:4])


def constraint_rows():
    rows = []
    for index, constraint in enumerate(_actionable_constraints(_scene_constraints()), start=1):
        rows.append({
            "index": index,
            "name": _short_name_from_long_name(_component_long_name(constraint)),
            "type": _constraint_type_name(constraint),
            "active": bool(getattr(constraint, "Active", False)),
            "weight": getattr(constraint, "Weight", ""),
            "targets": _constraint_target_summary(constraint),
            "constraint": constraint,
        })
    return rows


def _constraint_easy_base(constraint):
    type_name = _constraint_type_name(constraint)
    type_name = re.sub(r"^FB", "", type_name)
    type_name = re.sub(r"Constraint", "", type_name, flags=re.IGNORECASE)
    clean = re.sub(r"[^A-Za-z0-9]+", "_", type_name).strip("_") or "Constraint"
    return "Aminate_{0}".format(clean)


def rename_constraints_to_easy_names(constraints=None):
    constraints = _actionable_constraints(constraints)
    existing_names = _existing_component_short_names()
    renamed = []
    counters = {}
    for constraint in constraints:
        original_short = _short_name_from_long_name(_component_long_name(constraint))
        base = _constraint_easy_base(constraint)
        counters[base] = counters.get(base, 0) + 1
        while True:
            candidate = "{0}_{1:02d}".format(base, counters[base])
            counters[base] += 1
            if candidate == original_short or candidate not in existing_names:
                break
        new_long, old_long = _rename_component(constraint, candidate)
        new_short = _short_name_from_long_name(new_long or candidate)
        existing_names.discard(original_short)
        existing_names.add(new_short)
        renamed.append({"from": old_long, "to": new_long or candidate})
    _append_status("Renamed {0} user constraint(s) to easy Aminate names.".format(len(renamed)))
    return renamed


def _constraint_keyable_properties(constraint):
    output = []
    for prop in getattr(constraint, "PropertyList", []) or []:
        name = getattr(prop, "Name", "") or str(prop)
        normalized = _normalize_name(name)
        if any(term in normalized for term in CONSTRAINT_PROPERTY_KEY_TERMS):
            output.append(prop)
    for prop_name in ("Active", "Weight"):
        try:
            prop = constraint.PropertyList.Find(prop_name, False)
        except Exception:
            prop = None
        if prop is not None and prop not in output:
            output.append(prop)
    return output


def key_constraint_properties(constraints=None, time_value=None):
    constraints = _actionable_constraints(constraints)
    if time_value is None:
        try:
            time_value = FBPlayerControl().GetEditCurrentTime()
        except Exception:
            time_value = FBSystem().LocalTime
    keyed_constraints = 0
    keyed_channels = 0
    for constraint in constraints:
        keyed_here = 0
        for prop in _constraint_keyable_properties(constraint):
            keyed_here += _key_property_at_time(prop, time_value)
        if keyed_here:
            keyed_constraints += 1
            keyed_channels += keyed_here
    _append_status("Keyed {0} constraint(s), {1} property channel(s), at current time.".format(keyed_constraints, keyed_channels))
    return {"ok": True, "constraints": keyed_constraints, "channels": keyed_channels}


def open_constraint_bake_options():
    try:
        popup = FBPlotPopup()
        popup.Popup()
        _append_status("Opened MotionBuilder bake/plot options. Use Save To Skeleton or Save To Control Rig after choosing options.")
        return {"ok": True}
    except Exception as exc:
        result = {"ok": False, "error": "Could not open bake/plot options: {0}".format(exc)}
        _append_status(result["error"])
        return result


def save_current_character_motion(plot_where):
    character, error = _current_character_or_error()
    if error:
        _append_status(error["error"])
        return error
    options = FBPlotOptions()
    options.PlotOnFrame = True
    try:
        result = bool(character.PlotAnimation(plot_where, options))
    except Exception as exc:
        result = False
        _append_status("Could not save constrained motion: {0}".format(exc))
        return {"ok": False, "error": str(exc)}
    target = "Skeleton" if plot_where == FBCharacterPlotWhere.kFBCharacterPlotOnSkeleton else "Control Rig"
    _append_status("Saved constrained motion to {0}: {1}.".format(target, bool(result)))
    return {"ok": bool(result), "target": target}


_MUTED_PROP_CONSTRAINT_STATES = OrderedDict()
_PROP_TAKE_OFFSET_VALUES = OrderedDict()
_PROP_TAKE_OFFSET_APPLYING = False
_LAST_PROP_OFFSET_PREVIEW = "No prop offset captured yet."


def _current_take():
    try:
        return FBSystem().CurrentTake
    except Exception:
        return None


def _take_label(take=None):
    take = take or _current_take()
    if take is None:
        return "Unknown Take"
    return _short_name_from_long_name(_component_long_name(take)) or str(getattr(take, "Name", "") or "Unknown Take")


def _scene_takes():
    try:
        return [take for take in list(FBSystem().Scene.Takes) if take is not None]
    except Exception:
        return []


def _set_current_take(take):
    if take is None:
        return False
    try:
        FBSystem().CurrentTake = take
        _evaluate_scene()
        apply_prop_offsets_for_current_take()
        return True
    except Exception:
        return False


def _constraint_reference_models(constraint):
    refs = []
    try:
        group_count = int(constraint.ReferenceGroupGetCount())
    except Exception:
        group_count = 0
    for group_index in range(group_count):
        try:
            ref_count = int(constraint.ReferenceGetCount(group_index))
        except Exception:
            ref_count = 0
        for ref_index in range(ref_count):
            try:
                ref = constraint.ReferenceGet(group_index, ref_index)
            except Exception:
                ref = None
            if isinstance(ref, FBModel) and ref not in refs:
                refs.append(ref)
    return refs


def _property_data_values(prop):
    if prop is None:
        return []
    try:
        value = prop.Data
    except Exception:
        return []
    try:
        if isinstance(value, (str, bytes)):
            return []
    except Exception:
        pass
    try:
        return [float(value[index]) for index in range(len(value))]
    except Exception:
        pass
    try:
        return [float(value)]
    except Exception:
        return []


def _set_property_data(prop, values):
    if prop is None or values is None:
        return False
    try:
        values = [float(item) for item in values]
    except Exception:
        return False
    if len(values) >= 3:
        vector = FBVector3d(values[0], values[1], values[2])
        for candidate in (vector, (values[0], values[1], values[2]), [values[0], values[1], values[2]]):
            try:
                prop.Data = candidate
                return True
            except Exception:
                pass
    if len(values) == 1:
        try:
            prop.Data = values[0]
            return True
        except Exception:
            return False
    return False


def _find_property_by_name(component, property_name):
    try:
        prop = component.PropertyList.Find(property_name, False)
    except Exception:
        prop = None
    if prop is not None:
        return prop
    for candidate in getattr(component, "PropertyList", []) or []:
        if str(getattr(candidate, "Name", "") or candidate) == str(property_name):
            return candidate
    return None


def _constraint_offset_property_kind(prop):
    name = getattr(prop, "Name", "") or str(prop)
    normalized = _normalize_name(name)
    if not any(term in normalized for term in ("offset", "baseoffset", "base")):
        return ""
    if any(term in normalized for term in ("rotation", "rotate", "rot", "roffset", "offsetr")):
        return "rotation"
    if any(term in normalized for term in ("translation", "translate", "position", "pos", "toffset", "offsett")):
        return "translation"
    if any(term in normalized for term in ("scaling", "scale", "soffset", "offsets")):
        return "scale"
    return "generic"


def _constraint_offset_properties(constraint):
    props = []
    for prop in getattr(constraint, "PropertyList", []) or []:
        kind = _constraint_offset_property_kind(prop)
        if kind:
            props.append((prop, kind))
    return props


def _wrap_euler_delta(value):
    while value > 180.0:
        value -= 360.0
    while value < -180.0:
        value += 360.0
    return value


def _constraint_world_offset_values(constraint):
    refs = _constraint_reference_models(constraint)
    if len(refs) < 2:
        return {}
    source = refs[0]
    driven = refs[-1]
    source_t = _model_world_translation(source)
    driven_t = _model_world_translation(driven)
    source_r = _model_world_rotation(source)
    driven_r = _model_world_rotation(driven)
    values = {}
    if source_t is not None and driven_t is not None:
        values["translation"] = _v_sub(driven_t, source_t)
    if source_r is not None and driven_r is not None:
        values["rotation"] = tuple(_wrap_euler_delta(driven_r[index] - source_r[index]) for index in range(3))
    return values


def _find_constraint_by_long_name(long_name):
    for constraint in _scene_constraints():
        if _component_long_name(constraint) == long_name:
            return constraint
    return None


def _store_prop_take_offsets(constraint, prop_values, take_name=None):
    constraint_name = _component_long_name(constraint)
    take_name = take_name or _take_label()
    if not constraint_name or not take_name:
        return
    if constraint_name not in _PROP_TAKE_OFFSET_VALUES:
        _PROP_TAKE_OFFSET_VALUES[constraint_name] = OrderedDict()
    _PROP_TAKE_OFFSET_VALUES[constraint_name][take_name] = list(prop_values)


def apply_prop_offsets_for_current_take():
    global _PROP_TAKE_OFFSET_APPLYING
    if _PROP_TAKE_OFFSET_APPLYING:
        return {"ok": False, "applied": 0}
    take_name = _take_label()
    if not _PROP_TAKE_OFFSET_VALUES:
        return {"ok": True, "applied": 0}
    _PROP_TAKE_OFFSET_APPLYING = True
    applied = 0
    try:
        for constraint_name, take_map in list(_PROP_TAKE_OFFSET_VALUES.items()):
            payload = take_map.get(take_name)
            if not payload:
                continue
            constraint = _find_constraint_by_long_name(constraint_name)
            if constraint is None:
                continue
            for item in payload:
                prop = _find_property_by_name(constraint, item.get("property", ""))
                values = item.get("values")
                if prop is not None and values and _set_property_data(prop, values):
                    applied += 1
        if applied:
            _evaluate_scene()
            _append_status("Prop Take Offset: applied {0} stored offset propertie(s) for {1}.".format(applied, take_name))
        return {"ok": True, "applied": applied, "take": take_name}
    finally:
        _PROP_TAKE_OFFSET_APPLYING = False


def _format_offset_vector(values):
    if not values:
        return "none"
    try:
        return ", ".join("{0:.3f}".format(float(value)) for value in values[:3])
    except Exception:
        return str(values)


def _constraint_offset_preview_line(constraint, offset_values):
    name = _short_name_from_long_name(_component_long_name(constraint)) or "Constraint"
    translation = _format_offset_vector(offset_values.get("translation"))
    rotation = _format_offset_vector(offset_values.get("rotation"))
    return "{0}: Offset T [{1}]  Offset R [{2}]".format(name, translation, rotation)


def preview_prop_offset(constraints=None):
    global _LAST_PROP_OFFSET_PREVIEW
    constraints = _selected_or_actionable_constraints(constraints)
    take_name = _take_label()
    if not constraints:
        message = "Prop Take Offset Preview: no user-facing constraints found on {0}.".format(take_name)
        _append_status(message)
        return {"ok": False, "error": message, "preview": []}
    preview_lines = []
    missing_offset = []
    for constraint in constraints:
        if not _constraint_offset_properties(constraint):
            missing_offset.append(_short_name_from_long_name(_component_long_name(constraint)))
            continue
        offset_values = _constraint_world_offset_values(constraint)
        preview_line = _constraint_offset_preview_line(constraint, offset_values)
        preview_lines.append(preview_line)
        _append_status("Prop Take Offset preview: {0}".format(preview_line))
    if preview_lines:
        _LAST_PROP_OFFSET_PREVIEW = preview_lines[-1]
        _append_status("Prop Take Offset Preview: found {0} offset preview(s) on {1}. No keys were changed.".format(len(preview_lines), take_name))
        if missing_offset:
            _append_status("No editable offset property found on: {0}".format(", ".join(missing_offset[:4])))
        return {"ok": True, "preview": list(preview_lines), "take": take_name}
    message = "Prop Take Offset Preview: no editable offset properties found. Try Parent/Child, Position, Rotation, or Multi-Referential constraints."
    _append_status(message)
    return {"ok": False, "error": message, "preview": []}


def _selected_or_actionable_constraints(constraints=None):
    if constraints is not None:
        selected = []
        for constraint in constraints:
            try:
                if isinstance(constraint, FBConstraint):
                    selected.append(constraint)
                    continue
            except Exception:
                pass
            if "Constraint" in type(constraint).__name__:
                selected.append(constraint)
        if selected:
            return selected
    return _actionable_constraints(_scene_constraints())


def set_prop_offset_for_take(constraints=None, time_value=None):
    global _LAST_PROP_OFFSET_PREVIEW
    constraints = _selected_or_actionable_constraints(constraints)
    if time_value is None:
        try:
            time_value = FBPlayerControl().GetEditCurrentTime()
        except Exception:
            time_value = FBSystem().LocalTime
    take_name = _take_label()
    if not constraints:
        message = "Prop Take Offset: no user-facing constraints found on {0}.".format(take_name)
        _append_status(message)
        return {"ok": False, "error": message, "constraints": 0, "properties": 0}
    constraints_changed = 0
    properties_keyed = 0
    missing_offset = []
    preview_lines = []
    for constraint in constraints:
        offset_props = _constraint_offset_properties(constraint)
        if not offset_props:
            missing_offset.append(_short_name_from_long_name(_component_long_name(constraint)))
            continue
        offset_values = _constraint_world_offset_values(constraint)
        preview_line = _constraint_offset_preview_line(constraint, offset_values)
        preview_lines.append(preview_line)
        _append_status("Prop Take Offset detected: {0}".format(preview_line))
        changed_here = 0
        stored_props = []
        for prop, kind in offset_props:
            values = None
            if kind in ("translation", "rotation"):
                values = offset_values.get(kind)
            elif kind == "generic":
                current_values = _property_data_values(prop)
                values = offset_values.get("translation") if len(current_values) >= 3 else current_values
            else:
                values = _property_data_values(prop)
            if values:
                _set_property_data(prop, values)
                stored_props.append({
                    "property": str(getattr(prop, "Name", "") or prop),
                    "kind": kind,
                    "values": [float(item) for item in values[:3]],
                })
            keyed = _key_property_at_time(prop, time_value, values=values)
            properties_keyed += keyed
            changed_here += keyed
        for prop_name in ("Active", "Weight"):
            try:
                prop = constraint.PropertyList.Find(prop_name, False)
            except Exception:
                prop = None
            if prop is not None:
                properties_keyed += _key_property_at_time(prop, time_value)
        if changed_here:
            constraints_changed += 1
            if stored_props:
                _store_prop_take_offsets(constraint, stored_props, take_name=take_name)
    if constraints_changed:
        if preview_lines:
            _LAST_PROP_OFFSET_PREVIEW = preview_lines[-1]
        message = "Prop Take Offset: keyed {0} offset propertie(s) on {1} constraint(s) for {2}.".format(
            properties_keyed,
            constraints_changed,
            take_name,
        )
        _append_status(message)
        if missing_offset:
            _append_status("No editable offset property found on: {0}".format(", ".join(missing_offset[:4])))
        return {
            "ok": True,
            "constraints": constraints_changed,
            "properties": properties_keyed,
            "take": take_name,
            "preview": list(preview_lines),
        }
    message = "Prop Take Offset: no editable offset properties found. Try selecting Parent/Child, Position, Rotation, or Multi-Referential constraints."
    _append_status(message)
    return {"ok": False, "error": message, "constraints": 0, "properties": properties_keyed}


def set_prop_offset_for_all_takes(constraints=None):
    constraints = _selected_or_actionable_constraints(constraints)
    takes = _scene_takes()
    original_take = _current_take()
    if not takes:
        return set_prop_offset_for_take(constraints)
    results = []
    try:
        for take in takes:
            if not _set_current_take(take):
                continue
            results.append(set_prop_offset_for_take(constraints))
    finally:
        _set_current_take(original_take)
    ok_count = len([item for item in results if item.get("ok")])
    _append_status("Prop Take Offset: updated {0}/{1} take(s).".format(ok_count, len(takes)))
    return {"ok": ok_count > 0, "takes": len(takes), "updated": ok_count}


def mute_prop_constraints_for_setup(constraints=None):
    constraints = _selected_or_actionable_constraints(constraints)
    muted = 0
    for constraint in constraints:
        key = _component_long_name(constraint)
        if not key:
            continue
        if key not in _MUTED_PROP_CONSTRAINT_STATES:
            _MUTED_PROP_CONSTRAINT_STATES[key] = bool(getattr(constraint, "Active", False))
        try:
            constraint.Active = False
            muted += 1
        except Exception:
            pass
    _evaluate_scene()
    _append_status("Prop Take Offset: muted {0} constraint(s) for setup.".format(muted))
    return {"ok": bool(muted), "constraints": muted}


def restore_prop_constraints_after_setup(constraints=None):
    constraints = _selected_or_actionable_constraints(constraints)
    restored = 0
    for constraint in constraints:
        key = _component_long_name(constraint)
        if key not in _MUTED_PROP_CONSTRAINT_STATES:
            continue
        try:
            constraint.Active = bool(_MUTED_PROP_CONSTRAINT_STATES[key])
            restored += 1
        except Exception:
            pass
        _MUTED_PROP_CONSTRAINT_STATES.pop(key, None)
    _evaluate_scene()
    _append_status("Prop Take Offset: restored {0} setup constraint(s).".format(restored))
    return {"ok": bool(restored), "constraints": restored}


def collect_scene_clean_targets():
    cameras = []
    for camera in FBSystem().Scene.Cameras:
        short_name = _short_name_from_long_name(_component_long_name(camera))
        if short_name.startswith("Producer "):
            continue
        cameras.append(camera)
    junk_markers = []
    prop_markers = []
    for marker in _scene_markers():
        if _is_unlabelled_marker_namespace(marker):
            junk_markers.append(marker)
            continue
        if not _is_unlabelled_marker(marker):
            continue
        if _marker_has_transform_animation(marker):
            prop_markers.append(marker)
        else:
            junk_markers.append(marker)
    return cameras, junk_markers, prop_markers


def delete_components(components):
    deleted = []
    for component in components:
        long_name = _component_long_name(component)
        try:
            component.FBDelete()
            deleted.append(long_name)
        except Exception:
            pass
    return deleted


def run_scene_cleaner(delete_cameras=True, delete_unlabelled_markers=True, prop_marker_base_name=None):
    clean_base_name = set_prop_marker_base_name(prop_marker_base_name or get_prop_marker_base_name())
    cameras, junk_markers, prop_markers = collect_scene_clean_targets()
    deleted_cameras = delete_components(cameras) if delete_cameras else []
    renamed_markers = _rename_prop_markers(prop_markers, clean_base_name) if delete_unlabelled_markers else []
    deleted_markers = delete_components(junk_markers) if delete_unlabelled_markers else []
    result = {
        "deleted_cameras": deleted_cameras,
        "deleted_markers": deleted_markers,
        "renamed_markers": renamed_markers,
        "preserved_prop_markers": [item.get("to") for item in renamed_markers],
        "prop_marker_base_name": clean_base_name,
        "camera_count": len(deleted_cameras),
        "marker_count": len(deleted_markers),
        "renamed_marker_count": len(renamed_markers),
    }
    _append_status(
        "Scene Cleaner deleted {0} user camera(s), deleted {1} junk marker(s), and renamed {2} animated prop marker(s) with base {3}.".format(
            len(deleted_cameras),
            len(deleted_markers),
            len(renamed_markers),
            clean_base_name,
        )
    )
    return result


def _candidate_namespace_from_selection():
    if _SKELETON_SCOPE_ROOT_NAME:
        root = FBFindModelByLabelName(_SKELETON_SCOPE_ROOT_NAME) or FBFindModelByLabelName(selected_skeleton_scope_label())
        if root is not None:
            return _namespace_from_long_name(root.LongName)
    for model in _selected_models():
        if isinstance(model, FBModelSkeleton):
            return _namespace_from_long_name(model.LongName)
    return ""


def _index_namespace_skeletons(namespace):
    indexed = OrderedDict()
    for model in _scoped_skeletons(namespace=namespace):
        short_name = _short_name_from_long_name(model.LongName)
        if _is_dummy_name(short_name):
            continue
        normalized = _normalize_name(short_name)
        indexed.setdefault(normalized, model)
    return indexed


def _slot_match_for_index(slot_name, indexed, used_models=None):
    used_models = used_models or set()
    best_model = None
    best_score = 0
    for candidate in CHARACTER_SLOT_CANDIDATES.get(slot_name, ()):
        model = indexed.get(_normalize_name(candidate))
        if model is not None and _component_long_name(model) not in used_models:
            return model
    for normalized, model in indexed.items():
        if _component_long_name(model) in used_models:
            continue
        score = _candidate_slot_score(slot_name, normalized, model)
        if score > best_score:
            best_model = model
            best_score = score
    return best_model


def _slot_score_for_index(slot_name, indexed):
    model = _slot_match_for_index(slot_name, indexed)
    if model is None:
        return 0
    return _candidate_slot_score(slot_name, _normalize_name(_short_name_from_long_name(_component_long_name(model))), model) or 100


def _available_namespaces():
    namespaces = OrderedDict()
    for model in _scoped_skeletons():
        namespaces.setdefault(_namespace_from_long_name(model.LongName), True)
    return list(namespaces.keys())


def _namespace_score(namespace):
    indexed = _index_namespace_skeletons(namespace)
    score = 0
    for slot_name in CORE_REQUIRED_LINKS:
        score += _slot_score_for_index(slot_name, indexed)
    return score, indexed


def find_best_skeleton_namespace():
    preferred = _candidate_namespace_from_selection()
    candidates = _available_namespaces()
    if preferred and preferred in candidates:
        candidates = [preferred] + [item for item in candidates if item != preferred]
    best_namespace = ""
    best_score = -1
    best_index = OrderedDict()
    for namespace in candidates:
        score, indexed = _namespace_score(namespace)
        if score > best_score:
            best_namespace = namespace
            best_score = score
            best_index = indexed
    return best_namespace, best_index, best_score


def _unique_character_name(base_name):
    existing = {_component_short_name(character) for character in FBSystem().Scene.Characters}
    if base_name not in existing:
        return base_name
    counter = 1
    while True:
        candidate = "{0}_{1}".format(base_name, counter)
        if candidate not in existing:
            return candidate
        counter += 1


def _unique_numbered_character_name(prefix):
    existing = {_component_short_name(character) for character in FBSystem().Scene.Characters}
    highest = 0
    pattern = re.compile(r"^{0}_(\d+)$".format(re.escape(prefix)))
    for name in existing:
        match = pattern.match(name)
        if not match:
            continue
        try:
            highest = max(highest, int(match.group(1)))
        except Exception:
            pass
    return "{0}_{1}".format(prefix, highest + 1)


def _is_animate_auto_character(character):
    return _component_short_name(character).startswith("animate_auto_")


def _is_aminate_generated_character(character):
    name = _component_short_name(character)
    return name.startswith("AminateMobu_") or name.startswith("animate_auto_")


def _rename_to_animate_auto(character):
    if character is None or _is_animate_auto_character(character):
        return character
    new_name = _unique_numbered_character_name("animate_auto")
    try:
        character.Name = new_name
    except Exception:
        try:
            character.LongName = new_name
        except Exception:
            pass
    return character


def _auto_map_target_character(namespace_label):
    current = _current_character()
    if current is not None and _is_animate_auto_character(current) and _character_matches_skeleton_scope(current):
        return current, False
    if current is not None and _is_aminate_generated_character(current) and _character_matches_skeleton_scope(current):
        return _rename_to_animate_auto(current), False
    character_name = _unique_numbered_character_name("animate_auto")
    return FBCharacter(character_name), True


def _disconnect_all_sources(prop):
    if prop is None:
        return
    try:
        prop.DisconnectAllSrc()
        return
    except Exception:
        pass
    for index in range(_property_src_count(prop) - 1, -1, -1):
        source = None
        try:
            source = prop.GetSrc(index)
        except Exception:
            source = None
        if source is None:
            continue
        try:
            prop.DisconnectSrc(source)
        except Exception:
            pass


def _map_model_to_slot(character, slot_name, model, replace_existing=True):
    prop = character.PropertyList.Find(slot_name, False)
    if prop is None or model is None:
        return False
    if replace_existing:
        _disconnect_all_sources(prop)
    try:
        prop.append(model)
        return True
    except Exception:
        try:
            prop.ConnectSrc(model)
            return True
        except Exception:
            return False


def _clear_roll_links(character):
    if character is None:
        return 0
    cleared = 0
    for slot_name in ROLL_LINK_SLOTS:
        prop = character.PropertyList.Find(slot_name, False)
        if prop is None:
            continue
        before = _property_src_count(prop)
        _disconnect_all_sources(prop)
        if before:
            cleared += 1
    return cleared


def _harmonize_optional_retarget_slots(target_character, source_character):
    if target_character is None or source_character is None or target_character is source_character:
        return []
    removed = []
    for slot_name in RETARGET_OPTIONAL_MATCH_SLOTS:
        if _character_slot_model(source_character, slot_name) is not None:
            continue
        if _character_slot_model(target_character, slot_name) is None:
            continue
        prop = target_character.PropertyList.Find(slot_name, False)
        if prop is None:
            continue
        _disconnect_all_sources(prop)
        removed.append(slot_name)
    return removed


def _set_characterized(character, enabled):
    if character is None:
        return False, ""
    try:
        result = bool(character.SetCharacterizeOn(bool(enabled)))
    except Exception as exc:
        return False, str(exc)
    error = ""
    try:
        error = character.GetCharacterizeError()
    except Exception:
        error = ""
    return result, error


def _set_character_definition_lock(character, locked):
    if character is None:
        return False
    try:
        character.Lock = bool(locked)
        return True
    except Exception:
        return False


def _set_characterize_off(character):
    if character is None:
        return False
    try:
        character.SetCharacterizeOff()
        return True
    except Exception:
        pass
    try:
        return bool(character.SetCharacterizeOn(False))
    except Exception:
        return False


def _character_input_character(character):
    if character is None:
        return None
    try:
        return character.InputCharacter
    except Exception:
        return None


def _capture_character_input_state(character):
    if character is None:
        return {}
    state = {}
    for attr_name in ("InputCharacter", "InputType", "InputActor", "ActiveInput"):
        try:
            state[attr_name] = getattr(character, attr_name)
        except Exception:
            state[attr_name] = None
    return state


def _restore_character_input_state(character, state, restore_active_input=False):
    if character is None or not state:
        return False
    restored = False
    for attr_name in ("InputCharacter", "InputActor", "InputType"):
        value = state.get(attr_name)
        if value is None:
            continue
        try:
            setattr(character, attr_name, value)
            restored = True
        except Exception:
            pass
    try:
        character.ActiveInput = bool(state.get("ActiveInput")) if restore_active_input else False
        restored = True
    except Exception:
        pass
    return restored


def _characterize_with_roll_fallback(character):
    _set_current_character(character)
    result, error = _set_characterized(character, True)
    clean = _sanitize_motionbuilder_warning_text(error or "")
    cleared = 0
    if clean and "invalid roll" in clean.lower():
        _set_characterize_off(character)
        cleared = _clear_roll_links(character)
        result, error = _set_characterized(character, True)
    if result and not _sanitize_motionbuilder_warning_text(error or ""):
        _set_character_definition_lock(character, True)
    _set_current_character(character)
    return result, error, cleared


def _definition_store_load():
    path = _definition_store_path()
    if not os.path.isfile(path):
        return {"version": 1, "definitions": OrderedDict()}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle, object_pairs_hook=OrderedDict)
    except Exception:
        return {"version": 1, "definitions": OrderedDict()}
    definitions = payload.get("definitions")
    if not isinstance(definitions, dict):
        definitions = OrderedDict()
    payload["definitions"] = OrderedDict(definitions)
    payload["version"] = int(payload.get("version", 1) or 1)
    return payload


def _definition_store_save(payload):
    path = _definition_store_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    return path


def _definition_names():
    return list(_definition_store_load().get("definitions", {}).keys())


def _sanitize_definition_name(name):
    cleaned = re.sub(r"\s+", " ", str(name or "").strip())
    return cleaned or "Character Definition"


def _current_definition_links(character):
    links = OrderedDict()
    if character is None:
        return links
    for slot_name in CHARACTER_SLOT_CANDIDATES:
        prop = character.PropertyList.Find(slot_name, False)
        model = _property_first_src(prop)
        if model is not None:
            links[slot_name] = _component_long_name(model)
    return links


def save_current_character_definition(name=None):
    character, error = _current_character_or_error()
    if error:
        _append_status(_sanitize_motionbuilder_warning_text(error["error"]) or "Character definition needs cleanup.")
        return error
    definition_name = _sanitize_definition_name(name or _component_short_name(character))
    links = _current_definition_links(character)
    if not links:
        result = {"ok": False, "error": "Current character has no definition links to save."}
        _append_status(result["error"])
        return result
    payload = _definition_store_load()
    payload.setdefault("definitions", OrderedDict())
    payload["definitions"][definition_name] = OrderedDict([
        ("name", definition_name),
        ("saved_at", time.strftime("%Y-%m-%d %H:%M:%S")),
        ("source_character", character.LongName),
        ("characterized", bool(character.GetCharacterize())),
        ("core_link_count", _core_link_count(character)),
        ("links", links),
    ])
    path = _definition_store_save(payload)
    result = {
        "ok": True,
        "name": definition_name,
        "path": path,
        "link_count": len(links),
        "core_link_count": _core_link_count(character),
    }
    _append_status("Saved definition {0}: {1} link(s), core {2}/{3}.".format(definition_name, len(links), _core_link_count(character), len(CORE_REQUIRED_LINKS)))
    return result


def _find_definition_model(saved_name, slot_name, indexed):
    if saved_name:
        exact = FBFindModelByLabelName(saved_name)
        if exact is not None:
            return exact
        short_name = _short_name_from_long_name(saved_name)
        exact = FBFindModelByLabelName(short_name)
        if exact is not None:
            return exact
        normalized = _normalize_name(short_name)
        model = indexed.get(normalized)
        if model is not None:
            return model
    return _slot_match_for_index(slot_name, indexed)


def load_character_definition(name):
    definition_name = _sanitize_definition_name(name)
    payload = _definition_store_load()
    definition = payload.get("definitions", {}).get(definition_name)
    if not definition:
        result = {"ok": False, "error": "Definition not found: {0}".format(definition_name)}
        _append_status(result["error"])
        return result
    links = definition.get("links") or {}
    character, error = _current_character_or_error()
    if error:
        namespace_label = definition.get("namespace", "Scene")
        character, _created = _auto_map_target_character(namespace_label)
    FBApplication().CurrentCharacter = character
    was_characterized = bool(character.GetCharacterize())
    if was_characterized:
        _set_character_definition_lock(character, False)
        _set_characterize_off(character)
    namespace, indexed, _score = find_best_skeleton_namespace()
    mapped = OrderedDict()
    missing = []
    used_models = set()
    for slot_name, saved_model_name in links.items():
        model = _find_definition_model(saved_model_name, slot_name, indexed)
        if model is None or _component_long_name(model) in used_models:
            missing.append(slot_name)
            continue
        if _map_model_to_slot(character, slot_name, model):
            model_name = _component_long_name(model)
            mapped[slot_name] = model_name
            used_models.add(model_name)
    characterize_result = False
    characterize_error = ""
    characterize_result, characterize_error, cleared_roll_links = _characterize_with_roll_fallback(character)
    result = {
        "ok": True,
        "name": definition_name,
        "character_name": character.LongName,
        "namespace": namespace,
        "mapped_count": len(mapped),
        "missing": missing,
        "core_link_count": _core_link_count(character),
        "characterized": bool(character.GetCharacterize()),
        "characterize_result": characterize_result,
        "characterize_error": characterize_error,
        "cleared_roll_links": cleared_roll_links,
    }
    lines = [
        "Loaded definition {0}".format(definition_name),
        "Character: {0}".format(character.LongName),
        "Mapped slots: {0}".format(len(mapped)),
        "Core links: {0}/{1}".format(_core_link_count(character), len(CORE_REQUIRED_LINKS)),
        "Characterized: {0}".format(bool(character.GetCharacterize())),
    ]
    if missing:
        lines.append("Missing slots: {0}".format(", ".join(missing[:12])))
    if characterize_error:
        clean_warning = _sanitize_motionbuilder_warning_text(characterize_error)
        if clean_warning:
            lines.append("MotionBuilder warnings: {0}".format(clean_warning.replace("\n", " | ")))
    _append_status("\n".join(lines))
    return result


def rename_character_definition(old_name, new_name):
    old_name = _sanitize_definition_name(old_name)
    new_name = _sanitize_definition_name(new_name)
    payload = _definition_store_load()
    definitions = payload.get("definitions", OrderedDict())
    if old_name not in definitions:
        result = {"ok": False, "error": "Definition not found: {0}".format(old_name)}
        _append_status(result["error"])
        return result
    if new_name in definitions and new_name != old_name:
        result = {"ok": False, "error": "Definition already exists: {0}".format(new_name)}
        _append_status(result["error"])
        return result
    definition = definitions.pop(old_name)
    definition["name"] = new_name
    definitions[new_name] = definition
    payload["definitions"] = definitions
    _definition_store_save(payload)
    result = {"ok": True, "old_name": old_name, "new_name": new_name}
    _append_status("Renamed definition {0} to {1}.".format(old_name, new_name))
    return result


def delete_character_definition(name):
    definition_name = _sanitize_definition_name(name)
    payload = _definition_store_load()
    definitions = payload.get("definitions", OrderedDict())
    if definition_name not in definitions:
        result = {"ok": False, "error": "Definition not found: {0}".format(definition_name)}
        _append_status(result["error"])
        return result
    definitions.pop(definition_name)
    payload["definitions"] = definitions
    _definition_store_save(payload)
    result = {"ok": True, "name": definition_name}
    _append_status("Deleted definition {0}.".format(definition_name))
    return result


def _core_link_count(character):
    count = 0
    for slot_name in CORE_REQUIRED_LINKS:
        prop = character.PropertyList.Find(slot_name, False)
        if prop and _property_src_count(prop) > 0:
            count += 1
    return count


def character_setup_seems_done(character):
    return _core_link_count(character) >= len(CORE_REQUIRED_LINKS)


def maybe_warn_lock_definition(character):
    if character is None:
        return False
    if character.GetCharacterize():
        return False
    if not character_setup_seems_done(character):
        return False
    return _queue_warning(
        "lock_definition",
        LOCK_DEFINITION_WARNING,
        duration_ms=DEFAULT_TOAST_DURATION_MS,
        throttle_seconds=LOCK_WARNING_THROTTLE_SECONDS,
    )


def _control_rig_model_names(character):
    names = set()
    if character is None:
        return names
    for body_node in FBBodyNodeId.values.values():
        try:
            model = character.GetCtrlRigModel(body_node)
        except Exception:
            model = None
        if model is not None:
            names.add(_component_long_name(model))
    return names


def maybe_warn_control_rig_mode(character, model, property_name):
    if character is None or model is None:
        return False
    if str(property_name or "") not in CONTROL_RIG_PROPERTY_NAMES:
        return False
    if character.KeyingMode in (
        FBCharacterKeyingMode.kFBCharacterKeyingBodyPart,
        FBCharacterKeyingMode.kFBCharacterKeyingFullBody,
    ):
        return False
    if _component_long_name(model) not in _control_rig_model_names(character):
        return False
    return _queue_warning(
        "control_rig_mode",
        CONTROL_RIG_MODE_WARNING,
        duration_ms=DEFAULT_TOAST_DURATION_MS,
        throttle_seconds=MODE_WARNING_THROTTLE_SECONDS,
    )


def auto_map_character(create_control_rig=False, characterize=True, activate_input=False):
    scope_error = _require_skeleton_scope_if_needed()
    if scope_error:
        _append_status(scope_error["error"])
        return scope_error
    namespace, indexed, score = find_best_skeleton_namespace()
    if score <= 0:
        result = {"ok": False, "error": "No usable skeleton namespace found.", "namespace": namespace}
        _append_status(result["error"])
        return result
    namespace_label = namespace or "Scene"
    character, character_created = _auto_map_target_character(namespace_label)
    _set_current_character(character)
    was_characterized = bool(character.GetCharacterize())
    if was_characterized:
        _set_characterize_off(character)
    mapped = OrderedDict()
    used_models = set()
    for slot_name in CHARACTER_SLOT_CANDIDATES:
        model = _slot_match_for_index(slot_name, indexed, used_models=used_models)
        if model is None:
            continue
        if slot_name == "HipsTranslationLink" and _component_long_name(model) == mapped.get("HipsLink", ""):
            continue
        if _map_model_to_slot(character, slot_name, model):
            model_name = _component_long_name(model)
            mapped[slot_name] = model_name
            used_models.add(model_name)
    characterize_result = None
    characterize_error = None
    control_rig_result = None
    cleared_roll_links = 0
    if characterize:
        characterize_result, characterize_error, cleared_roll_links = _characterize_with_roll_fallback(character)
    if create_control_rig and character.GetCharacterize():
        try:
            control_rig_result = bool(character.CreateControlRig(True))
        except Exception as exc:
            control_rig_result = False
            characterize_error = str(exc)
    _set_current_character(character)
    if activate_input and character.GetCharacterize():
        try:
            character.ActiveInput = True
        except Exception:
            pass
    maybe_warn_lock_definition(character)
    result = {
        "ok": True,
        "namespace": namespace,
        "skeleton_scope": selected_skeleton_scope_label(),
        "score": score,
        "character_name": character.LongName,
        "character_created": bool(character_created),
        "was_characterized": bool(was_characterized),
        "mapped_slots": dict(mapped),
        "mapped_count": len(mapped),
        "core_link_count": _core_link_count(character),
        "characterized": bool(character.GetCharacterize()),
        "characterize_result": characterize_result,
        "characterize_error": characterize_error,
        "control_rig_result": control_rig_result,
        "cleared_roll_links": cleared_roll_links,
    }
    report_lines = [
        "Auto Map Report",
        "Character: {0}".format(character.LongName),
        "Namespace: {0}".format(namespace_label),
        "Skeleton scope: {0}".format(selected_skeleton_scope_label()),
        "Mapped slots: {0}".format(len(mapped)),
        "Core links: {0}/{1}".format(_core_link_count(character), len(CORE_REQUIRED_LINKS)),
        "Characterized: {0}".format(bool(character.GetCharacterize())),
        "Control rig: {0}".format(bool(control_rig_result)),
    ]
    if characterize_error:
        clean_warning = _sanitize_motionbuilder_warning_text(characterize_error)
        if clean_warning:
            report_lines.append("MotionBuilder warnings: {0}".format(clean_warning.replace("\n", " | ")))
    missing_core = []
    for slot_name in CORE_REQUIRED_LINKS:
        if slot_name not in mapped:
            missing_core.append(slot_name)
    if missing_core:
        report_lines.append("Missing core: {0}".format(", ".join(missing_core)))
    _append_status("\n".join(report_lines))
    _append_status(
        "Auto Map mapped {0} from {1} with {2} mapped slot(s), core {3}/{4}. Characterized: {5}.".format(
            character.LongName,
            namespace_label,
            len(mapped),
            _core_link_count(character),
            len(CORE_REQUIRED_LINKS),
            bool(character.GetCharacterize()),
        )
    )
    return result


def _current_character_or_error():
    character = _current_character()
    if character is None:
        return None, {"ok": False, "error": "No current character."}
    return character, None


def _character_matches_skeleton_scope(character):
    if character is None or not _SKELETON_SCOPE_ROOT_NAME:
        return True
    for slot_name in CORE_REQUIRED_LINKS:
        model = _character_slot_model(character, slot_name)
        if model is not None and _is_model_in_skeleton_scope(model):
            return True
    return False


def _scoped_character_or_error():
    scope_error = _require_skeleton_scope_if_needed()
    if scope_error:
        return None, scope_error
    current = _current_character()
    if _character_matches_skeleton_scope(current):
        if current is None:
            return None, {"ok": False, "error": "No current character."}
        return current, None
    for character in FBSystem().Scene.Characters:
        if _character_matches_skeleton_scope(character):
            _set_current_character(character)
            return character, None
    return None, {
        "ok": False,
        "error": "No characterized character is mapped to selected skeleton scope: {0}.".format(selected_skeleton_scope_label()),
    }


def _character_key_models(character):
    models = OrderedDict()
    if character is None:
        return []
    for body_node in FBBodyNodeId.values.values():
        try:
            model = character.GetCtrlRigModel(body_node)
        except Exception:
            model = None
        if model is not None:
            models.setdefault(_component_long_name(model), model)
    if models:
        return list(models.values())
    for slot_name in CHARACTER_SLOT_CANDIDATES:
        prop = character.PropertyList.Find(slot_name, False)
        model = _property_first_src(prop)
        if model is not None:
            models.setdefault(_component_long_name(model), model)
    return list(models.values())


def _character_slot_model(character, slot_name):
    if character is None:
        return None
    prop = character.PropertyList.Find(slot_name, False)
    return _property_first_src(prop)


def _model_world_vector(model, transform_type):
    vector = FBVector3d()
    try:
        model.GetVector(vector, transform_type, True)
        return (float(vector[0]), float(vector[1]), float(vector[2]))
    except Exception:
        return None


def _model_world_translation(model):
    return _model_world_vector(model, FBModelTransformationType.kModelTranslation)


def _model_world_rotation(model):
    return _model_world_vector(model, FBModelTransformationType.kModelRotation)


def _set_model_world_rotation(model, rotation):
    try:
        model.SetVector(
            FBVector3d(float(rotation[0]), float(rotation[1]), float(rotation[2])),
            FBModelTransformationType.kModelRotation,
            True,
        )
        return True
    except Exception:
        return False


def _v_sub(left, right):
    return (left[0] - right[0], left[1] - right[1], left[2] - right[2])


def _v_mul(value, scale):
    return (value[0] * scale, value[1] * scale, value[2] * scale)


def _v_dot(left, right):
    return left[0] * right[0] + left[1] * right[1] + left[2] * right[2]


def _v_cross(left, right):
    return (
        left[1] * right[2] - left[2] * right[1],
        left[2] * right[0] - left[0] * right[2],
        left[0] * right[1] - left[1] * right[0],
    )


def _v_len(value):
    return math.sqrt(max(_v_dot(value, value), 0.0))


def _v_norm(value, fallback=None):
    length = _v_len(value)
    if length <= 0.000001:
        return fallback
    return (value[0] / length, value[1] / length, value[2] / length)


def _quat_norm(quat):
    length = math.sqrt(sum(item * item for item in quat))
    if length <= 0.000001:
        return (1.0, 0.0, 0.0, 0.0)
    return tuple(item / length for item in quat)


def _quat_mul(left, right):
    lw, lx, ly, lz = left
    rw, rx, ry, rz = right
    return (
        lw * rw - lx * rx - ly * ry - lz * rz,
        lw * rx + lx * rw + ly * rz - lz * ry,
        lw * ry - lx * rz + ly * rw + lz * rx,
        lw * rz + lx * ry - ly * rx + lz * rw,
    )


def _quat_from_vectors(source, target):
    source = _v_norm(source, (1.0, 0.0, 0.0))
    target = _v_norm(target, (1.0, 0.0, 0.0))
    dot = max(-1.0, min(1.0, _v_dot(source, target)))
    if dot < -0.999999:
        axis = _v_cross((1.0, 0.0, 0.0), source)
        if _v_len(axis) <= 0.000001:
            axis = _v_cross((0.0, 1.0, 0.0), source)
        axis = _v_norm(axis, (0.0, 0.0, 1.0))
        return (0.0, axis[0], axis[1], axis[2])
    cross = _v_cross(source, target)
    return _quat_norm((1.0 + dot, cross[0], cross[1], cross[2]))


def _quat_from_euler(rotation):
    x = math.radians(rotation[0]) * 0.5
    y = math.radians(rotation[1]) * 0.5
    z = math.radians(rotation[2]) * 0.5
    cx, sx = math.cos(x), math.sin(x)
    cy, sy = math.cos(y), math.sin(y)
    cz, sz = math.cos(z), math.sin(z)
    return _quat_norm((
        cx * cy * cz + sx * sy * sz,
        sx * cy * cz - cx * sy * sz,
        cx * sy * cz + sx * cy * sz,
        cx * cy * sz - sx * sy * cz,
    ))


def _euler_from_quat(quat):
    w, x, y, z = _quat_norm(quat)
    sinr = 2.0 * (w * x + y * z)
    cosr = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr, cosr)
    sinp = 2.0 * (w * y - z * x)
    if abs(sinp) >= 1.0:
        pitch = math.copysign(math.pi * 0.5, sinp)
    else:
        pitch = math.asin(sinp)
    siny = 2.0 * (w * z + x * y)
    cosy = 1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(siny, cosy)
    return (math.degrees(roll), math.degrees(pitch), math.degrees(yaw))


def _evaluate_scene():
    try:
        FBSystem().Scene.Evaluate()
    except Exception:
        pass


def _align_model_segment(parent, child, desired_direction):
    parent_pos = _model_world_translation(parent)
    child_pos = _model_world_translation(child)
    rotation = _model_world_rotation(parent)
    desired = _v_norm(desired_direction)
    if parent_pos is None or child_pos is None or rotation is None or desired is None:
        return False
    current = _v_norm(_v_sub(child_pos, parent_pos))
    if current is None:
        return False
    delta = _quat_from_vectors(current, desired)
    result = _quat_mul(delta, _quat_from_euler(rotation))
    if not _set_model_world_rotation(parent, _euler_from_quat(result)):
        return False
    _evaluate_scene()
    return True


def _slot_pos(character, slot_name):
    model = _character_slot_model(character, slot_name)
    if model is None:
        return None
    return _model_world_translation(model)


def _direction_between(character, start_slot, end_slot, fallback=None):
    start = _slot_pos(character, start_slot)
    end = _slot_pos(character, end_slot)
    if start is None or end is None:
        return fallback
    return _v_norm(_v_sub(end, start), fallback)


def _tpose_reference_axes(character):
    side_hint = (
        _direction_between(character, "RightArmLink", "LeftArmLink")
        or _direction_between(character, "RightShoulderLink", "LeftShoulderLink")
        or _direction_between(character, "RightUpLegLink", "LeftUpLegLink")
        or (1.0, 0.0, 0.0)
    )
    # MotionBuilder's definition check expects a world-upright stance: spine on Y,
    # arms on X. Body-derived axes can preserve a bad forward lean.
    up = (0.0, 1.0, 0.0)
    left = (1.0, 0.0, 0.0) if _v_dot(side_hint, (1.0, 0.0, 0.0)) >= 0.0 else (-1.0, 0.0, 0.0)
    return {
        "up": up,
        "down": _v_mul(up, -1.0),
        "left": left,
        "right": _v_mul(left, -1.0),
    }


def _align_tpose_chain(character, slots, direction):
    aligned = 0
    existing = []
    seen = set()
    for slot_name in slots:
        model = _character_slot_model(character, slot_name)
        model_name = _component_long_name(model)
        if model is None or not model_name or model_name in seen:
            continue
        seen.add(model_name)
        existing.append((slot_name, model))
    for (_parent_slot, parent), (_child_slot, child) in zip(existing, existing[1:]):
        if parent is None or child is None:
            continue
        if _align_model_segment(parent, child, direction):
            aligned += 1
    return aligned


def _apply_skeleton_tpose(character):
    axes = _tpose_reference_axes(character)
    aligned = 0
    spine_slots = [
        "HipsLink",
        "SpineLink",
        "Spine1Link",
        "Spine2Link",
        "Spine3Link",
        "Spine4Link",
        "Spine5Link",
        "Spine6Link",
        "Spine7Link",
        "Spine8Link",
        "Spine9Link",
        "NeckLink",
        "Neck1Link",
        "Neck2Link",
        "HeadLink",
    ]
    left_arm = ["LeftShoulderLink", "LeftArmLink", "LeftForeArmLink", "LeftHandLink"]
    right_arm = ["RightShoulderLink", "RightArmLink", "RightForeArmLink", "RightHandLink"]
    left_leg = ["LeftUpLegLink", "LeftLegLink", "LeftFootLink"]
    right_leg = ["RightUpLegLink", "RightLegLink", "RightFootLink"]
    for _pass_index in range(3):
        axes = _tpose_reference_axes(character)
        aligned += _align_tpose_chain(character, spine_slots, axes["up"])
        aligned += _align_tpose_chain(character, left_arm, axes["left"])
        aligned += _align_tpose_chain(character, right_arm, axes["right"])
        aligned += _align_tpose_chain(character, left_leg, axes["down"])
        aligned += _align_tpose_chain(character, right_leg, axes["down"])
        if TPOSE_ALIGN_FINGERS:
            for side, direction in (("Left", axes["left"]), ("Right", axes["right"])):
                for finger in ("Thumb", "Index", "Middle", "Ring", "Pinky"):
                    slots = ["{0}HandLink".format(side)]
                    for index in range(1, 5):
                        slots.append("{0}Hand{1}{2}Link".format(side, finger, index))
                    aligned += _align_tpose_chain(character, slots, direction)
    return aligned


def _tpose_arm_axis_report(character):
    axes = _tpose_reference_axes(character)
    checks = (
        ("LeftShoulderLink", "LeftArmLink", axes["left"]),
        ("LeftArmLink", "LeftForeArmLink", axes["left"]),
        ("LeftForeArmLink", "LeftHandLink", axes["left"]),
        ("RightShoulderLink", "RightArmLink", axes["right"]),
        ("RightArmLink", "RightForeArmLink", axes["right"]),
        ("RightForeArmLink", "RightHandLink", axes["right"]),
    )
    dots = []
    failures = []
    for start_slot, end_slot, target in checks:
        direction = _direction_between(character, start_slot, end_slot)
        if direction is None:
            continue
        dot = _v_dot(direction, target)
        dots.append(dot)
        if dot < TPOSE_AXIS_DOT_THRESHOLD:
            failures.append("{0}->{1} {2:.3f}".format(start_slot, end_slot, dot))
    return {
        "min_dot": min(dots) if dots else 0.0,
        "failures": failures,
        "ok": bool(dots) and not failures,
    }


def _tpose_body_axis_report(character):
    axes = _tpose_reference_axes(character)
    checks = (
        ("HipsLink", "SpineLink", axes["up"]),
        ("SpineLink", "HeadLink", axes["up"]),
        ("LeftUpLegLink", "LeftLegLink", axes["down"]),
        ("LeftLegLink", "LeftFootLink", axes["down"]),
        ("RightUpLegLink", "RightLegLink", axes["down"]),
        ("RightLegLink", "RightFootLink", axes["down"]),
    )
    dots = []
    failures = []
    for start_slot, end_slot, target in checks:
        direction = _direction_between(character, start_slot, end_slot)
        if direction is None:
            continue
        dot = _v_dot(direction, target)
        dots.append(dot)
        if dot < TPOSE_AXIS_DOT_THRESHOLD:
            failures.append("{0}->{1} {2:.3f}".format(start_slot, end_slot, dot))
    return {
        "min_dot": min(dots) if dots else 0.0,
        "failures": failures,
        "ok": bool(dots) and not failures,
    }


def _preferred_tpose_character_or_error():
    current = _current_character()
    if current is not None and _character_input_character(current) is not None:
        return current, None
    scope_error = _require_skeleton_scope_if_needed()
    if scope_error:
        return None, scope_error
    if _character_matches_skeleton_scope(current):
        if current is None:
            return None, {"ok": False, "error": "No current character."}
        return current, None
    for character in FBSystem().Scene.Characters:
        if _character_matches_skeleton_scope(character):
            _set_current_character(character)
            return character, None
    return None, {
        "ok": False,
        "error": "No characterized character is mapped to selected skeleton scope: {0}.".format(selected_skeleton_scope_label()),
    }


def _ordered_tpose_characters(character):
    if character is None:
        return []
    ordered = []
    source = _character_input_character(character)
    if source is not None and source is not character:
        ordered.append(source)
    ordered.append(character)
    seen = set()
    unique = []
    for item in ordered:
        name = _component_long_name(item)
        if not name or name in seen:
            continue
        seen.add(name)
        unique.append(item)
    return unique


def _make_single_character_tpose_on_frame_zero(character, key_skeleton=True, key_control_rig=False, retarget_source=None):
    _set_current_character(character)
    was_characterized = bool(character.GetCharacterize())
    if not was_characterized:
        result = {"ok": False, "error": "Current character is not characterized. Auto Map Skeleton first."}
        _append_status(result["error"])
        return result
    input_state = _capture_character_input_state(character)
    try:
        character.ActiveInput = False
    except Exception:
        pass
    _set_character_definition_lock(character, False)
    _set_characterize_off(character)
    harmonized_slots = _harmonize_optional_retarget_slots(character, retarget_source)

    player = FBPlayerControl()
    frame_zero = FBTime(0, 0, 0, 0)
    try:
        player.Goto(frame_zero, FBTimeReferential.kFBTimeReferentialEdit)
    except Exception:
        try:
            player.Goto(frame_zero)
        except Exception:
            pass
    aligned_segments = _apply_skeleton_tpose(character)
    _evaluate_scene()
    characterize_result, characterize_error, cleared_roll_links = _characterize_with_roll_fallback(character)
    _set_current_character(character)
    axis_report = _tpose_arm_axis_report(character)
    body_report = _tpose_body_axis_report(character)
    if not axis_report["ok"] or not body_report["ok"]:
        _set_characterize_off(character)
        aligned_segments += _apply_skeleton_tpose(character)
        _evaluate_scene()
        characterize_result, characterize_error, cleared_roll_links_retry = _characterize_with_roll_fallback(character)
        cleared_roll_links += cleared_roll_links_retry
        _set_current_character(character)
        axis_report = _tpose_arm_axis_report(character)
        body_report = _tpose_body_axis_report(character)
    _restore_character_input_state(character, input_state, restore_active_input=False)
    stance_pose_ok = bool(character.GetCharacterize()) and not bool(characterize_error) and bool(axis_report["ok"]) and bool(body_report["ok"])

    keyed_models = 0
    keyed_channels = 0
    for model in _character_key_models(character):
        if not key_control_rig and _component_long_name(model).find("_Ctrl:") >= 0:
            continue
        for prop_name in CONTROL_RIG_PROPERTY_NAMES:
            keyed = _key_model_property_at_time(model, prop_name, frame_zero)
            if keyed:
                keyed_channels += keyed
        keyed_models += 1
    if key_skeleton:
        for slot_name in CHARACTER_SLOT_CANDIDATES:
            prop = character.PropertyList.Find(slot_name, False)
            model = _property_first_src(prop)
            if model is None:
                continue
            for prop_name in CONTROL_RIG_PROPERTY_NAMES:
                keyed_channels += _key_model_property_at_time(model, prop_name, frame_zero)

    try:
        player.Goto(frame_zero, FBTimeReferential.kFBTimeReferentialEdit)
    except Exception:
        try:
            player.Goto(frame_zero)
        except Exception:
            pass
    result = {
        "ok": True,
        "character_name": character.LongName,
        "skeleton_scope": selected_skeleton_scope_label(),
        "frame": 0,
        "keyed_models": keyed_models,
        "keyed_channels": keyed_channels,
        "characterized": bool(character.GetCharacterize()),
        "stance_pose_ok": stance_pose_ok,
        "aligned_segments": aligned_segments,
        "cleared_roll_links": cleared_roll_links,
        "characterize_result": characterize_result,
        "characterize_error": characterize_error,
        "tpose_axis_min_dot": axis_report["min_dot"],
        "tpose_axis_failures": axis_report["failures"],
        "tpose_body_min_dot": body_report["min_dot"],
        "tpose_body_failures": body_report["failures"],
        "harmonized_retarget_slots": harmonized_slots,
        "input_source": _component_long_name(_character_input_character(character)),
        "active_input_after": bool(getattr(character, "ActiveInput", False)),
    }
    return result


def make_tpose_on_frame_zero(key_skeleton=True, key_control_rig=False):
    character, error = _preferred_tpose_character_or_error()
    if error:
        _append_status(error["error"])
        return error
    results = []
    for item in _ordered_tpose_characters(character):
        retarget_source = _character_input_character(item) if item is character else None
        result = _make_single_character_tpose_on_frame_zero(
            item,
            key_skeleton=key_skeleton,
            key_control_rig=key_control_rig,
            retarget_source=retarget_source,
        )
        results.append(result)
        if not result.get("ok"):
            return result
    result = results[-1] if results else {"ok": False, "error": "No character to T-pose."}
    result = dict(result)
    result["characters_tposed"] = [
        item.get("character_name")
        for item in results
        if item.get("character_name")
    ]
    _append_status(
        "T-Pose Frame 0 keyed {0}: frame 0 only, {1} character(s), green check {2}, arm axis {3:.3f}, body axis {4:.3f}. Source link kept, input left off for definition check.".format(
            character.LongName,
            len(results),
            result.get("stance_pose_ok"),
            result.get("tpose_axis_min_dot", 0.0),
            result.get("tpose_body_min_dot", 0.0),
        )
    )
    for item in results:
        _append_status(
            "T-Pose detail {0} on {1}: {2} segment(s), {3} model(s), {4} channel key(s), green check {5}, arm axis {6:.3f}, body axis {7:.3f}.".format(
                item.get("character_name"),
                selected_skeleton_scope_label(),
                item.get("aligned_segments"),
                item.get("keyed_models"),
                item.get("keyed_channels"),
                item.get("stance_pose_ok"),
                item.get("tpose_axis_min_dot", 0.0),
                item.get("tpose_body_min_dot", 0.0),
            )
        )
        characterize_error = item.get("characterize_error")
        if characterize_error:
            clean_warning = _sanitize_motionbuilder_warning_text(characterize_error)
            if clean_warning:
                _append_status("MotionBuilder warnings: {0}".format(clean_warning.replace("\n", " | ")))
        harmonized = item.get("harmonized_retarget_slots") or []
        if harmonized:
            _append_status(
                "Retarget match removed target-only optional slot(s): {0}.".format(
                    ", ".join(harmonized)
                )
            )
    return result


def make_tpose_on_frame_one(key_skeleton=True, key_control_rig=False):
    return make_tpose_on_frame_zero(key_skeleton=key_skeleton, key_control_rig=key_control_rig)


def validate_current_character():
    character = _current_character()
    if character is None:
        result = {"ok": False, "error": "No current character."}
        _append_status(result["error"])
        return result
    current_control_set = None
    try:
        current_control_set = character.GetCurrentControlSet()
    except Exception:
        current_control_set = None
    lock_warning = maybe_warn_lock_definition(character)
    result = {
        "ok": True,
        "character_name": character.LongName,
        "characterized": bool(character.GetCharacterize()),
        "core_link_count": _core_link_count(character),
        "has_control_set": bool(current_control_set),
        "keying_mode": str(character.KeyingMode),
        "lock_warning": bool(lock_warning),
    }
    _append_status(
        "Validate Character: {0} | Characterized {1} | Control Rig {2} | Keying {3}".format(
            character.LongName,
            bool(character.GetCharacterize()),
            bool(current_control_set),
            character.KeyingMode,
        )
    )
    return result


def set_keying_mode_body_part():
    character = _current_character()
    if character is None:
        _append_status("Body Part Mode could not run: no current character.")
        return False
    character.KeyingMode = FBCharacterKeyingMode.kFBCharacterKeyingBodyPart
    _append_status("Keying mode switched to Body Part.")
    return True


def set_keying_mode_full_body():
    character = _current_character()
    if character is None:
        _append_status("Full Body Mode could not run: no current character.")
        return False
    character.KeyingMode = FBCharacterKeyingMode.kFBCharacterKeyingFullBody
    _append_status("Keying mode switched to Full Body.")
    return True


def handle_transform_attempt(model, property_name):
    character = _current_character()
    return maybe_warn_control_rig_mode(character, model, property_name)


def _on_scene_change(control, event):
    character = _current_character()
    if character is not None:
        maybe_warn_lock_definition(character)


def _on_take_change(control, event):
    apply_prop_offsets_for_current_take()


def _on_connection_data_notify(control, event):
    plug = getattr(event, "Plug", None)
    if plug is None:
        return
    property_name = ""
    try:
        property_name = plug.Name
    except Exception:
        try:
            property_name = plug.GetName()
        except Exception:
            property_name = ""
    if property_name not in CONTROL_RIG_PROPERTY_NAMES:
        return
    try:
        owner = plug.GetOwner()
    except Exception:
        owner = None
    if not isinstance(owner, FBModel):
        return
    maybe_warn_control_rig_mode(_current_character(), owner, property_name)


def _on_file_exit(control=None, event=None):
    remove_runtime_watchers()


def install_runtime_watchers():
    global _CALLBACKS_INSTALLED
    if _CALLBACKS_INSTALLED:
        return
    system = FBSystem()
    app = FBApplication()
    system.Scene.OnChange.Add(_on_scene_change)
    try:
        system.Scene.OnTakeChange.Add(_on_take_change)
    except Exception:
        pass
    system.OnConnectionDataNotify.Add(_on_connection_data_notify)
    app.OnFileExit.Add(_on_file_exit)
    _CALLBACKS_INSTALLED = True


def remove_runtime_watchers():
    global _CALLBACKS_INSTALLED
    if not _CALLBACKS_INSTALLED:
        return
    system = FBSystem()
    app = FBApplication()
    try:
        system.Scene.OnChange.Remove(_on_scene_change)
    except Exception:
        pass
    try:
        system.Scene.OnTakeChange.Remove(_on_take_change)
    except Exception:
        pass
    try:
        system.OnConnectionDataNotify.Remove(_on_connection_data_notify)
    except Exception:
        pass
    try:
        app.OnFileExit.Remove(_on_file_exit)
    except Exception:
        pass
    _CALLBACKS_INSTALLED = False


def _tool_intro_lines():
    return [
        TOOL_NAME + "  " + TOOL_VERSION,
        "",
        "Scene Cleaner removes user cameras, deletes junk default markers, and renames animated default markers as prop markers.",
        "History Timeline saves full-scene MotionBuilder snapshot branches beside the current scene.",
        "Constraints Manager renames constraints, keys Weight/Active style properties at current time, and opens bake/save options.",
        "Prop Take Offset Manager stores constraint offsets per take so props can start in different places without immediate bake loops.",
        "Use Save To Skeleton or Save To Control Rig after constraints are keyed so constrained motion becomes normal keys.",
        SCENE_CLEANER_HINT,
        "",
        "Auto Map builds a MotionBuilder character from the best skeleton namespace and tries to characterize it all the way through fingers and extra spine links.",
        "",
        "If the character looks mapped but not locked, Aminate Mobu shows a lock-definition popup.",
        "If a control rig translate or rotate happens while keying mode is Selection, Aminate Mobu warns to use Body Part or Full Body.",
    ]


def _refresh_dashboard():
    character = _current_character()
    cameras, junk_markers, prop_markers = collect_scene_clean_targets()
    summary = [
        TOOL_NAME + "  " + TOOL_VERSION,
        _character_summary(character),
        "Scene Cleaner Targets: {0} camera(s)  {1} junk marker(s)  {2} prop marker(s)".format(
            len(cameras),
            len(junk_markers),
            len(prop_markers),
        ),
        "Skeleton Scope: {0}".format(selected_skeleton_scope_label()),
        "Managed Constraints: {0}".format(len(_actionable_constraints(_scene_constraints()))),
        "Prop Marker Base Name: {0}".format(get_prop_marker_base_name()),
        "Current Scene: {0}".format(FBApplication().FBXFileName or "Untitled"),
        "",
    ]
    summary.extend(_tool_intro_lines()[2:])
    summary.append("")
    summary.extend(_STATUS_LINES[-10:])
    _set_status_lines(summary)


def _button(caption, callback, color=None):
    button = FBButton()
    button.Caption = caption
    button.Look = FBButtonLook.kFBLookColorChange
    button.Style = FBButtonStyle.kFBPushButton
    button.Justify = FBTextJustify.kFBTextJustifyCenter
    if color is not None:
        button.SetStateColor(FBButtonState.kFBButtonState0, FBColor(*color))
    button.OnClick.Add(callback)
    return button


def _on_refresh(control=None, event=None):
    validate_current_character()
    _refresh_dashboard()


def _on_clean_scene(control=None, event=None, prop_marker_base_name=None):
    run_scene_cleaner(
        delete_cameras=True,
        delete_unlabelled_markers=True,
        prop_marker_base_name=prop_marker_base_name,
    )
    _refresh_dashboard()


def _on_clean_cameras(control=None, event=None):
    run_scene_cleaner(delete_cameras=True, delete_unlabelled_markers=False)
    _refresh_dashboard()


def _on_clean_markers(control=None, event=None, prop_marker_base_name=None):
    run_scene_cleaner(
        delete_cameras=False,
        delete_unlabelled_markers=True,
        prop_marker_base_name=prop_marker_base_name,
    )
    _refresh_dashboard()


def _on_auto_map(control=None, event=None):
    auto_map_character(create_control_rig=False, characterize=True, activate_input=False)
    _refresh_dashboard()


def _on_use_selected_skeleton(control=None, event=None):
    set_selected_skeleton_scope_from_selection()
    _refresh_dashboard()


def _on_tpose_frame_zero(control=None, event=None):
    make_tpose_on_frame_zero(key_skeleton=True, key_control_rig=False)
    _refresh_dashboard()


def _on_tpose_frame_one(control=None, event=None):
    _on_tpose_frame_zero(control, event)


def _on_validate(control=None, event=None):
    validate_current_character()
    _refresh_dashboard()


def _on_body_part(control=None, event=None):
    set_keying_mode_body_part()
    _refresh_dashboard()


def _on_full_body(control=None, event=None):
    set_keying_mode_full_body()
    _refresh_dashboard()


def _on_history_timeline(control=None, event=None):
    import aminate_mobu_history

    aminate_mobu_history.launch_motionbuilder_history_timeline()
    _append_status("Opened Aminate Mobu History Timeline.")
    _refresh_dashboard()


def _on_rename_constraints_easy(control=None, event=None):
    rename_constraints_to_easy_names(_scene_constraints())
    _refresh_dashboard()


def _on_key_constraints(control=None, event=None):
    key_constraint_properties(_scene_constraints())
    _refresh_dashboard()


def _on_preview_prop_offset(control=None, event=None):
    preview_prop_offset(_scene_constraints())
    _refresh_dashboard()


def _on_prop_offset_this_take(control=None, event=None):
    set_prop_offset_for_take(_scene_constraints())
    _refresh_dashboard()


def _on_prop_offset_all_takes(control=None, event=None):
    set_prop_offset_for_all_takes(_scene_constraints())
    _refresh_dashboard()


def _on_mute_prop_constraints(control=None, event=None):
    mute_prop_constraints_for_setup(_scene_constraints())
    _refresh_dashboard()


def _on_restore_prop_constraints(control=None, event=None):
    restore_prop_constraints_after_setup(_scene_constraints())
    _refresh_dashboard()


if QtWidgets:
    class AspectRatioPixmapLabel(QtWidgets.QLabel):
        def __init__(self, parent=None):
            super(AspectRatioPixmapLabel, self).__init__(parent)
            self._source_pixmap = None
            self.setAlignment(QtCore.Qt.AlignCenter)
            self.setScaledContents(False)

        def setAspectPixmap(self, pixmap):
            self._source_pixmap = pixmap if pixmap is not None and not pixmap.isNull() else None
            self._refresh_scaled_pixmap()

        def clear(self):
            self._source_pixmap = None
            super(AspectRatioPixmapLabel, self).clear()

        def resizeEvent(self, event):
            super(AspectRatioPixmapLabel, self).resizeEvent(event)
            self._refresh_scaled_pixmap()

        def _refresh_scaled_pixmap(self):
            if self._source_pixmap is None:
                return
            size = self.contentsRect().size()
            if size.width() <= 0 or size.height() <= 0:
                return
            scaled = self._source_pixmap.scaled(
                size,
                QtCore.Qt.KeepAspectRatio,
                QtCore.Qt.SmoothTransformation,
            )
            super(AspectRatioPixmapLabel, self).setPixmap(scaled)


    class AminateMobuPanel(QtWidgets.QWidget):
        def __init__(self, parent=None):
            super(AminateMobuPanel, self).__init__(parent)
            self.theme_key = set_active_theme(THEME_MODERN)
            self._collapsed = False
            self._build_version = QT_PANEL_BUILD_VERSION
            self.setObjectName(QT_WINDOW_OBJECT_NAME)
            self.setMinimumSize(220, 260)
            self.resize(520, 640)
            self._build_ui()
            self._apply_theme(self.theme_key)
            try:
                self.destroyed.connect(
                    lambda *_args, panel_id=id(self): _on_qt_panel_destroyed(panel_id)
                )
            except Exception:
                pass

        def _build_ui(self):
            main_layout = QtWidgets.QVBoxLayout(self)
            main_layout.setContentsMargins(6, 6, 6, 6)
            main_layout.setSpacing(5)
            header_layout = QtWidgets.QVBoxLayout()
            header_layout.setSpacing(4)
            header_text_layout = QtWidgets.QVBoxLayout()
            header_text_layout.setSpacing(0)
            self.header_title = QtWidgets.QLabel(TOOL_NAME)
            self.header_title.setObjectName("aminateMobuHeaderTitle")
            self.header_title.setToolTip("Main Aminate Mobu panel title.")
            header_text_layout.addWidget(self.header_title)
            self.header_subtitle = QtWidgets.QLabel("Choose a workflow tab below.")
            self.header_subtitle.setObjectName("aminateMobuHeaderSubtitle")
            self.header_subtitle.setToolTip("Switch tabs to open each Aminate Mobu workflow.")
            header_text_layout.addWidget(self.header_subtitle)
            header_layout.addLayout(header_text_layout)
            header_controls_layout = QtWidgets.QGridLayout()
            header_controls_layout.setHorizontalSpacing(5)
            header_controls_layout.setVerticalSpacing(4)
            self.theme_badge = QtWidgets.QLabel()
            self.theme_badge.setObjectName("aminateMobuThemeBadge")
            self.theme_badge.setToolTip("Shows which Aminate theme is active.")
            header_controls_layout.addWidget(self.theme_badge, 0, 0)
            self.theme_button = QtWidgets.QPushButton()
            self.theme_button.setObjectName("aminateMobuThemeToggle")
            self.theme_button.clicked.connect(self._toggle_theme)
            header_controls_layout.addWidget(self.theme_button, 0, 1)
            header_controls_layout.setColumnStretch(1, 1)
            self.collapse_button = QtWidgets.QPushButton("Hide Panel")
            self.collapse_button.setToolTip("Collapse Aminate into a thin side panel.")
            self.collapse_button.clicked.connect(self._toggle_collapsed)
            header_controls_layout.addWidget(self.collapse_button, 1, 0, 1, 2)
            header_layout.addLayout(header_controls_layout)
            main_layout.addLayout(header_layout)
            self.body_container = QtWidgets.QWidget()
            self.body_container.setObjectName("aminateMobuBodyContainer")
            self.body_container.setMinimumWidth(0)
            self.body_container.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
            body_layout = QtWidgets.QVBoxLayout(self.body_container)
            body_layout.setContentsMargins(0, 0, 0, 0)
            body_layout.setSpacing(5)
            self.status_label = QtWidgets.QLabel("Ready.")
            self.status_label.setObjectName("mayaAnimWorkflowStatusLabel")
            self.status_label.setWordWrap(True)
            self.status_label.setToolTip("This line shows the newest Aminate status message.")
            self.status_memo = QtWidgets.QPlainTextEdit()
            self.status_memo.setReadOnly(True)
            self.status_memo.setObjectName("aminateMobuStatusMemo")
            self.status_memo.setToolTip("This area shows the full Aminate run history for the current session.")
            self.status_memo.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)

            self.workflow_tabs = QtWidgets.QTabWidget()
            self.workflow_tabs.setObjectName("aminateMobuWorkflowTabs")
            self.workflow_tabs.setUsesScrollButtons(True)
            self.workflow_tabs.setDocumentMode(False)
            self.workflow_tabs.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
            try:
                workflow_tab_bar = self.workflow_tabs.tabBar()
                workflow_tab_bar.setElideMode(QtCore.Qt.ElideRight)
                workflow_tab_bar.setExpanding(False)
            except Exception:
                pass

            cleanup_page, cleanup_layout = self._build_workflow_page(
                "aminateMobuCleanupPage",
                "Scene Cleanup",
                "Remove scene junk safely while preserving useful animated prop markers.",
            )
            cleanup_layout.addWidget(self._build_cleanup_group())
            cleanup_layout.addWidget(self._build_note_group())
            cleanup_layout.addStretch(1)
            cleanup_index = self.workflow_tabs.addTab(cleanup_page, "Cln")
            self.workflow_tabs.setTabToolTip(cleanup_index, "Scene Cleanup")

            hik_page, hik_layout = self._build_workflow_page(
                "aminateMobuHikPage",
                "HIK Mapping",
                "Choose one skeleton, build its HumanIK definition, validate it, and prepare a T-pose.",
            )
            hik_layout.addWidget(self._build_hik_mapping_group())
            hik_layout.addWidget(self._build_definition_manager_group())
            hik_layout.addStretch(1)
            hik_index = self.workflow_tabs.addTab(hik_page, "HIK")
            self.workflow_tabs.setTabToolTip(hik_index, "HIK Mapping")

            warnings_page, warnings_layout = self._build_workflow_page(
                "aminateMobuWarningsPage",
                "Setup Warnings",
                "Check the current character and review warnings about unlocked definitions or unsafe control-rig keying modes.",
            )
            warnings_layout.addWidget(self._build_setup_warnings_group())
            warnings_layout.addWidget(self.status_memo, 1)
            warnings_index = self.workflow_tabs.addTab(warnings_page, "Wrn")
            self.workflow_tabs.setTabToolTip(warnings_index, "Setup Warnings")

            constraints_page, constraints_layout = self._build_workflow_page(
                "aminateMobuConstraintsPage",
                "Constraints",
                "Inspect, rename, key, offset, and bake MotionBuilder constraints.",
            )
            constraints_layout.addWidget(self._build_constraints_manager_group(), 1)
            constraints_index = self.workflow_tabs.addTab(constraints_page, "Con")
            self.workflow_tabs.setTabToolTip(constraints_index, "Constraints")

            history_page, history_layout = self._build_workflow_page(
                "aminateMobuHistoryPage",
                "History",
                "Open the full-scene History Timeline for snapshots, restores, branches, and Auto History.",
            )
            history_layout.addWidget(self._build_history_group())
            history_layout.addStretch(1)
            history_index = self.workflow_tabs.addTab(history_page, "Hist")
            self.workflow_tabs.setTabToolTip(history_index, "History")

            body_layout.addWidget(self.workflow_tabs, 1)
            body_layout.addWidget(self.status_label)
            footer_layout = QtWidgets.QGridLayout()
            footer_layout.setContentsMargins(0, 0, 0, 0)
            footer_layout.setHorizontalSpacing(6)
            footer_layout.setVerticalSpacing(2)
            self.brand_label = QtWidgets.QLabel(
                'Built by Amir. Follow Amir at <a href="{0}">followamir.com</a>.'.format(FOLLOW_AMIR_URL)
            )
            self.brand_label.setObjectName("mayaAnimWorkflowBrandLabel")
            self.brand_label.setOpenExternalLinks(False)
            self.brand_label.linkActivated.connect(self._open_follow_url)
            self.brand_label.setWordWrap(True)
            self.brand_label.setToolTip("Open followamir.com.")
            footer_layout.addWidget(self.brand_label, 0, 0, 1, 2)
            self.version_label = QtWidgets.QLabel(TOOL_VERSION)
            self.version_label.setObjectName("mayaAnimWorkflowVersionLabel")
            self.version_label.setToolTip("Shows which Aminate Mobu build is loaded.")
            footer_layout.addWidget(self.version_label, 1, 0)
            self.donate_button = QtWidgets.QPushButton("Donate")
            self.donate_button.setToolTip("Open Amir's PayPal donate link. Set AMIR_PAYPAL_DONATE_URL or AMIR_DONATE_URL to customize it.")
            self.donate_button.clicked.connect(self._open_donate_url)
            footer_layout.addWidget(self.donate_button, 1, 1)
            footer_layout.setColumnStretch(0, 1)
            body_layout.addLayout(footer_layout)
            self.scroll_area = QtWidgets.QScrollArea()
            self.scroll_area.setObjectName("aminateMobuScrollArea")
            self.scroll_area.setWidgetResizable(True)
            self.scroll_area.setFrameShape(QtWidgets.QFrame.NoFrame)
            self.scroll_area.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
            self.scroll_area.setWidget(self.body_container)
            main_layout.addWidget(self.scroll_area, 1)
            self._refresh_warning_history_view()

        def _build_intro_card(self, title_text, body_text):
            frame = QtWidgets.QFrame()
            frame.setObjectName("mayaAnimWorkflowTabIntro")
            inner = QtWidgets.QVBoxLayout(frame)
            inner.setContentsMargins(8, 6, 8, 6)
            inner.setSpacing(2)
            title = QtWidgets.QLabel(title_text)
            title.setObjectName("mayaAnimWorkflowIntroTitle")
            body = QtWidgets.QLabel(body_text)
            body.setObjectName("mayaAnimWorkflowIntroBody")
            body.setWordWrap(True)
            inner.addWidget(title)
            inner.addWidget(body)
            return frame

        def _build_workflow_page(self, object_name, title_text, body_text):
            scroll = QtWidgets.QScrollArea()
            scroll.setObjectName(object_name)
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
            scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
            scroll.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
            page = QtWidgets.QWidget()
            page.setObjectName(object_name + "Content")
            layout = QtWidgets.QVBoxLayout(page)
            layout.setContentsMargins(5, 5, 5, 5)
            layout.setSpacing(6)
            layout.addWidget(self._build_intro_card(title_text, body_text))
            scroll.setWidget(page)
            return scroll, layout

        def _build_cleanup_group(self):
            group = QtWidgets.QGroupBox("Scene Cleaner")
            group.setToolTip("Remove user cameras and junk default markers while keeping animated prop markers.")
            layout = QtWidgets.QVBoxLayout(group)
            layout.setSpacing(5)
            marker_row = QtWidgets.QVBoxLayout()
            marker_row.setSpacing(5)
            marker_label = QtWidgets.QLabel("Prop Marker Base Name")
            marker_label.setToolTip("Name prefix Aminate uses when renaming animated prop markers.")
            marker_row.addWidget(marker_label)
            self.prop_marker_base_field = QtWidgets.QLineEdit(get_prop_marker_base_name())
            self.prop_marker_base_field.setPlaceholderText(DEFAULT_PROP_MARKER_BASE_NAME)
            self.prop_marker_base_field.setToolTip("Type the base name for animated prop markers such as Gun or Sword.")
            marker_row.addWidget(self.prop_marker_base_field)
            layout.addLayout(marker_row)
            cleaner_grid = QtWidgets.QGridLayout()
            cleaner_grid.setHorizontalSpacing(5)
            cleaner_grid.setVerticalSpacing(4)
            cleaner_grid.addWidget(self._action_button("Refresh", _on_refresh), 0, 0)
            cleaner_grid.addWidget(self._action_button("Scene Cleaner", self._run_scene_cleaner), 0, 1)
            cleaner_grid.addWidget(self._action_button("Delete Cameras", _on_clean_cameras), 1, 0)
            cleaner_grid.addWidget(self._action_button("Delete Markers", self._run_marker_cleanup), 1, 1)
            layout.addLayout(cleaner_grid)
            return group

        def _build_hik_mapping_group(self):
            group = QtWidgets.QGroupBox("HumanIK Mapping")
            group.setToolTip("Choose a skeleton, map it to HumanIK, validate it, and create a T-pose.")
            layout = QtWidgets.QVBoxLayout(group)
            layout.setSpacing(5)
            instruction = QtWidgets.QLabel("Select a skeleton bone or skinned mesh, then confirm the selection and Auto Map Skeleton.")
            instruction.setObjectName("mayaAnimWorkflowIntroBody")
            instruction.setWordWrap(True)
            instruction.setToolTip("Aminate reads the selected bone, bones, or skinned mesh to choose the correct skeleton.")
            layout.addWidget(instruction)
            skeleton_row = QtWidgets.QVBoxLayout()
            skeleton_row.setSpacing(5)
            skeleton_label = QtWidgets.QLabel("Skeleton Scope")
            skeleton_label.setToolTip("Aminate will Auto Map and T-Pose this selected skeleton hierarchy.")
            skeleton_row.addWidget(skeleton_label)
            self.skeleton_scope_label = QtWidgets.QLabel(selected_skeleton_scope_label())
            self.skeleton_scope_label.setObjectName("aminateMobuThemeBadge")
            self.skeleton_scope_label.setToolTip("Selected skeleton root for Auto Map and T-Pose.")
            skeleton_row.addWidget(self.skeleton_scope_label)
            layout.addLayout(skeleton_row)
            setup_grid = QtWidgets.QGridLayout()
            setup_grid.setHorizontalSpacing(5)
            setup_grid.setVerticalSpacing(4)
            setup_grid.addWidget(self._action_button("Use Selected Skeleton", self._use_selected_skeleton), 0, 0)
            setup_grid.addWidget(self._action_button("Auto Map Skeleton", self._auto_map_skeleton), 1, 0)
            setup_grid.addWidget(self._action_button("Validate Character", _on_validate), 2, 0)
            setup_grid.addWidget(self._action_button("T-Pose Frame 0", _on_tpose_frame_zero), 3, 0)
            layout.addLayout(setup_grid)
            return group

        def _build_setup_warnings_group(self):
            group = QtWidgets.QGroupBox("Live Setup Warnings")
            group.setToolTip("Check character setup and choose safe control-rig keying modes.")
            layout = QtWidgets.QVBoxLayout(group)
            layout.setSpacing(5)
            lock_hint = QtWidgets.QLabel("Lock definition: warns when all core HIK links are mapped but the character definition is still unlocked.")
            lock_hint.setObjectName("aminateMobuGroupHint")
            lock_hint.setWordWrap(True)
            layout.addWidget(lock_hint)
            mode_hint = QtWidgets.QLabel("Control-rig mode: warns when a control is moved while keying mode is Selection instead of Body Part or Full Body.")
            mode_hint.setObjectName("aminateMobuGroupHint")
            mode_hint.setWordWrap(True)
            layout.addWidget(mode_hint)
            warning_buttons = QtWidgets.QGridLayout()
            warning_buttons.setHorizontalSpacing(5)
            warning_buttons.setVerticalSpacing(4)
            warning_buttons.addWidget(self._action_button("Check Setup Now", self._check_setup_warnings), 0, 0)
            warning_buttons.addWidget(self._action_button("Body Part Mode", _on_body_part), 1, 0)
            warning_buttons.addWidget(self._action_button("Full Body Mode", _on_full_body), 2, 0)
            layout.addLayout(warning_buttons)
            warning_title = QtWidgets.QLabel("Warning History")
            warning_title.setObjectName("mayaAnimWorkflowIntroTitle")
            layout.addWidget(warning_title)
            self.warning_history_memo = QtWidgets.QPlainTextEdit()
            self.warning_history_memo.setObjectName("aminateMobuWarningHistory")
            self.warning_history_memo.setReadOnly(True)
            self.warning_history_memo.setMinimumHeight(86)
            self.warning_history_memo.setMinimumWidth(0)
            self.warning_history_memo.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
            self.warning_history_memo.setToolTip("Warnings shown during this MotionBuilder session.")
            layout.addWidget(self.warning_history_memo)
            status_title = QtWidgets.QLabel("Full Status")
            status_title.setObjectName("mayaAnimWorkflowIntroTitle")
            layout.addWidget(status_title)
            return group

        def _build_history_group(self):
            group = QtWidgets.QGroupBox("History Timeline")
            group.setToolTip("Open full-scene snapshots, restores, branches, milestones, and Auto History.")
            layout = QtWidgets.QVBoxLayout(group)
            layout.setSpacing(5)
            hint = QtWidgets.QLabel("Save the scene to a writable folder first, then open History Timeline to create and restore full-scene snapshots.")
            hint.setObjectName("aminateMobuGroupHint")
            hint.setWordWrap(True)
            layout.addWidget(hint)
            history_row = QtWidgets.QHBoxLayout()
            history_row.setSpacing(5)
            history_row.addWidget(self._action_button("History Timeline", _on_history_timeline))
            history_row.addStretch(1)
            layout.addLayout(history_row)
            return group

        def _build_constraints_manager_group(self):
            group = QtWidgets.QGroupBox("Constraints Manager")
            group.setToolTip("Better MotionBuilder constraint management: list, rename, key, save, and bake.")
            layout = QtWidgets.QVBoxLayout(group)
            layout.setSpacing(5)

            self.constraints_table = QtWidgets.QTableWidget(0, 5)
            self.constraints_table.setObjectName("aminateMobuConstraintsTable")
            self.constraints_table.setHorizontalHeaderLabels(["Name", "Type", "Active", "Weight", "Targets"])
            self.constraints_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
            self.constraints_table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
            self.constraints_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
            self.constraints_table.setToolTip("Select constraints here, then rename or key them.")
            self.constraints_table.setMinimumHeight(92)
            self.constraints_table.setMinimumWidth(0)
            self.constraints_table.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
            self.constraints_table.setMouseTracking(True)
            self.constraints_table.itemEntered.connect(self._preview_constraint_table_item)
            self.constraints_table.itemSelectionChanged.connect(self._preview_selected_constraint)
            try:
                self.constraints_table.horizontalHeader().setStretchLastSection(True)
            except Exception:
                pass
            layout.addWidget(self.constraints_table)

            button_grid = QtWidgets.QGridLayout()
            button_grid.setHorizontalSpacing(5)
            button_grid.setVerticalSpacing(4)
            button_grid.addWidget(self._action_button("List Constraints", self._refresh_constraints_manager), 0, 0)
            button_grid.addWidget(self._action_button("Rename To Easy Names", self._rename_selected_constraints_easy), 1, 0)
            button_grid.addWidget(self._action_button("Rename All Easy", self._rename_all_constraints_easy), 2, 0)
            button_grid.addWidget(self._action_button("Key Selected Props", self._key_selected_constraint_props), 3, 0)
            button_grid.addWidget(self._action_button("Bake Options", self._open_bake_options), 4, 0)
            button_grid.addWidget(self._action_button("Save To Skeleton", self._save_to_skeleton), 5, 0)
            button_grid.addWidget(self._action_button("Save To Control Rig", self._save_to_control_rig), 6, 0)
            layout.addLayout(button_grid)

            prop_offset_group = QtWidgets.QGroupBox("Prop Take Offset Manager")
            prop_offset_group.setToolTip("Fix prop constraints per take without forcing students to bake every take immediately.")
            prop_offset_layout = QtWidgets.QVBoxLayout(prop_offset_group)
            prop_offset_layout.setSpacing(4)
            prop_offset_hint = QtWidgets.QLabel(
                "For props that change position between takes: select the prop constraint, place the prop correctly, then store the offset for this take."
            )
            prop_offset_hint.setObjectName("aminateMobuGroupHint")
            prop_offset_hint.setWordWrap(True)
            prop_offset_hint.setToolTip("Use this when a prop hand constraint works on one take but breaks on another because the prop starts somewhere else.")
            prop_offset_layout.addWidget(prop_offset_hint)
            self.prop_offset_status = QtWidgets.QLabel(_LAST_PROP_OFFSET_PREVIEW)
            self.prop_offset_status.setObjectName("aminateMobuGroupHint")
            self.prop_offset_status.setWordWrap(True)
            self.prop_offset_status.setToolTip("Shows the last detected translation and rotation offset before Aminate keyed it.")
            prop_offset_layout.addWidget(self.prop_offset_status)
            prop_offset_buttons = QtWidgets.QGridLayout()
            prop_offset_buttons.setHorizontalSpacing(5)
            prop_offset_buttons.setVerticalSpacing(4)
            prop_offset_buttons.addWidget(self._action_button("Preview Offset Only", self._preview_prop_offset_only), 0, 0)
            prop_offset_buttons.addWidget(self._action_button("Set Offset For This Take", self._set_prop_offset_this_take), 1, 0)
            prop_offset_buttons.addWidget(self._action_button("Set Offset For All Takes", self._set_prop_offset_all_takes), 2, 0)
            prop_offset_buttons.addWidget(self._action_button("Mute Constraints For Setup", self._mute_prop_constraints_setup), 3, 0)
            prop_offset_buttons.addWidget(self._action_button("Restore Constraints", self._restore_prop_constraints_setup), 4, 0)
            prop_offset_layout.addLayout(prop_offset_buttons)
            layout.addWidget(prop_offset_group)

            preview_row = QtWidgets.QHBoxLayout()
            preview_row.setSpacing(6)
            self.constraint_tutorial_combo = QtWidgets.QComboBox()
            self.constraint_tutorial_combo.setToolTip("Pick a constraint demo preview.")
            preview_row.addWidget(self.constraint_tutorial_combo, 1)
            self.constraint_tutorial_combo.currentIndexChanged.connect(self._preview_constraint_combo)
            layout.addLayout(preview_row)

            self.constraint_preview_title = QtWidgets.QLabel("Hover a constraint or pick a demo.")
            self.constraint_preview_title.setObjectName("mayaAnimWorkflowIntroTitle")
            layout.addWidget(self.constraint_preview_title)
            self.constraint_preview = AspectRatioPixmapLabel()
            self.constraint_preview.setObjectName("aminateMobuConstraintPreview")
            self.constraint_preview.setMinimumSize(0, 150)
            self.constraint_preview.setAlignment(QtCore.Qt.AlignCenter)
            self.constraint_preview.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            self.constraint_preview.setToolTip("Simple visual constraint preview.")
            layout.addWidget(self.constraint_preview, 1)
            self._constraint_preview_key = ""
            self._populate_constraint_tutorial_combo()

            self.constraints_recommendations = QtWidgets.QLabel("\n".join(CONSTRAINT_RECOMMENDATIONS))
            self.constraints_recommendations.setObjectName("aminateMobuGroupHint")
            self.constraints_recommendations.setWordWrap(True)
            self.constraints_recommendations.setToolTip("Plain-English constraint suggestions.")
            layout.addWidget(self.constraints_recommendations)
            self._refresh_constraints_manager()
            return group

        def _build_definition_manager_group(self):
            group = QtWidgets.QGroupBox("Definition Manager")
            group.setToolTip("Save, load, rename, and delete quick character definition presets.")
            layout = QtWidgets.QVBoxLayout(group)
            layout.setSpacing(5)

            selector_row = QtWidgets.QHBoxLayout()
            selector_row.setSpacing(5)
            self.definition_combo = QtWidgets.QComboBox()
            self.definition_combo.setToolTip("Pick a saved character definition preset.")
            selector_row.addWidget(self.definition_combo, 1)
            selector_row.addWidget(self._action_button("Refresh Definitions", self._refresh_definition_manager))
            layout.addLayout(selector_row)

            name_row = QtWidgets.QHBoxLayout()
            name_row.setSpacing(5)
            self.definition_name_field = QtWidgets.QLineEdit()
            self.definition_name_field.setPlaceholderText("Definition name")
            self.definition_name_field.setToolTip("Name used when saving or renaming a definition preset.")
            name_row.addWidget(self.definition_name_field, 1)
            layout.addLayout(name_row)

            button_grid = QtWidgets.QGridLayout()
            button_grid.setHorizontalSpacing(5)
            button_grid.setVerticalSpacing(4)
            button_grid.addWidget(self._action_button("Save Definition", self._save_definition), 0, 0)
            button_grid.addWidget(self._action_button("Load Definition", self._load_definition), 1, 0)
            button_grid.addWidget(self._action_button("Rename Definition", self._rename_definition), 2, 0)
            button_grid.addWidget(self._action_button("Delete Definition", self._delete_definition), 3, 0)
            layout.addLayout(button_grid)
            self._refresh_definition_manager()
            return group

        def _build_note_group(self):
            group = QtWidgets.QGroupBox("Notes")
            group.setToolTip("Short simple notes about how Aminate handles markers and cleanup.")
            layout = QtWidgets.QVBoxLayout(group)
            layout.setSpacing(3)
            hint = QtWidgets.QLabel(
                "Default markers with translation or rotation keys are treated as prop markers. Scene Cleaner keeps them, renames them with your chosen base name, and only deletes non-animated junk markers."
            )
            hint.setObjectName("aminateMobuGroupHint")
            hint.setWordWrap(True)
            hint.setToolTip("Explains what Aminate keeps, renames, and deletes during marker cleanup.")
            layout.addWidget(hint)
            return group

        def _action_button(self, caption, callback):
            button = QtWidgets.QPushButton(caption)
            button.setMinimumWidth(0)
            button.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
            tooltip = _easy_tooltip_text(caption, "QPushButton")
            if tooltip:
                button.setToolTip(tooltip)
            button.clicked.connect(lambda _checked=False, fn=callback: fn())
            return button

        def _apply_theme(self, theme_key=None):
            self.theme_key = set_active_theme(theme_key or self.theme_key)
            self.setStyleSheet(_theme_stylesheet(self.theme_key))
            if getattr(self, "theme_badge", None) is not None:
                self.theme_badge.setText("Theme  {0}".format(_theme_label(self.theme_key)))
            if getattr(self, "theme_button", None) is not None:
                self.theme_button.setText(_theme_toggle_caption(self.theme_key))
                self.theme_button.setToolTip(_theme_tooltip(self.theme_key))
            _style_donate_button(getattr(self, "donate_button", None), self.theme_key)
            _apply_app_theme(self.theme_key)
            install_easy_motionbuilder_tooltips()

        def _toggle_theme(self):
            self._apply_theme(_other_theme(self.theme_key))
            _append_status("Theme switched to {0}.".format(_theme_label(self.theme_key)))
            _refresh_dashboard()

        def _toggle_collapsed(self):
            self._collapsed = not self._collapsed
            self.scroll_area.setVisible(not self._collapsed)
            self.header_subtitle.setVisible(not self._collapsed)
            self.theme_badge.setVisible(not self._collapsed)
            self.theme_button.setVisible(not self._collapsed)
            if self._collapsed:
                self.collapse_button.setText("Show Panel")
                self.collapse_button.setToolTip("Expand Aminate back into the full panel.")
                self.setMinimumWidth(150)
                self.resize(150, max(self.height(), 260))
            else:
                self.collapse_button.setText("Hide Panel")
                self.collapse_button.setToolTip("Collapse Aminate into a thin side panel.")
                self.setMinimumWidth(220)
                self.resize(max(self.width(), 420), max(self.height(), 520))

        def _refresh_skeleton_scope_label(self):
            if getattr(self, "skeleton_scope_label", None) is not None:
                self.skeleton_scope_label.setText(selected_skeleton_scope_label())

        def _use_selected_skeleton(self):
            set_selected_skeleton_scope_from_selection()
            self._refresh_skeleton_scope_label()
            _refresh_dashboard()

        def _auto_map_skeleton(self):
            auto_map_character(create_control_rig=False, characterize=True, activate_input=False)
            self._refresh_skeleton_scope_label()
            _refresh_dashboard()

        def _check_setup_warnings(self):
            result = validate_current_character()
            self._refresh_warning_history_view()
            _refresh_dashboard()
            return result

        def _refresh_warning_history_view(self):
            memo = getattr(self, "warning_history_memo", None)
            if memo is None:
                return
            history = get_warning_history()
            if not history:
                memo.setPlainText("No setup warnings shown in this session.")
                return
            lines = []
            for item in history:
                lines.append("{0}: {1}".format(item.get("kind", "warning"), item.get("message", "")))
            memo.setPlainText("\n\n".join(lines))

        def _refresh_constraints_manager(self):
            table = getattr(self, "constraints_table", None)
            if table is None:
                return
            rows = constraint_rows()
            self._constraint_row_objects = [row["constraint"] for row in rows]
            table.setRowCount(len(rows))
            for row_index, row in enumerate(rows):
                values = [
                    row["name"],
                    row["type"],
                    "Yes" if row["active"] else "No",
                    str(row["weight"]),
                    row["targets"],
                ]
                for col_index, value in enumerate(values):
                    item = QtWidgets.QTableWidgetItem(str(value))
                    table.setItem(row_index, col_index, item)
            try:
                table.resizeColumnsToContents()
            except Exception:
                pass
            _append_status("Constraints Manager listed {0} constraint(s).".format(len(rows)))
            _refresh_dashboard()

        def _populate_constraint_tutorial_combo(self):
            combo = getattr(self, "constraint_tutorial_combo", None)
            if combo is None:
                return
            combo.blockSignals(True)
            combo.clear()
            for key, item in _constraint_tutorial_index().items():
                combo.addItem(item.get("title", key), key)
            combo.blockSignals(False)
            if combo.count():
                self._preview_constraint_key(str(combo.itemData(0)))

        def _preview_constraint_key(self, key):
            if not key or key == getattr(self, "_constraint_preview_key", ""):
                return
            path = _constraint_tutorial_asset_path(key)
            index = _constraint_tutorial_index()
            item = index.get(key, {})
            title = item.get("title", key)
            description = item.get("description", "")
            if getattr(self, "constraint_preview_title", None) is not None:
                self.constraint_preview_title.setText("{0}: {1}".format(title, description))
            if not os.path.isfile(path) or getattr(self, "constraint_preview", None) is None:
                if getattr(self, "constraint_preview", None) is not None:
                    self.constraint_preview.setText("No preview found for {0}".format(title))
                return
            pixmap = QtGui.QPixmap(path)
            if pixmap.isNull():
                self.constraint_preview.setText("No preview found for {0}".format(title))
                return
            self.constraint_preview.clear()
            self.constraint_preview.setAspectPixmap(pixmap)
            self._constraint_preview_key = key

        def _preview_constraint_table_item(self, item):
            row = item.row() if item is not None else -1
            objects = getattr(self, "_constraint_row_objects", [])
            if 0 <= row < len(objects):
                self._preview_constraint_key(_constraint_tutorial_key(objects[row]))

        def _preview_selected_constraint(self):
            table = getattr(self, "constraints_table", None)
            if table is None:
                return
            rows = sorted({index.row() for index in table.selectionModel().selectedRows()})
            objects = getattr(self, "_constraint_row_objects", [])
            if rows and 0 <= rows[0] < len(objects):
                self._preview_constraint_key(_constraint_tutorial_key(objects[rows[0]]))

        def _preview_constraint_combo(self, index):
            combo = getattr(self, "constraint_tutorial_combo", None)
            if combo is None or index < 0:
                return
            self._preview_constraint_key(str(combo.itemData(index)))

        def _selected_constraints_from_table(self):
            table = getattr(self, "constraints_table", None)
            objects = getattr(self, "_constraint_row_objects", [])
            if table is None:
                return []
            rows = sorted({index.row() for index in table.selectionModel().selectedRows()})
            selected = []
            for row in rows:
                if 0 <= row < len(objects):
                    selected.append(objects[row])
            return selected

        def _rename_selected_constraints_easy(self):
            selected = self._selected_constraints_from_table()
            if not selected:
                selected = _scene_constraints()
            rename_constraints_to_easy_names(selected)
            self._refresh_constraints_manager()

        def _rename_all_constraints_easy(self):
            rename_constraints_to_easy_names(_scene_constraints())
            self._refresh_constraints_manager()

        def _key_selected_constraint_props(self):
            selected = self._selected_constraints_from_table()
            if not selected:
                selected = _scene_constraints()
            key_constraint_properties(selected)
            _refresh_dashboard()

        def _preview_prop_offset_only(self):
            selected = self._selected_constraints_from_table()
            if not selected:
                selected = _scene_constraints()
            result = preview_prop_offset(selected)
            self._refresh_prop_offset_status(result)
            _refresh_dashboard()

        def _set_prop_offset_this_take(self):
            selected = self._selected_constraints_from_table()
            if not selected:
                selected = _scene_constraints()
            result = set_prop_offset_for_take(selected)
            self._refresh_prop_offset_status(result)
            self._refresh_constraints_manager()

        def _set_prop_offset_all_takes(self):
            selected = self._selected_constraints_from_table()
            if not selected:
                selected = _scene_constraints()
            result = set_prop_offset_for_all_takes(selected)
            self._refresh_prop_offset_status(result)
            self._refresh_constraints_manager()

        def _mute_prop_constraints_setup(self):
            selected = self._selected_constraints_from_table()
            if not selected:
                selected = _scene_constraints()
            mute_prop_constraints_for_setup(selected)
            self._refresh_constraints_manager()

        def _restore_prop_constraints_setup(self):
            selected = self._selected_constraints_from_table()
            if not selected:
                selected = _scene_constraints()
            restore_prop_constraints_after_setup(selected)
            self._refresh_constraints_manager()

        def _refresh_prop_offset_status(self, result=None):
            label = getattr(self, "prop_offset_status", None)
            if label is None:
                return
            if result and result.get("preview"):
                label.setText(result["preview"][-1])
            else:
                label.setText(_LAST_PROP_OFFSET_PREVIEW)

        def _open_bake_options(self):
            open_constraint_bake_options()
            _refresh_dashboard()

        def _save_to_skeleton(self):
            save_current_character_motion(FBCharacterPlotWhere.kFBCharacterPlotOnSkeleton)
            _refresh_dashboard()

        def _save_to_control_rig(self):
            save_current_character_motion(FBCharacterPlotWhere.kFBCharacterPlotOnControlRig)
            _refresh_dashboard()

        def _cleaner_base_name(self):
            return set_prop_marker_base_name(getattr(self, "prop_marker_base_field", None).text() if getattr(self, "prop_marker_base_field", None) is not None else get_prop_marker_base_name())

        def _run_scene_cleaner(self):
            _on_clean_scene(prop_marker_base_name=self._cleaner_base_name())

        def _run_marker_cleanup(self):
            _on_clean_markers(prop_marker_base_name=self._cleaner_base_name())

        def _selected_definition_name(self):
            combo = getattr(self, "definition_combo", None)
            if combo is not None and combo.currentText():
                return combo.currentText()
            return getattr(self, "definition_name_field", None).text() if getattr(self, "definition_name_field", None) is not None else ""

        def _refresh_definition_manager(self):
            combo = getattr(self, "definition_combo", None)
            if combo is None:
                return
            current = combo.currentText()
            combo.blockSignals(True)
            combo.clear()
            names = _definition_names()
            combo.addItems(names)
            if current in names:
                combo.setCurrentText(current)
            combo.blockSignals(False)
            if getattr(self, "definition_name_field", None) is not None and combo.currentText():
                self.definition_name_field.setText(combo.currentText())

        def _save_definition(self):
            name = getattr(self, "definition_name_field", None).text() if getattr(self, "definition_name_field", None) is not None else ""
            result = save_current_character_definition(name)
            self._refresh_definition_manager()
            if result.get("ok") and getattr(self, "definition_combo", None) is not None:
                self.definition_combo.setCurrentText(result.get("name", ""))
            _refresh_dashboard()

        def _load_definition(self):
            load_character_definition(self._selected_definition_name())
            _refresh_dashboard()

        def _rename_definition(self):
            old_name = self._selected_definition_name()
            new_name = getattr(self, "definition_name_field", None).text() if getattr(self, "definition_name_field", None) is not None else ""
            result = rename_character_definition(old_name, new_name)
            self._refresh_definition_manager()
            if result.get("ok") and getattr(self, "definition_combo", None) is not None:
                self.definition_combo.setCurrentText(result.get("new_name", ""))
            _refresh_dashboard()

        def _delete_definition(self):
            delete_character_definition(self._selected_definition_name())
            self._refresh_definition_manager()
            _refresh_dashboard()

        def _open_follow_url(self, url=None):
            if _open_external_url(url or FOLLOW_AMIR_URL):
                _append_status("Opened followamir.com.")
                _refresh_dashboard()
            else:
                _append_status("Could not open followamir.com from this MotionBuilder session.")
                _refresh_dashboard()

        def _open_donate_url(self):
            if DONATE_URL and _open_external_url(DONATE_URL):
                _append_status("Opened the Donate link.")
                _refresh_dashboard()
            else:
                _append_status("Could not open the Donate link from this MotionBuilder session.")
                _refresh_dashboard()

    class AminateMobuDockWidget(QtWidgets.QDockWidget):
        def __init__(self, parent=None):
            super(AminateMobuDockWidget, self).__init__(TOOL_NAME, parent or _qt_host_main_window())
            self.setObjectName(QT_DOCK_OBJECT_NAME)
            self.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
            self.setAllowedAreas(QtCore.Qt.AllDockWidgetAreas)
            self.setFeatures(
                QtWidgets.QDockWidget.DockWidgetClosable
                | QtWidgets.QDockWidget.DockWidgetMovable
                | QtWidgets.QDockWidget.DockWidgetFloatable
            )
            self.panel = AminateMobuPanel(self)
            self.status_memo = self.panel.status_memo
            self.status_label = self.panel.status_label
            self.setWidget(self.panel)

        def closeEvent(self, event):
            global _QT_DOCK
            global _QT_TOOL
            is_current_dock = self is _QT_DOCK
            if is_current_dock:
                _QT_DOCK = None
                _QT_TOOL = None
            super(AminateMobuDockWidget, self).closeEvent(event)
            if is_current_dock:
                QtCore.QTimer.singleShot(0, _restore_app_theme)


def _populate_tool_layout(tool):
    x_pos = FBAddRegionParam(0, FBAttachType.kFBAttachLeft, "")
    y_pos = FBAddRegionParam(0, FBAttachType.kFBAttachTop, "")
    width = FBAddRegionParam(0, FBAttachType.kFBAttachRight, "")
    height = FBAddRegionParam(0, FBAttachType.kFBAttachBottom, "")
    tool.AddRegion("main", "main", x_pos, y_pos, width, height)
    container = pyfbsdk_additions.FBVBoxLayout(FBAttachType.kFBAttachTop)
    tool.SetControl("main", container)

    title = FBLabel()
    title.Caption = TOOL_NAME + "  " + TOOL_VERSION
    container.Add(title, 24)

    subhead = FBLabel()
    subhead.Caption = "Scene Cleaner  Auto Map  Lock Warning  Control Rig Mode Warning"
    container.Add(subhead, 20)

    row = pyfbsdk_additions.FBHBoxLayout(FBAttachType.kFBAttachLeft)
    row.Add(_button("Refresh", _on_refresh, color=(0.18, 0.36, 0.64)), 96)
    row.Add(_button("Scene Cleaner", _on_clean_scene, color=(0.10, 0.44, 0.40)), 120)
    row.Add(_button("Delete Cameras", _on_clean_cameras, color=(0.16, 0.26, 0.42)), 120)
    row.Add(_button("Delete Markers", _on_clean_markers, color=(0.16, 0.26, 0.42)), 120)
    container.Add(row, 28)

    row = pyfbsdk_additions.FBHBoxLayout(FBAttachType.kFBAttachLeft)
    row.Add(_button("Auto Map Skeleton", _on_auto_map, color=(0.40, 0.24, 0.10)), 150)
    row.Add(_button("Validate Character", _on_validate, color=(0.26, 0.24, 0.40)), 150)
    row.Add(_button("T-Pose Frame 0", _on_tpose_frame_zero, color=(0.24, 0.34, 0.40)), 150)
    row.Add(_button("Body Part Mode", _on_body_part, color=(0.24, 0.34, 0.14)), 130)
    row.Add(_button("Full Body Mode", _on_full_body, color=(0.24, 0.34, 0.14)), 130)
    container.Add(row, 28)
    instruction = FBEdit()
    instruction.ReadOnly = True
    instruction.Text = "Select a skeleton bone or skinned mesh, then click Auto Map Skeleton."
    container.Add(instruction, 26)

    row = pyfbsdk_additions.FBHBoxLayout(FBAttachType.kFBAttachLeft)
    row.Add(_button("History Timeline", _on_history_timeline, color=(0.46, 0.34, 0.12)), 180)
    row.Add(_button("Rename To Easy Names", _on_rename_constraints_easy, color=(0.24, 0.34, 0.40)), 180)
    row.Add(_button("Key Selected Props", _on_key_constraints, color=(0.24, 0.34, 0.40)), 160)
    container.Add(row, 28)

    row = pyfbsdk_additions.FBHBoxLayout(FBAttachType.kFBAttachLeft)
    row.Add(_button("Preview Offset Only", _on_preview_prop_offset, color=(0.18, 0.30, 0.38)), 180)
    row.Add(_button("Set Offset For This Take", _on_prop_offset_this_take, color=(0.24, 0.34, 0.40)), 190)
    row.Add(_button("Set Offset For All Takes", _on_prop_offset_all_takes, color=(0.24, 0.34, 0.40)), 190)
    row.Add(_button("Mute Constraints For Setup", _on_mute_prop_constraints, color=(0.20, 0.28, 0.36)), 210)
    row.Add(_button("Restore Constraints", _on_restore_prop_constraints, color=(0.20, 0.36, 0.28)), 170)
    container.Add(row, 28)

    note = FBEdit()
    note.ReadOnly = True
    note.Text = SCENE_CLEANER_HINT
    container.Add(note, 36)

    memo = FBMemo()
    tool.status_memo = memo
    container.AddRelative(memo, 1.0)


def launch_aminate_mobu():
    global _QT_TOOL
    global _QT_DOCK
    global _TOOL
    install_runtime_watchers()
    prime_app_theme_baseline()
    ensure_native_default_ui_snapshot(force=False)
    set_active_theme(THEME_MODERN)
    _apply_app_theme(THEME_MODERN)
    _ensure_aminate_launcher_toolbar()
    install_easy_motionbuilder_tooltips()
    if QtWidgets is not None and hasattr(_qt_host_main_window(), "addDockWidget"):
        if not _qt_object_is_valid(_QT_DOCK):
            _QT_DOCK = None
            _QT_TOOL = None
        elif not _qt_object_is_valid(_QT_TOOL):
            _QT_TOOL = getattr(_QT_DOCK, "panel", None)
        if _QT_DOCK is None:
            existing_docks = _existing_aminate_mobu_docks()
            if existing_docks:
                _QT_DOCK = existing_docks[-1]
                _close_duplicate_aminate_mobu_docks(keep_dock=_QT_DOCK)
                _QT_TOOL = getattr(_QT_DOCK, "panel", None)
                if (
                    _QT_TOOL is None
                    or not hasattr(_QT_TOOL, "collapse_button")
                    or not hasattr(_QT_TOOL, "constraints_table")
                    or not hasattr(_QT_TOOL, "skeleton_scope_label")
                    or getattr(_QT_TOOL, "_build_version", 0) != QT_PANEL_BUILD_VERSION
                ):
                    stale_dock = _QT_DOCK
                    _QT_DOCK = None
                    _QT_TOOL = None
                    try:
                        stale_dock.hide()
                    except Exception:
                        pass
                    try:
                        stale_dock.close()
                    except Exception:
                        pass
                    app = _qt_application()
                    if app is not None:
                        try:
                            app.processEvents()
                        except Exception:
                            pass
        if _QT_DOCK is None:
            main = _qt_host_main_window()
            _QT_DOCK = AminateMobuDockWidget(parent=main)
            _QT_TOOL = _QT_DOCK.panel
            try:
                main.addDockWidget(QtCore.Qt.RightDockWidgetArea, _QT_DOCK)
            except Exception:
                pass
            _close_duplicate_aminate_mobu_docks(keep_dock=_QT_DOCK)
        try:
            _QT_DOCK.show()
            _QT_DOCK.raise_()
        except Exception:
            pass
        _set_status_lines(_tool_intro_lines())
        _refresh_dashboard()
        install_easy_motionbuilder_tooltips()
        return _QT_DOCK
    if TOOL_NAME in pyfbsdk_additions.FBToolList:
        _TOOL = pyfbsdk_additions.FBToolList[TOOL_NAME]
        try:
            _TOOL.SetPossibleDockPosition(FBToolPossibleDockPosition.kFBToolPossibleDockPosLeft)
            _TOOL.SetPossibleDockPosition(FBToolPossibleDockPosition.kFBToolPossibleDockPosRight)
            _TOOL.SetPossibleDockPosition(FBToolPossibleDockPosition.kFBToolPossibleDockPosTop)
            _TOOL.SetPossibleDockPosition(FBToolPossibleDockPosition.kFBToolPossibleDockPosBottom)
        except Exception:
            pass
        ShowTool(_TOOL)
        _refresh_dashboard()
        return _TOOL
    tool = pyfbsdk_additions.FBCreateUniqueTool(TOOL_NAME)
    tool.StartSizeX = 760
    tool.StartSizeY = 420
    try:
        tool.SetPossibleDockPosition(FBToolPossibleDockPosition.kFBToolPossibleDockPosLeft)
        tool.SetPossibleDockPosition(FBToolPossibleDockPosition.kFBToolPossibleDockPosRight)
        tool.SetPossibleDockPosition(FBToolPossibleDockPosition.kFBToolPossibleDockPosTop)
        tool.SetPossibleDockPosition(FBToolPossibleDockPosition.kFBToolPossibleDockPosBottom)
    except Exception:
        pass
    _populate_tool_layout(tool)
    ShowTool(tool)
    _TOOL = tool
    _set_status_lines(_tool_intro_lines())
    _refresh_dashboard()
    return tool


__all__ = [
    "CONTROL_RIG_MODE_WARNING",
    "LOCK_DEFINITION_WARNING",
    "SCENE_CLEANER_HINT",
    "TOOL_NAME",
    "TOOL_VERSION",
    "auto_map_character",
    "character_setup_seems_done",
    "collect_scene_clean_targets",
    "get_prop_marker_base_name",
    "get_warning_history",
    "handle_transform_attempt",
    "install_motionbuilder_startup",
    "install_runtime_watchers",
    "key_constraint_properties",
    "launch_aminate_mobu",
    "make_tpose_on_frame_zero",
    "make_tpose_on_frame_one",
    "maybe_warn_control_rig_mode",
    "maybe_warn_lock_definition",
    "remove_runtime_watchers",
    "rename_constraints_to_easy_names",
    "reset_runtime_state",
    "run_scene_cleaner",
    "set_prop_marker_base_name",
    "set_keying_mode_body_part",
    "set_keying_mode_full_body",
    "set_selected_skeleton_scope_from_selection",
    "selected_skeleton_scope_label",
    "startup_bootstrap_path",
    "ensure_motionbuilder_ui_entry",
    "validate_current_character",
]
